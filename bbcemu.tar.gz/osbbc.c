
#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <string.h>

#include "config.h"
#include "mc6502.h"

unsigned int load_address = 0;
unsigned int exec_address = 0;
unsigned int last_address = 0;
unsigned int trac_address = 0;

char * trac_file = 0;
int trac_saved = 0;

long inst_cnt = 0;

int is_other = 0;
int do_trace = 0;
int ena_ports = -1;
int mon_err = 0;

int read_line_done = 0;
char read_line_buf[256];

main(argc, argv)
int argc;
char **argv;
{
   int ar;
   unsigned char * p;
   int nloads=0;

#ifndef __MSDOS__
   /* If run as root disable some stuff */
   if( getuid() == 0 || geteuid() == 0 )
   {
      is_other = 1;
      setuid(0);
      setgid(32767);
      setuid(32767);
   }
#endif

   reset_6502();
   two_megas(0);
   bbc_ram_init();

   for(ar=1; ar<argc; ar++) if( argv[ar][0] == '-' )
   {
      switch(argv[ar][1])
      {
         case 'l': sscanf(argv[ar]+2,"%i",&load_address);
	           break;
	 case 't': do_trace= -1;
		   if( argv[ar][2] ) trac_file = argv[ar]+2;
	           break;
	 case 'b': if( argv[ar][2] >= '0' && argv[ar][2] <= '9' )
                      sscanf(argv[ar]+2,"%i",&trac_address);
                   break;
	 case 'o': is_other= 1; break;
         case 'm': do_trace= 1; break;
         case 'p': ena_ports = atoi(argv[ar]+2); break;
	 case 'e': mon_err++; break;
      }
   }
   else
   {
      load_image_file(argv[ar]);
      nloads++;
   }

   if( ena_ports == 0 )
   {
      mem_rd[0xFE] = mem_wr[0xFE] = 0;	/* SHEILA */
      mem_rd[0xFD] = mem_wr[0xFD] = 0;	/* JIM */
      mem_rd[0xFC] = mem_wr[0xFC] = 0;	/* FRED */
   }

   run_bbc();
   term_screen();
   exit(1);
}

load_image_file(fname)
char * fname;
{
   unsigned char buf[256];
   unsigned char * p;
   FILE * fd;
   int cc;

   fd = fopen(fname, "rb");
   if( fd == 0 )
   {
      printf("Cannot open image %s\n", fname);
      return 0;
   }
   printf("Loading %s ", fname);

   cc = fread(buf, 1, 256, fd);
   if( memcmp((p=buf+buf[7]), "\0(C)", 4) == 0)
   {
      load_address = 0x8000;

      if( (buf[6] & 0x60) == 0x60) for(p++; p<buf+cc; p++)
      {
         if( *p == 0 )
	 {
	    load_address = p[1] + (p[2]<<8);
	    break;
	 }
      }
      exec_address = load_address;
   }
   printf("at $%04x\n", load_address);

   while( cc > 0 )
   {
      memcpy(memory+load_address, buf, cc);
      load_address+=cc;
      cc = fread(buf, 1, 256, fd);
   }
   fclose(fd);
   return 1;
}

bbc_ram_init()
{
   int i;

   memset(memory,        0, 0x8000);
#ifndef DATA16
   memset(memory+0x8000, 0, 0x7F00);
#endif
   memset(memory+0xFF00, 0, 0x0100);

   /* I/O pages */
   mem_rd[0xFE] = mem_wr[0xFE] = -2;	/* SHEILA */
   mem_rd[0xFD] = mem_wr[0xFD] = -3;	/* JIM */
   mem_rd[0xFC] = mem_wr[0xFC] = -4;	/* FRED */

   /* Point reset vector at OS entry to start BBC rom */
   memory[0xFFFC] = (0xFF01 &0xFF); memory[0xFFFD] = (0xFF01 >>8);

   /* Brk to host code */
   memory[0xFFFE] = 0xFF;
   memory[0xFFFF] = 0xFF;

   for(i=0; i<27; i++)
   {
      memory[0x200+i*2]   = i*3;
      memory[0x200+i*2+1] = 0xFF;
   }

   set_vec(0xFFCE, 0x021C, -1);
   set_vec(0xFFD1, 0x021A, -1);
   set_vec(0xFFD4, 0x0218, -1);
   set_vec(0xFFD7, 0x0216, -1);
   set_vec(0xFFDA, 0x0214, -1);
   set_vec(0xFFDD, 0x0212, -1);
   set_vec(0xFFE0, 0x0210, 0xFFC8);
{
   static unsigned char code[] =
   { 0xC9, 0x0D, 0xD0, 0x07, 0xA9, 0x0A, 0x20, 0xEE, 0xFF, 0xA9, 0x0D };
   memcpy(memory+0xFFE3, (void*)code, 11);
}
   set_vec(0xFFEE, 0x020E, 0xFFCB);
   set_vec(0xFFF1, 0x020C, -1);
   set_vec(0xFFF4, 0x020A, -1);
   set_vec(0xFFF7, 0x0208, -1);
}

exec_bbc_rom()
{
   int i;

   if( exec_address == 0 )
   {
      i = load_image_file("bbc_hibas.rom");
      if( i == 0 )
         i = load_image_file("bbc_bas.rom");
      reset_6502();
      return i;
   }

   if( memcmp(memory+exec_address+memory[exec_address+7], "\0(C)", 4) )
   {
      printf("No BBC rom signature found at $%04x\n", exec_address);
      do_trace=1;
      return 1;
   }

   cpu.pc = exec_address;
   cpu.acc=1;
   cpu.sreg = 0xfd;
   cpu.ir = -1;
   memory[0x01fe] = 0x01;
   memory[0x01ff] = 0xFF;

   /* Ah well, we don't seem to need the I/O pages */
   if( ena_ports != 1 )
   {
      mem_rd[0xFE] = mem_wr[0xFE] = 0;	/* SHEILA */
      mem_rd[0xFD] = mem_wr[0xFD] = 0;	/* JIM */
      mem_rd[0xFC] = mem_wr[0xFC] = 0;	/* FRED */
   }

   for(i=exec_address+9; memory[i] != 0; i++)
      if( memory[i] >= ' ' && memory[i] <= '~' )
         outchar(memory[i]);

   memory[0xFD] = i;
   memory[0xFE] = (i>>8);

   last_address = exec_address;
   exec_address = 0;

   outchar('\r');
   outchar('\n');

   return 1;
}

set_vec(caller, vector, dest)
unsigned int caller, vector, dest;
{
   if( caller != 0 )
   {
      memory[caller]   = 0x6C;
      memory[caller+1] = (vector&0xFF);
      memory[caller+2] = (vector>>8);
   }

   if( dest != -1 )
   {
      memory[vector] = dest;
      memory[vector+1] = (dest>>8);
   }
}

void intr_6502()
{
   inst_cnt -= cpu.utimer;

   cpu.int_pending = 1;
   cpu.utimer = 0;
}

run_bbc()
{
   if( trac_address )
   {
      trac_saved = memory[trac_address];
      memory[trac_address] = 0xf3;
   }

   for(;;)
   {
      two_megas(2);

      if( do_trace )
      {
         inst_cnt += 1-cpu.utimer;
	 cpu.utimer += 1-cpu.utimer;
         if( do_trace > 0 )  do_trace--;
         if( do_trace == 0 ) monitor();
         else                cpu_status();
      }
      else while( cpu.utimer <= 0 )
      {
         cpu.utimer += 80000; /* A short length of time */
         inst_cnt += 80000;
      }

      {
         register int rv = run_6502();
	 if( rv == 1 )
	 {
#if 1
	    if( (memory[cpu.pc] & 0xF) == 3 )
	    {
	       switch(memory[cpu.pc++]>>4)
	       {
	       case  0: oscli_call(); break;
	       case  1: osbyte_call(); break;
	       case  2: osword_call(); break;
	       case  3: outchar(cpu.acc); break;
               case  4: cpu.acc = inchar(); two_megas(0); break;
               case  5: osfile_call(); break;
               case  6: bbcfatal("Unimplemented OSARGS call", 1); break;
               case  7: bbcfatal("Unimplemented OSBGET call", 1); break;
               case  8: bbcfatal("Unimplemented OSBPUT call", 1); break;
               case  9: bbcfatal("Unimplemented OSGBPB call", 1); break;
               case 10: bbcfatal("Unimplemented OSFIND call", 1); break;
               case 11: term_screen(); exit(0);
               case 12: exec_bbc_rom();
                        if(exec_address) exec_bbc_rom();
                        memory[0xF4] = (last_address&0xFF);
                        memory[0xF5] = (last_address>>8);
                        break;

               case 15:
		     if( trac_address && cpu.pc-1 == trac_address )
		     {
			cpu.pc--;
			memory[trac_address] = trac_saved;
			trac_address = 0;
			do_trace = 1;
			break;
		     }
	       default: cpu.pc--;
                       bbcfatal("OSbbc instruction unimplemented", 1);
	       }
	    }
	    else
#endif
            {
	       do_trace=1;
	       printf("Illegal instruction\n");
	    }
	 }
	 else if( rv == 2 )
	 {
	    if(!oscall() ) break;
	 }
      }
      if( cpu.utimer <= 0 ) check_esc();
   }

   printf("Halt"); cpu_status();
}

oscall()
{
   cpu.ir = 0x60;

   switch(cpu.pc)
   {
   case 0xFF01: return exec_bbc_rom();

   case 0xFF00: bbcfatal("Untrapped USERV", 1); break;
   case 0xFF03: bbcfatal("Untrapped BRK instruction", 0); break;
   case 0xFF06: bbcfatal("Vector IRQ1V called", 0); break;
   case 0xFF09: bbcfatal("Vector IRQ2V called", 0); break;

   case 0xFF0C: oscli_call(); break;
   case 0xFF0F: osbyte_call(); break;
   case 0xFF12: osword_call(); break;
   case 0xFF1B: osfile_call(); break;

   case 0xFF1E: bbcfatal("Unimplemented OSARGS call", 1); break;
   case 0xFF21: bbcfatal("Unimplemented OSBGET call", 1); break;
   case 0xFF24: bbcfatal("Unimplemented OSBPUT call", 1); break;
   case 0xFF27: bbcfatal("Unimplemented OSGBPB call", 1); break;
   case 0xFF2A: bbcfatal("Unimplemented OSFIND call", 1); break;

   case 0xFFB9: bbcfatal("Unimplemented OSRDRM call", 1); break;
   case 0xFFBF: bbcfatal("Unimplemented OSEVEN call", 1); break;
   case 0xFFC2: bbcfatal("Unimplemented GSINIT call", 1); break;
   case 0xFFC5: bbcfatal("Unimplemented GSREAD call", 1); break;

   case 0xFFC8: cpu.acc = inchar(); two_megas(0); break;
   case 0xFFCB: outchar(cpu.acc); break;

/* All these are revectored */

   case 0xFFCE: return bbcfatal("Unimplemented OSFIND call", 1);
   case 0xFFD1: return bbcfatal("Unimplemented OSGBPB call", 1);
   case 0xFFD4: return bbcfatal("Unimplemented OSBPUT call", 1);
   case 0xFFD7: return bbcfatal("Unimplemented OSBGET call", 1);
   case 0xFFDA: return bbcfatal("Unimplemented OSARGS call", 1);
   case 0xFFDD: return osfile_call();
   case 0xFFE0: cpu.acc = inchar(); two_megas(0); break;
   case 0xFFE3: if(cpu.acc!='\r') {outchar(cpu.acc); break;}
   case 0xFFE7: outchar('\n'); outchar(cpu.acc = '\r'); break;
   case 0xFFEE: outchar(cpu.acc); break;
   case 0xFFF1: return osword_call();
   case 0xFFF4: return osbyte_call();
   case 0xFFF7: return oscli_call();
/***/

   default: if(cpu.pc < 0xFF00 )
               brkinstr();
            else
               bbcfatal("Unimplemented OS entry point", 1);
            break;
   }

   return 1;
}

bbcfatal(str, regflag)
char * str;
int regflag;
{
   char buf[256];

   strcpy(buf, str);

   if( regflag )
   {
      sprintf(buf+strlen(buf), " At %04x: %02x %02x %02x ",
           cpu.pc, memory[cpu.pc], memory[cpu.pc+1], memory[cpu.pc+2]);

      sprintf(buf+strlen(buf), "A %02x X %02x Y %02x S %02x P %02x",
           cpu.acc, cpu.xreg, cpu.yreg, cpu.sreg, cpu.preg);
   }
   buf[78] = '\0';

   cpu.pc = 0x100;
   cpu.ir = -1;
   memory[0x100] = 0x00;
   memory[0x101] = 0x00;
   strcpy(memory+0x102, buf);

   if( mon_err ) do_trace=1;
   return 1;
}

brkinstr()
{
   unsigned int brkv1;
   unsigned int brkv2;

   cpu.ir = -1;

   brkv1 = memory[0xFFFE] + (memory[0xFFFF]<<8);
   brkv2 = memory[0x0202] + (memory[0x0203]<<8);

   /* Has someone taken control ? */
   if( brkv1 < 0xFFFC && brkv1 != 0 )
   {
      cpu.brk_ill = 0;
      return 1;
   }

   if( brkv2 < 512 || brkv2 >= 0xFF00U )
   {
      printf("Unset second order BRK vector\n");
      do_trace=1;
      return 1;
   }

   if( read_line_done == 0 )
   {
      printf("Loop in BRK processing ?\n");
      do_trace=1;
      return 1;
   }
   read_line_done=0;

   cpu.preg |= B_FLAG|X_FLAG;
   memory[0x100 + (cpu.sreg-- &0xFF)] = (cpu.pc>>8);
   memory[0x100 + (cpu.sreg-- &0xFF)] = cpu.pc;
   memory[0x100 + (cpu.sreg-- &0xFF)] = cpu.preg;

   memory[0xFD] = cpu.pc+1;
   memory[0xFE] = ((cpu.pc+1)>>8);

   cpu.pc = brkv2;
   return 1;
}

check_esc()
{
   int ch;
   if( keyhit() )
   {
      ch = inchar();
      if( ch == '\033' )
      {
         if( ena_ports == 1 ) do_trace=1;
	 else
	 {
            if( memory[0xFF] == 0xFF ) do_trace=1;

            memory[0xFF] = 0xFF;
	 }
      }

      /* else should put back in inchar() */
   }
}

/* This function is used to limit the speed of the emulator to 2MHz */
two_megas(resync_type)
int resync_type;
{
#ifdef TWOMEG

static clock_t started_at = 0;
static long icount = 0;

   clock_t now_tic;
   long cycles = inst_cnt - cpu.utimer - icount;

   if( resync_type == 0 )
   {
      start_timer(&started_at);
      icount += cycles;
      return;
   }

   if( resync_type == 1 || (resync_type == 2 && cycles > 500000L) )
   {
      now_tic = time_since(&started_at);
      if( now_tic < cycles/10000L )
         usleep( cycles/2 - now_tic*5000);

      now_tic = time_since(&started_at);
      icount += now_tic*10000L;
      started_at += now_tic;
   }
#endif
}

osword_call()
{
   unsigned int paramtbl = cpu.xreg + (cpu.yreg<<8);

   switch(cpu.acc)
   {
   case 0:  read_line(paramtbl); break;
   case 1:  read_time(paramtbl); break;

   default: bbcfatal("Unimplemented OSWORD call", 1); break;
   }
   return 1;
}

osbyte_call()
{
extern int vdubufcnt;
int t;

   switch( cpu.acc )
   {
   case 0x7E: cpu.xreg = 0xFF; memory[0xFF] = 0x00; break;
   case 0x82: cpu.xreg = 0x00; cpu.yreg = 0x00; break;
   case 0x83: cpu.xreg = 0x00; cpu.yreg = 0x08; break;
   case 0x84: cpu.xreg = (last_address&0xFF);
              cpu.yreg = (last_address>>8);
              break;
   case 0xA3: /* strcpy(memory+0x100, "BASIC\r"); */
              cpu.xreg=0; cpu.yreg=0;

              /* Must disable IO for tube rom */
              mem_rd[0xFE] = mem_wr[0xFE] = 0;	/* SHEILA */
              mem_rd[0xFD] = mem_wr[0xFD] = 0;	/* JIM */
              mem_rd[0xFC] = mem_wr[0xFC] = 0;	/* FRED */
              break;
   case 0xDA: t = vdubufcnt;
              vdubufcnt = ((vdubufcnt & cpu.yreg)|cpu.xreg);
              cpu.xreg = t;
              break;
   default:
      if( cpu.acc >= 0xA6 )
      {
         int nv = ((memory[0x190+cpu.acc]&cpu.yreg)^cpu.xreg);
	 cpu.xreg = memory[0x190+cpu.acc];
	 cpu.yreg = memory[0x191+cpu.acc];
	 memory[0x190+cpu.acc] = nv;
      }
      else
	 bbcfatal("Unimplemented OSBYTE call", 1);
   }
   return 1;
}

int 
read_line(param)
unsigned int param;
{
   char * bufp;
   int    maxlen;
   int    ch;  
   int    curlen = 0; 

   read_line_done =1;
   two_megas(1);

   if( param == 0 )
   {
      bufp = read_line_buf;
      maxlen = sizeof(read_line_buf);
   }
   else
   {
      bufp   = (char*) memory + memory[param] + (memory[param+1]<<8);
      maxlen = memory[param+2];
      cpu.preg &= -2;
   }

   for(;;)
   {
      ch = inchar();
      if( ch == '\033' )
      {
         if( param == 0 ) return -1;

         cpu.preg |= 1;
	 break;
      }

      if( ch == '\b' && curlen != 0 )
      {
         curlen--; outchar('\b'); outchar(' '); outchar('\b');
      }

      if( isprint(ch) || ch == '\r' )
      {
         if( curlen != maxlen )
         {
            bufp[curlen++] = ch;
            outchar(ch);
            if( ch == '\r' ) outchar('\n');
         }
         else
         {
            outchar('\007');
            continue;
         }
      }

      if( ch == '\r' )
         break;
   }
   two_megas(0);

   if( param == 0 ) { bufp[curlen-1] = '\0'; return curlen-1; }

   return cpu.yreg = curlen;
}

read_time(param)
unsigned int param;
{
   struct tm * t;
static long boot = -1;
static clock_t boot_tic;
   clock_t now_tic;
   unsigned long tmp;
static long lastcount = 0;

   if( boot == -1 )
   {
#ifdef __BCC__
      boot = 0;
#else
      time_t now;
      time(&now);
      t = localtime(&now);

      boot = t->tm_sec + 60*t->tm_min + 3600L*t->tm_hour;
      boot += 86400L * t->tm_yday;
#endif
      start_timer(&boot_tic);
   }

   two_megas(1);

   now_tic = time_since(&boot_tic) / 2; /* 200 HZ to 100 */

   tmp = boot * 100 + now_tic;

   {
      long diff = inst_cnt-cpu.utimer-lastcount;
      if( diff ) fprintf(stderr, "utimer=%ld\r\n", diff);
      lastcount += diff;
   }

   memory[param++] = (tmp & 0xFF); tmp>>=8;
   memory[param++] = (tmp & 0xFF); tmp>>=8;
   memory[param++] = (tmp & 0xFF); tmp>>=8;
   memory[param++] = (tmp & 0xFF); tmp>>=8; /* BBCBASIC is 32 bit so */
   memory[param++] = (tmp & 0xFF); tmp>>=8; /* <- will always be zero */
}

oscli_call()
{
static char * commands[] = {
   /*  0 */ "catalogue",
   /*  1 */ "cat",
   /*  2 */ "fx",
   /*  3 */ "|",
   /*  4 */ "/",
   /*  5 */ "run",
   /*  6 */ "basic",
   /*  7 */ "load",
   /*  8 */ "save",
   /*  9 */ "exec",
   /* 10 */ "key",
   /* 11 */ "help",
   /* 12 */ "rom",
   /* 13 */ "tape",
   /* 14 */ "motor",
   /* 15 */ "opt",
   /* 16 */ "tv",
   /* 17 */ "code",
   /* 18 */ "line",
   /* 19 */ "bye",
   /* 20 */ "system",
   /* 21 */ "memdump",
   /* 22 */ "monitor",
   0
};
   char buf[128];
   char *d, *s;
   char ** cmd = commands;
   int cmdno= -1;

   s = (char*)memory + cpu.xreg + (cpu.yreg<<8);
   d = buf;
   while(*s != '\r' && *s && d < buf+sizeof(buf)-1)
      *d++ = *s++;
   *d = '\0';
   while(d>buf && d[-1] == ' ' )
      *--d = '\0';

   for(d=buf; *d; d++)
      if( isupper(*d) ) *d = tolower(*d);

   while(*cmd)
   {
      for(d=buf; *d == ' ' || *d == '*'; d++) ;
      for(s= *cmd; *d && *s == *d; s++,d++) ;
      if( *s == 0 )
      {
         if( !isalpha(*d) || !isalpha(**cmd) ) break;
      }
      if( *d == '.' )
      {
         d++; break;
      }
      cmd++;
   }
   cmdno = cmd-commands;

   switch(cmdno)
   {
   case 0: case 1:
      system("/bin/ls -C *.bbc | /usr/bin/sed 's/$/\r/'");
      break;

   case 2:
      cpu.acc = atoi(d);
      cpu.xreg = cpu.yreg = 0;
      d = strchr(d, ',');
      if( d )
      {
         cpu.xreg = atoi(d+1);
         d = strchr(d+1, ',');
         if( d )
            cpu.yreg = atoi(d+1);
      }
      return osbyte_call();

   case 3:
      break;

   case 6:
      exec_bbc_rom();
      break;

   case 11:
      printf("BBC OS Faker 1.0\n");
      break;

   case 12:
      cpu.acc = 0x8D;
      if(0) {
   case 13:
         cpu.acc = 0x8C;
      } if(0) {
   case 14:
         cpu.acc = 0x89;
      } if(0) {
   case 15:
         cpu.acc = 0x8B;
      } if(0) {
   case 16:
         cpu.acc = 0x90;
      } if(0) {
   case 17:
         cpu.acc = 0x88;
      }
      cpu.xreg = atoi(d);
      d = strchr(d, ',');
      if( d )
         cpu.yreg = atoi(d+1);
      else
         cpu.yreg = 0;
      return osbyte_call();

   case 19: case 20:
      term_screen();
      hex_counters();
      exit(0);

   case 21:
      {
	 FILE * fd= fopen("BBC_memory", "wb");
	 if( fd )
	 {
	    fwrite(memory, 64, 1024, fd);
	    fclose(fd);
	 }
	 else bbcfatal("Cannot open dump file");
	 break;
      }
   case 22:
      do_trace=2;
      break;

   case 23:
      for(d=buf; *d == ' ' || *d == '*'; d++) ;

      if( !is_other && system(d) == 0 )
         return 1;
      return bbcfatal("Bad command", 0);

   default: return bbcfatal("Command not implemented", 0);
   }
   return 1;
}

osfile_call()
{
   unsigned char * param;
   unsigned char * fname;
   int  bbcfile;
   char fbuf[80];
   char * p;
   unsigned int fptr;

   param = memory + cpu.xreg + (cpu.yreg<<8);
   fname = memory + param[0] + (param[1]<<8);

   for(p=fbuf; p < fbuf+sizeof(fbuf)-5 && *fname != '\r';)
   {
      if( islower(*fname) )
         *p++ = *fname++ -'a'+'A';
      else if( isupper(*fname) )
         *p++ = *fname++ -'A'+'a';
      else if( isdigit(*fname) || strchr("_+=,:;", *fname) )
         *p++ = *fname++;
      else if( !is_other && *fname == '.' )
         *p++ = *fname++;
      else
         fname++;
   }
   *p = '\0';
   p = strrchr(fbuf, '.');
   if( p == 0 )
   {
      strcat(fbuf, ".bbc");
      bbcfile = 1;
   }
   else if( strcmp(p, ".bbc") == 0)
      bbcfile = 1;
   else bbcfile = 0;

   switch(cpu.acc)
   {
   case 0:    if( os_savefile(fbuf, param, bbcfile) ) break;
              return bbcfatal("Cannot open file", 0);
/*
   case 1: case 2: case 3: case 4:
              os_modefile(fbuf, param, bbcfile); break;
   case 6:    os_deletefile(fbuf, param, bbcfile); break;
*/
   case 0xFF: if( os_loadfile(fbuf, param, bbcfile) ) break;
              return bbcfatal("File not found", 0);
   default:   cpu.acc = 0; break;
   }
   return 1;
}

os_savefile(fname, param, bbcfile)
unsigned char *fname, *param;
int bbcfile;
{
   FILE * fd;
   long foffset, feofile;

   fd = fopen(fname, "wb");
   if( fd == 0 ) return 0;

   if( bbcfile )
   {
      fwrite("bbc\0", 4, 1, fd);

      fputc(param[3], fd); /* Load address */
      fputc(param[2], fd);
      fputc(param[7], fd); /* Execute address */
      fputc(param[6], fd);
   }

   foffset = ((param[0xB]<<8)&0xFF00) + (param[0xA]&0xFF);
   feofile = ((param[0xF]<<8)&0xFF00) + (param[0xE]&0xFF);

   while( foffset <= feofile )
      fputc(memory[foffset++], fd);

   fclose(fd);
   return 1;
}

os_loadfile(fname, param, bbcfile)
unsigned char *fname, *param;
int bbcfile;
{
   FILE * fd;
   long foffset;
   char ibuf[80];
   int ch;

   fd = fopen(fname, "rb");

   if( fd == 0 ) return 0;

   if( bbcfile )
   {
      fread(ibuf, 8, 1, fd);

      if( memcmp( ibuf, "bbc\0", 4) != 0 )
      {
         bbcfile = 0;
         rewind(fd);
      }
/*
      param[3], fd);   Load address 
      param[2], fd);
      param[7], fd);   Execute address 
      param[6], fd);
*/
   }

   if( !bbcfile && param[6] != 0 )
   {
      /* Haven't got a load address from anywhere so can't load */
      fclose(fd);
      return 0;
   }

   if( param[6] != 0 )
   {
      foffset = ((ibuf[0x4]<<8)&0xFF00) + (ibuf[0x5]&0xFF);
   }
   else
   {
      foffset = ((param[0x3]<<8)&0xFF00) + (param[0x2]&0xFF);
   }

   while( foffset != 0x10000L && (ch = fgetc(fd)) != EOF)
      memory[foffset++] = ch;

   fclose(fd);
   return 1;
}

hex_counters()
{
   long tot = 0;
   long max = 0;
   int i;
   long j;
   for(i=0; i<256; i++)
   {tot += counters[i]; if( counters[i] > max ) max = counters[i]; }

   if( tot == 0 ) return;
   /* max = 99; /* */

   for(tot = 0, i=0; i<256; i++)
   {
      if( (i&0xF) == 0 ) printf("%02x:", i);
      j = counters[i] *99/max; tot += j;
      printf(" %2ld", j );
      if( (i&0xF) == 0xF ) printf("\r\n");
   }
   printf("Total %ld\r\n", tot);
}
