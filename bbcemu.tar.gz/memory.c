
#include "mc6502.h"

long counters[256];

#ifdef DATA16
/* This is just a stub for a tiny machine */
unsigned char mem[49152+512];
#else /* To end of file */

extern int do_trace;
unsigned char memory[65536];

int mem_rd[256], mem_wr[256], mem_ex[256];

/* JIM */
int jim_page = 0;
unsigned char jim_ram[65536];

/* SHEILA */
ubyte ROM_select = 0x1F;
ubyte serial_ula_value;
ubyte video_ula_control = 0;
ubyte video_ula_pallet[16];
ubyte video_chip_sel = 0;
ubyte video_chip_reg[18];

/* MEMORY */
void tracemem();

/* Function to read byte from memory */
read_mem(location)
unsigned int location;
{
   if( do_trace ) tracemem("READ", location, -1);
   switch(-mem_rd[location>>8])
   {
   case 2:  /* SHEILA */
            return read_sheila(location & 0xFF);
   case 3:  /* JIM  */
            return jim_ram[jim_page + (location&0xFF)];
   case 4:  /* FRED */
            if( location == 0xFCFF ) return (jim_page>>8);

   case 1:  return 0xFF;
   default: return memory[location];
   }
}

/* Just like read mem but for the opcode and args only */
read_exe(location)
unsigned int location;
{
   if( do_trace ) tracemem("EXEC", location, -1);
   switch(-mem_ex[location>>8])
   {
   case 2:  /* SHEILA */
            return read_sheila(location & 0xFF);
   case 3:  /* JIM  */
            return jim_ram[jim_page + (location&0xFF)];
   case 4:  /* FRED */
            if( location == 0xFCFF ) return (jim_page>>8);

   case 1:  return 0xFF;
   default: return memory[location];
   }
}

/* Write to any memory location */
write_mem(location, value)
unsigned int location, value;
{
   if( do_trace ) tracemem("WRITE", location, value);
   switch(-mem_wr[location>>8])
   {
   case 2:  /* SHEILA */
            return write_sheila(location & 0xFF);
   case 3:  /* JIM  */
            jim_ram[jim_page + (location&0xFF)] = value; break;
   case 4:  /* FRED */
            if( location == 0xFCFF ) jim_page = (value<<8);

   case 1:  break;
   default: memory[location] = value; break;
   }
}

read_sheila(location)
int location;
{
   if( location & 0xC0 ) switch(location>>5)
   {
   case 2: /* SYSTEM VIA */
           return read_via(0, location&0xF);
   case 3: /* USER VIA */
           return read_via(1, location&0xF);
   case 4: /* FDC */
           break;
   case 5: /* ECONET */
           break;
   case 6: /* ADC */
           break;
   case 7: /* TUBE */
	   return 0;
   	   break;
   }
   else if( location & 0xF0 ) switch(location>>4)
   {
   case 1: /* Serial ULA */
           return serial_ula_value;
   case 2: /* Video ULA */
	   if((location&1) == 0) return video_ula_control;
           return 0xFF;
   case 3: /* Paged ROM selector */
           return 0xFF;	/* Write only */
   }
   else switch(location & 9)
   {
   case 0: /* Video control */
           return video_chip_sel | 0xE0;
   case 1: /* Video data */
           if( video_chip_sel >= 14 && video_chip_sel <= 17 )
	      return video_chip_reg[video_chip_sel];
	   else
	      return 0xFF;
   case 8: /* Serial contol */
   case 9: /* Serial data */
      break;
   }

   /* If no such device */
   return 0xFF;
}

write_sheila(location, value)
int location, value;
{
   if( location & 0xC0 ) switch(location>>5)
   {
   case 2: /* SYSTEM VIA */
	   write_via(0, location&0xF, value);
           return;
   case 3: /* USER VIA */
	   write_via(1, location&0xF, value);
           return;
   case 4: /* FDC */
           break;
   case 5: /* ECONET */
           break;
   case 6: /* ADC */
           break;
   case 7: /* TUBE */
   	   break;
   }
   else if( location & 0xF0 ) switch(location>>4)
   {
   case 1: /* Serial ULA */
	   serial_ula_value = value;
           return;
   case 2: /* Video ULA */
	   if((location&1) == 0) video_ula_control = value;
	   else                  video_ula_pallet[value>>4] = (value&0xF);
           return;
   case 3: /* Paged ROM selector */
	   write_rom_select(value);
           return;
   }
   else switch(location & 9)
   {
   case 0: /* Video control */
           video_chip_sel = (value & 0x1F);
	   return;
   case 1: /* Video data */
           if( video_chip_sel <= 15 )
	   {
	      video_chip_reg[video_chip_sel] = value;
	      return;
           }
   case 8: /* Serial contol */
   case 9: /* Serial data */
      break;
   }

   /* If no such device */
   return;
}

write_rom_select(value)
{
   if( ROM_select == 0x1F )
   {
      /* First time, write protect the ROMS */
      int i;
      for(i=0x80; i<0xFC; i++) mem_wr[i] = -1;
      mem_wr[0xFF] = -1;
   }
   ROM_select = (value&0xF);
   if( ROM_select != 15 )
   {
      int i;
      for(i=0x80; i<0xC0; i++) mem_rd[i] = -1;
   }
   else
   {
      int i;
      for(i=0x80; i<0xC0; i++) mem_rd[i] = 0;
      /* Someone is being sneaky, ok lets play along ... */
      if( value == 0x1F )
      {
	 for(i=0x80; i<0xFC; i++) mem_wr[i] = 0;
	 mem_wr[0xFF] = 0;
	 ROM_select = 0x1F;
      }
   }
}

void tracemem(op, locn, value)
char * op;
unsigned int locn;
int value;
{
   char * page;
   char * device = 0;
   char * offname = 0;
   int offt = locn&0xFF;

   if( locn & 0x8000) page = "ROM"; else page = "RAM";

   switch(locn>>8)
   {
   case 0xFC: page = "FRED";
              if( offt == 0xFF ) { device = "JIM's PAGE register"; offt=0; }
              break;
   case 0xFD: page = "JIM";
              break;
   case 0xFE: page = "SHEILA";
   	      switch(offt>>4)
	      {
	      case 0: if( offt & 0x8 ) device = "Serial chip";
	              else             device = "Video chip";
		      offt &= 7;
		      break;
	      case 1: device = "Serial ULA"; break;
	      case 2: device = "Video ULA"; break;
	      case 3: device = "ROM selector"; offt= -1; break;
	      case 4:
	      case 5: device = "SYSTEM VIA";
	              if(0) {
	      case 6:
	      case 7: device = "USER VIA";
	              }
		      switch(offt&0xF)
		      {
		      case 0: offname="I/ORB"; break;
		      case 1: offname="I/ORA"; break;
		      case 2: offname="DDRB"; break;
		      case 3: offname="DDRA"; break;
		      case 4: offname="T1C-L"; break;
		      case 5: offname="T1C-H"; break;
		      case 6: offname="T1L-L"; break;
		      case 7: offname="T1L-H"; break;
		      case 8: offname="T2C-L"; break;
		      case 9: offname="T2C-H"; break;
		      case 10: offname="SR"; break;
		      case 11: offname="ACR"; break;
		      case 12: offname="PCR"; break;
		      case 13: offname="IFR"; break;
		      case 14: offname="IER"; break;
		      case 15: offname="RAW-A"; break;
		      }
		      break;
	      case 8: 
	      case 9: device = "FDC"; break;
	      case 10: 
	      case 11: device = "ECONET Controller"; break;
	      case 12:
	      case 13: device = "ADC"; break;
	      case 14: 
	      case 15: device = "TUBE Interface"; break;
	      }
	      if(offt>0) offt &= 0xF;
              break;

   default: offt = locn; break;
   }

   printf("Memory %s at 0x%04x - %s", op, locn, page);
   if( device ) printf(" - %s", device);
   if( offname )        printf("[%s]", offname);
   else if( offt >= 0 ) printf("[0x%x]", offt);
   if( value >= 0 ) printf(" = 0x%02x", value);
   printf("\n");
}
#endif
