
#include <stdio.h>
#include <ctype.h>
#include "mc6502.h"

extern char read_line_buf[];
extern int do_trace;

static unsigned int current_address;
static int number_base = 16;

monitor()
{
   char * ptr;

   current_address = cpu.pc;
   do_trace=0;

   cpu_status();
   if( memory[cpu.pc] == 0 && cpu.pc < 0xFF00 )
   {
      printf(": ");
      disass("- 1");
      current_address = cpu.pc;
   }

   if( !isatty(1) ) { term_screen(); exit(0); }

   for(;;)
   {
      printf(".");
      if( read_line(0) <= 0 ) continue;

      /* Force most to upper case */
      for(ptr=read_line_buf; *ptr; ptr++)
      {
         if(*ptr=='"') do { ptr++; } while(*ptr && *ptr != '"');
	 if( islower(*ptr) ) *ptr = toupper(*ptr);
      }

      ptr = read_line_buf;
      while( *ptr == ' ' ) ptr++;
      switch(*ptr++)
      {
      case 0:   continue;
      case 'G': getnum(&ptr, &cpu.pc); return;
      case 'T': do_trace=1;
                getnum(&ptr, &do_trace);
                return;
      case 'X': term_screen(); exit(1);
      case 'B': return bbcfatal("Returning to basic", 0);

      case 'D': disass(ptr); break;
      case 'M': memdump(ptr); break;
      case 'F': fill_mem(ptr); break;
      case 'R': if( set_regs(ptr) == 1 ) return; break;

      case 'N': set_base(ptr); break;

      case 'Z': reset_6502();
		if( memory[0xFFFF] == 0 ) cpu.brk_ill = 1;
                cpu_status();
                break;

      default: printf("??\n"); break;
      }
   }
}

cpu_status()
{
   unsigned int c, a=cpu.pc;

   if( cpu.ir >= 0 && cpu.ir < 256 ) c = cpu.ir; else c=memory[a];

   printf(": %-26s ", disline(&a, c, memory[a+1], memory[a+2]));

   printf("IR %03x ACC %02x XR %02x YR %02x SP %02x FL %02x\n",
           cpu.ir & 0xFFF, cpu.acc, cpu.xreg, cpu.yreg, cpu.sreg, cpu.preg);
}

disass(ptr)
char * ptr;
{
   int count = 20;
   int line,i;
   int b1, b2, b3, iserr;

   getnum(&ptr, &current_address);
   getnum(&ptr, &count);

   for(line=0; line<count; line++)
   {
      current_address &= 0xFFFF;
      b1 = memory[current_address];
      b2 = memory[current_address+1];
      b3 = memory[current_address+2];

      iserr=0;
      if( b1 == 0 && b3>='A' && b3 <= 'Z' )
      {
         for(i=2; i<50; i++)
	 {
	    if( isprint(memory[current_address+i]) ) continue;
	    if( memory[current_address+i] == 0 )
	       iserr = 1;
	    break;
	 }
      }
      if( iserr )
      {
         printf("%04x 00 %02x ... err %d,\"", current_address, b2, b2);
	 current_address+=2;
	 while(b1 = memory[current_address])
	 {
	    if( isprint(b1) ) putchar(b1);
	    else break;
	    current_address++;
	 }
	 if( b1 == 0 ) current_address++;
	 else printf("\\c");
	 printf("\"\n");
      }
      else if( (b1&0xF) == 3 )
      {
	 static char * osentry[16] =
	 { "CLI", "BYTE","WORD","WRCH",
	   "RDCH","FILE","ARGS","BGET",
	   "BPUT","GBPB","FIND","QUIT",
	   "BASIC",0,0,0
	 };

         printf("%04x %02x        OSbbc ", current_address, b1);
	 b1>>=4;
	 if( osentry[b1] )
	    printf("%s\n", osentry[b1]);
	 else
	    printf("%d\n", b1);
         current_address++;
      }
      else
         printf("%s\n", disline(&current_address, b1, b2, b3));

      if( current_address -3 > current_address ) break;
   }
}

memdump(ptr)
char * ptr;
{
   int count = 128;
   int i,j;

#define rmem(x) memory[((x)+current_address)&0xFFFF]

   getnum(&ptr, &current_address);
   getnum(&ptr, &count);

   for(i=0; i<count; i+=16)
   {
      printf("%04x:", current_address);
      for(j=0; j<16; j++)
         printf(" %02x", rmem(j));
      printf("  ");
      for(j=0; j<16; j++)
	 if( rmem(j) >= ' ' && rmem(j) <= '~' )
            putchar(rmem(j));
	 else
	    putchar('.');
      putchar('\n');
      current_address += 16;
      current_address &= 0xFFFF;
   }

#undef rmem
}

set_regs(ptr)
char * ptr;
{
   int rv = 0;
   while(*ptr)
   {
      int rg=0, val;
      while( *ptr && *ptr <= ' ' ) ptr++;
      rg=*ptr;
      while( *ptr && *ptr > ' ' && *ptr != '=' ) ptr++;
      if(*ptr) ptr++;

      if( getnum(&ptr, &val) )
      switch(rg)
      {
      case 'A': cpu.acc = val; break;
      case 'X': cpu.xreg = val; break;
      case 'Y': cpu.yreg = val; break;
      case 'S': cpu.sreg = val; break;

      case 'F': cpu.preg = val; break;
      case 'P': cpu.pc = val; break;
      case 'I': cpu.ir = val; break;

      case 'G': rv=1; break;
      }
   }
   if(rv) return rv;
   cpu_status();
}

fill_mem(ptr)
char * ptr;
{
   int count = 0;
   int fillb = 0;
   int i,j;

   getnum(&ptr, &current_address);
   getnum(&ptr, &count);
   getnum(&ptr, &fillb);

   if( count )
      memset(memory+current_address, fillb, count);
}

/**************************************************************************/

set_base(ptr)
{
   int obase = number_base;
   int nbase;
   number_base = 10;

   if( getnum(&ptr, &nbase) )
   {
      if( nbase < 2 || nbase > 36 )
         printf("Can't use that base\n");
      else
         obase = nbase;
   }
   else printf("Current base is %d\n", obase);

   number_base = obase;
}

int
getnum(numptr, valptr)
char ** numptr;
unsigned int * valptr;
{
   char * ptr = *numptr;
   unsigned int val = 0;
   int base = number_base;
   int flg = 0;

   while( *ptr && *ptr <= ' ' ) ptr++;
   switch(*ptr)
   {
   case '$': case '&': case 'X':
      base=16; ptr++; break;
   case '#':
      base=10; ptr++; break;
   case '%':
      base=2; ptr++; break;
   case '0':
      if( ptr[1] == 'X' ) { base=16; ptr+=2; }
      break;
   case '-':
      *numptr = ptr+1;
      return 0;
   }

   while(*ptr)
   {
      int d = -1, ch;
      ch = *ptr;
      if( ch >= '0' && ch <= '9' ) d = ch - '0';
      if( ch >= 'a' && ch <= 'z' ) d = ch - 'a' + 10;
      if( ch >= 'A' && ch <= 'Z' ) d = ch - 'A' + 10;

      if( d>=0  && d<base )
      {
         val = val * base + d;
	 ptr++;
	 flg=1;
      }
      else
         break;
   }
   if( flg )
   {
      *numptr = ptr;
      if(valptr) *valptr = val;
      else return val;
   }
   return flg;
}


/****************************************************************************/

char * opcode[] = {
"brk oraI        tsbDoraDaslDrmbYphp oraCaslA    tsbJoraJaslJbbrX",
"bplBoraHoraG    trbDoraEaslErmbYclc oraLina     trbJoraKaslKbbrX",
"jsrJandI        bitDandDrolDrmbYplp andCrolA    bitJandJrolJbbrX",
"bmiBandHandG    bitEandErolErmbYsec andLdea     bitKandKrolKbbrX",
"rti eorI            eorDlsrDrmbYpha eorClsrA    jmpJeorJlsrJbbrX",
"bvcBeorHeorG        eorElsrErmbYcli eorLphy         eorKlsrKbbrX",
"rts adcI        stzDadcDrorDrmbYpla adcCrorA    jmpMadcJrorJbbrX",
"bvsBadcHadcG    stzEadcErorErmbYsei adcLply     jmpNadcKrorKbbrX",
"braBstaI        styDstaDstxDsmbYdey bitCtxa     styJstaJstxJbbsX",
"bccBstaHstaG    styEstaEstxFsmbYtya staLtxs     stzJstaKstzKbbsX",
"ldyCldaIldxC    ldyDldaDldxDsmbYtay ldaCtax     ldyJldaJldxJbbsX",
"bcsBldaHldaG    ldyEldaEldxFsmbYclv ldaLtsx     ldyKldaKldxLbbsX",
"cpyCcmpI        cpyDcmpDdecDsmbYiny cmpCdex     cpyJcmpJdecJbbsX",
"bneBcmpHcmpG        cmpEdecEsmbYcld cmpLphx         cmpKdecKbbsX",
"cpxCsbcI        cpxDsbcDincDsmbYinx sbcCnop     cpxJsbcJincJbbsX",
"beqBsbcHsbcG        sbcEincEsmbYsed sbcLplx         sbcKincKbbsX"
};

char * disline(address, code, dat1, dat2)
unsigned int *address;
int code, dat1, dat2;
{
static char opstr[32];
   char buf0[3], buf1[3], buf2[3];
   char * ptr = opcode[(code>>4)&0xF]+4*(code&0xF);

   if( code < 0 || code > 255 ) return "**";

   sprintf(buf0, "%02x", code);
   *buf1 = *buf2 = '\0';
   if( address ) sprintf(opstr, "%04x ", *address);
   else          strcpy(opstr, "     ");

   if(ptr[3]>= 'B' || code==0)
   {
      if( dat1 < 0 || dat1 > 255 ) strcpy(buf1, "**");
      else sprintf(buf1, "%02x", dat1);

      if((ptr[3] >= 'J' && ptr[3] <= 'X') || code==0)
      {
	 if( dat2 < 0 || dat2 > 255 ) strcpy(buf2, "**");
	 else sprintf(buf2, "%02x", dat2);
      }
   }
   if( address )
   {
      if(ptr[3]>= 'B')
      {
         if(ptr[3] >= 'J' && ptr[3] <= 'X' )
	    (*address)+=3;
	 else
	    (*address)+=2;
      }
      else
         (*address)++;
   }

   sprintf(opstr+5, "%2s %2s %2s  %.3s ", buf0, buf1, buf2, ptr);

   switch(ptr[3])
   {
   default:  opstr[18] = 0; break;
   case 'A': sprintf(opstr+19, "a");
	     break;
   case 'B': if( dat1 < 0 || dat1 > 255 )
	         sprintf(opstr+19, "$****");
	     else
	     {
   	         int tmp = (char)dat1;
		 if( !address )
		    sprintf(opstr+19, ".%s%d", tmp<-2?"":"+", tmp+2);
		 else
	            sprintf(opstr+19, "$%04x", *address+tmp);
	     }
	     break;
   case 'C': sprintf(opstr+19, "#$%2s", buf1);
	     break;
   case 'D': sprintf(opstr+19, "$%2s", buf1);
	     break;
   case 'E': sprintf(opstr+19, "$%2s,x", buf1);
	     break;
   case 'F': sprintf(opstr+19, "$%2s,y", buf1);
	     break;
   case 'G': sprintf(opstr+19, "($%2s)", buf1);
	     break;
   case 'H': sprintf(opstr+19, "($%2s),y", buf1);
	     break;
   case 'I': sprintf(opstr+19, "($%2s,x)", buf1);
	     break;
   case 'J': sprintf(opstr+19, "$%2s%2s", buf2, buf1);
	     break;
   case 'K': sprintf(opstr+19, "$%2s%2s,x", buf2, buf1);
	     break;
   case 'L': sprintf(opstr+19, "$%2s%2s,y", buf2, buf1);
	     break;
   case 'M': sprintf(opstr+19, "($%2s%2s)", buf2, buf1);
	     break;
   case 'N': sprintf(opstr+19, "($%2s%2s,x)", buf2, buf1);
	     break;
   case 'X': sprintf(opstr+19, "%d,$%2s,.%s%d", (code>>4)&7, buf1,
                               (char)dat2<-2?"":"+", 2+(char)dat2);
	     break;
   case 'Y': sprintf(opstr+19, "%d,$%2s", (code>>4)&7, buf1);
	     break;
   }
   return opstr+(address==0)*5;
}
