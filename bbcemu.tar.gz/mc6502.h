
typedef unsigned short uword;
typedef unsigned char ubyte;

extern struct regs
{
   union { uword _pc; ubyte _pcb[2]; } un;
   ubyte  acc;
   ubyte  xreg;
   ubyte  yreg;
   ubyte  sreg;
   ubyte  preg;
   int    ir;
   long   utimer;
   ubyte  brk_ill;
   ubyte  int_pending;
}
   cpu;

#define pc  un._pc
#define pcl un._pcb[_LOWBYTE]
#define pch un._pcb[_HI_BYTE]

#ifdef __BCC__
#define DATA16
#endif

#ifndef DATA16
extern unsigned char memory[65536];
extern unsigned char mflags[65536];
extern int mem_rd[256], mem_wr[256], mem_ex[256];

#else
extern unsigned char mem[49152+512];
#define memory	(mem+512)
#endif

extern long counters[256];

#define C_FLAG 0x01
#define Z_FLAG 0x02
#define I_FLAG 0x04
#define D_FLAG 0x08
#define B_FLAG 0x10
#define X_FLAG 0x20
#define V_FLAG 0x40
#define N_FLAG 0x80

#ifdef __STDC__
char * disline(unsigned int *, int, int, int);
#else
char * disline();
#endif

#ifdef LITTLENDIAN
#define _LOWBYTE 0
#define _HI_BYTE 1
#endif
#ifdef BIGENDIAN
#define _LOWBYTE 1
#define _HI_BYTE 0
#endif

