
#define VIA_REG_B	0
#define VIA_REG_A	1
#define VIA_DDR_B	2
#define VIA_DDR_A	3
#define VIA_T1CL	4
#define VIA_T1CH	5
#define VIA_T1LL	6
#define VIA_T1LH	7
#define VIA_T2CL	8
#define VIA_T2CH	9
#define VIA_SREG	10
#define VIA_ACR 	11
#define VIA_PCR 	12
#define VIA_IFR 	13
#define VIA_IEF 	14
#define VIA_RAW_A 	15

struct via {
   unsigned char ira;
   unsigned char irb;

   unsigned char ora, line_a, ddr_a;
   unsigned char orb, line_b, ddr_b;

   unsigned short t1_c, t2_c, t1_l;

   unsigned char sr;

   unsigned char acr;
   unsigned char pcr;
   unsigned char ifr;
   unsigned char ier;

   long last_update;
};
