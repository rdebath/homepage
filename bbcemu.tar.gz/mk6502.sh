
main() {
cat > mc6502.c <<\!
/*
 This file contains the emulator for the 6502 or 65c02 processor.

 This emulator is designed to emulate all the documented features of the
 processor plus a number of additional items.
 
 It does not emulate any illegal or undocumented instructions, these
 cause the emulator to drop out. The emulator doesn't emulate some of
 the 'well known' features of the 6502 either: there is no extra memory
 write for the read/modify/write instructions, branches and returns do
 not access the first byte following the instruction even if the branch
 is taken, the extra cycles for accesses to another page are not
 calculated nor are the the accesses these cycles represent executed.

 Currently the 'rmb,smb,bbr,bbs' instructions are not implemented and
 ADC and SBC are not correct in decimal mode.

 In addition to all illegal instructions causing the emulator to drop
 out the BRK instruction can be switched to do the same thing if the
 flag 'brk_ill' is set or the vector for BRK at $FFFE/F is >=$FFFC.
 */

!

   part1 >>mc6502.c
   part2 >>mc6502.c
   part3 >>mc6502.c

   indent -orig -bl -bli0 -nce -cli0 -nbc -ip0 -i3 -di6 mc6502.c
   rv=$?
   [ $rv = 0 ] && rm mc6502.c~
   exit $rv
}

part2() {
# This table has been sorted by frequency of use of the instructions, this
# helps the CPU's cache keep 'useful' data because the most frequently used
# code is in one place. It improves execution times by around 2-3% on some
# CPUs
(
cat <<\!
36 18  0  2 f0  - beq $1234     
23  9  0  2 c9  - cmp #$d1      
 0  1  8  3 85  - sta $d1       
 0  8  1  3 a5  - lda $d1       
16  8  8  5 26  - rol $d1       
 0 11  1  5 b1  - lda ($d1),y   
 2  3  3  2 c8  - iny           
35 18  0  2 d0  - bne $1234     
28 16  0  6 20  - jsr $d2d1     
 9  0  0  6 60  - rts           
33 18  0  2 90  - bcc $1234     
21  8  1  3 65  - adc $d1       
34 18  0  2 b0  - bcs $1234     
 3  3  3  2 88  - dey           
 0  2  8  3 86  - stx $d1       
24  9  0  2 e0  - cpx #$d1      
 0  9  3  2 a0  - ldy #$d1      
 0  1 11  6 91  - sta ($d1),y   
 0  8  2  3 a6  - ldx $d1       
 0  8  3  3 a4  - ldy $d1       
 0  3  8  3 84  - sty $d1       
 0 13  1  4 b9  - lda $d2d1,y   
14  1  1  2 0a  - asl a         
 0  1  6  3 48  - pha           
 0  6  1  4 68  - pla           
18  8  1  3 05  - ora $d1       
29 18  0  2 30  - bmi $1234     
 5  0  0  2 18  - clc           
 0  3  1  2 98  - tya           
 0  1  3  2 a8  - tay           
25  8  0  3 c4  - cpy $d1       
 2  8  8  5 e6  - inc $d1       
 0  9  1  2 a9  - lda #$d1      
22  9  1  2 e9  - sbc #$d1      
 6  0  0  2 38  - sec           
 2  2  2  2 e8  - inx           
14  8  8  5 06  - asl $d1       
 0  1 14  5 9d  - sta $d2d1,x   
 0  9  2  2 a2  - ldx #$d1      
30 16  0  3 4c  - jmp $d2d1     
 0  2  1  2 8a  - txa           
 0  1  2  2 aa  - tax           
 3  8  8  5 c6  - dec $d1       
15  8  8  5 46  - lsr $d1       
17  8  8  5 66  - ror $d1       
21  9  1  2 69  - adc #$d1      
 0  1 12  4 95  - sta $d1,x     
27 18  0  2 10  - bpl $1234     
26  8  0  3 24  - bit $d1       
 0  1 13  5 99  - sta $d2d1,y   
 0 14  1  4 bd  - lda $d2d1,x   
 3  2  2  2 ca  - dex           
19  9  1  2 29  - and #$d1      
16  1  1  2 2a  - rol a         
21 14  1  4 7d  - adc $d2d1,x   
 0 12  1  4 b5  - lda $d1,x     
23  8  0  3 c5  - cmp $d1       
22 14  1  4 fd  - sbc $d2d1,x   
20  8  1  3 45  - eor $d1       
20 14  1  4 5d  - eor $d2d1,x   
 0 14  3  4 bc  - ldy $d2d1,x   
25  9  0  2 c0  - cpy #$d1      
23 11  0  5 d1  - cmp ($d1),y   
23 14  0  4 dd  - cmp $d2d1,x   
 4 19  0  7 00  - brk           
18  7  1  6 01  - ora ($d1,x)   
 1  0  0  0 02 =- mul           # from 65C29 ?
 1  0  0  0 03  -               
37  8  8  5 04 +- tsb $d1       
 1  0  0  0 07 +- rmb 0,$d1
 0  5  6  3 08  - php           
18  9  1  2 09  - ora #$d1      
 1  0  0  0 0b  -               
37 10 10  6 0c +- tsb $d2d1     
18 10  1  4 0d  - ora $d2d1     
14 10 10  6 0e  - asl $d2d1     
 1  0  0  0 0f +- bbr 0,a,r     
18 11  1  5 11  - ora ($d1),y   
18 20  1  5 12 +- ora ($d1)     
 1  0  0  0 13  -               
38  8  8  5 14 +- trb $d1       
18 12  1  4 15  - ora $d1,x     
14 12 12  6 16  - asl $d1,x     
 1  0  0  0 17 +- rmb 1,$d1
18 13  1  4 19  - ora $d2d1,y   
 2  1  1  2 1a +- ina           
 1  0  0  0 1b  -               
38 10 10  6 1c +- trb $d2d1     
18 14  1  4 1d  - ora $d2d1,x   
14 14 14  7 1e  - asl $d2d1,x   
 1  0  0  0 1f +- bbr 1,a,r     
19  7  1  6 21  - and ($d1,x)   
 1  0  0  0 22  -               
 1  0  0  0 23  -               
19  8  1  3 25  - and $d1       
 1  0  0  0 27 +- rmb 2,$d1
 0  6  5  4 28  - plp           
 1  0  0  0 2b  -               
26 10  0  4 2c  - bit $d2d1     
19 10  1  4 2d  - and $d2d1     
16 10 10  6 2e  - rol $d2d1     
 1  0  0  0 2f +- bbr 2,a,r     
19 11  1  5 31  - and ($d1),y   
19 20  1  5 32 +- and ($d1)     
 1  0  0  0 33  -               
26 12  0  4 34 +- bit $d1,x     
19 12  1  4 35  - and $d1,x     
16 12 12  6 36  - rol $d1,x     
 1  0  0  0 37 +- rmb 3,$d1
19 13  1  4 39  - and $d2d1,y   
 3  1  1  2 3a +- dea           
 1  0  0  0 3b  -               
26 14  0  4 3c +- bit $d2d1,x   
19 14  1  4 3d  - and $d2d1,x   
16 14 14  7 3e  - rol $d2d1,x   
 1  0  0  0 3f +- bbr 3,a,r     
 7 19  0  6 40  - rti           
20  7  1  6 41  - eor ($d1,x)   
 1  0  0  0 42  -               
 1  0  0  0 43  -               
 1  0  0  0 44  -               
 1  0  0  0 47 +- rmb 4,$d1
20  9  1  2 49  - eor #$d1      
15  1  1  2 4a  - lsr a         
 1  0  0  0 4b  -               
20 10  1  4 4d  - eor $d2d1     
15 10 10  6 4e  - lsr $d2d1     
 1  0  0  0 4f +- bbr 4,a,r     
31 18  0  2 50  - bvc $1234     
20 11  1  5 51  - eor ($d1),y   
20 20  1  5 52 +- eor ($d1)     
 1  0  0  0 53  -               
 1  0  0  0 54  -               
20 12  1  4 55  - eor $d1,x     
15 12 12  6 56  - lsr $d1,x     
 1  0  0  0 57 +- rmb 5,$d1
 8  0  0  2 58  - cli           
20 13  1  4 59  - eor $d2d1,y   
 0  3  6  3 5a +- phy           
 1  0  0  0 5b  -               
 1  0  0  0 5c  -               
15 14 14  7 5e  - lsr $d2d1,x   
 1  0  0  0 5f +- bbr 5,a,r     
21  7  1  6 61  - adc ($d1,x)   
 1  0  0  0 62  -               
 1  0  0  0 63  -               
 0 21  8  3 64 +- stz $d1       
 1  0  0  0 67 +- rmb 6,$d1
17  1  1  2 6a  - ror a         
 1  0  0  0 6b  -               
30 17  0  5 6c  - jmp ($d2d1)   
21 10  1  4 6d  - adc $d2d1     
17 10 10  6 6e  - ror $d2d1     
 1  0  0  0 6f +- bbr 6,a,r     
32 18  0  2 70  - bvs $1234     
21 11  1  5 71  - adc ($d1),y   
21 20  1  5 72 +- adc ($d1)     
 1  0  0  0 73  -               
 0 21 12  4 74 +- stz $d1,x     
21 12  1  4 75  - adc $d1,x     
17 12 12  6 76  - ror $d1,x     
 1  0  0  0 77 +- rmb 7,$d1
10  0  0  2 78  - sei           
21 13  1  4 79  - adc $d2d1,y   
 0  6  3  4 7a +- ply           
 1  0  0  0 7b  -               
30 22  0  6 7c +- jmp ($d2d1,x) 
17 14 14  7 7e  - ror $d2d1,x   
 1  0  0  0 7f +- bbr 7,a,r     
39 18  0  2 80 +- bra $1234     
 0  1  7  6 81  - sta ($d1,x)   
 1  0  0  0 82  -               
 1  0  0  0 83  -               
 1  0  0  0 87 +- smb 0,$d1     
40  9  0  2 89 +- bit #$d1      
 1  0  0  0 8b  -               
 0  3 10  4 8c  - sty $d2d1     
 0  1 10  4 8d  - sta $d2d1     
 0  2 10  4 8e  - stx $d2d1     
 1  0  0  0 8f +- bbs 0,a,r     
 0  1 20  6 92 +- sta ($d1)     
 1  0  0  0 93  -               
 0  3 12  4 94  - sty $d1,x     
 0  2 15  4 96  - stx $d1,y     
 1  0  0  0 97 +- smb 1,$d1     
 0  2  4  2 9a  - txs           
 1  0  0  0 9b  -               
 0 21 10  4 9c +- stz $d2d1     
 0 21 14  5 9e +- stz $d2d1,x   
 1  0  0  0 9f +- bbs 1,a,r     
 0  7  1  6 a1  - lda ($d1,x)   
 1  0  0  0 a3  -               
 1  0  0  0 a7 +- smb 2,$d1     
 1  0  0  0 ab  -               
 0 10  3  4 ac  - ldy $d2d1     
 0 10  1  4 ad  - lda $d2d1     
 0 10  2  4 ae  - ldx $d2d1     
 1  0  0  0 af +- bbs 2,a,r     
 0 20  1  5 b2 +- lda ($d1)     
 1  0  0  0 b3  -               
 0 12  3  4 b4  - ldy $d1,x     
 0 15  2  4 b6  - ldx $d1,y     
 1  0  0  0 b7 +- smb 3,$d1     
11  0  0  2 b8  - clv           
 0  4  2  2 ba  - tsx           
 1  0  0  0 bb  -               
 0 13  2  4 be  - ldx $d2d1,y   
 1  0  0  0 bf +- bbs 3,a,r     
23  7  0  6 c1  - cmp ($d1,x)   
 1  0  0  0 c2  -               
 1  0  0  0 c3  -               
 1  0  0  0 c7 +- smb 4,$d1     
 1  0  0  0 cb  -               
25 10  0  4 cc  - cpy $d2d1     
23 10  0  4 cd  - cmp $d2d1     
 3 10 10  6 ce  - dec $d2d1     
 1  0  0  0 cf +- bbs 4,a,r     
23 20  0  5 d2 +- cmp ($d1)     
 1  0  0  0 d3  -               
 1  0  0  0 d4  -               
23 12  0  4 d5  - cmp $d1,x     
 3 12 12  6 d6  - dec $d1,x     
 1  0  0  0 d7 +- smb 5,$d1     
12  0  0  2 d8  - cld           
23 13  0  4 d9  - cmp $d2d1,y   
 0  2  6  3 da +- phx           
 1  0  0  0 db  -               
 1  0  0  0 dc  -               
 3 14 14  7 de  - dec $d2d1,x   
 1  0  0  0 df +- bbs 5,a,r     
22  7  1  6 e1  - sbc ($d1,x)   
 1  0  0  0 e2  -               
 1  0  0  0 e3  -               
24  8  0  3 e4  - cpx $d1       
22  8  1  3 e5  - sbc $d1       
 1  0  0  0 e7 +- smb 6,$d1     
 0  0  0  2 ea  - nop           
 1  0  0  0 eb  -               
24 10  0  4 ec  - cpx $d2d1     
22 10  1  4 ed  - sbc $d2d1     
 2 10 10  6 ee  - inc $d2d1     
 1  0  0  0 ef +- bbs 6,a,r     
22 11  1  5 f1  - sbc ($d1),y   
22 20  1  5 f2 +- sbc ($d1)     
 1  0  0  0 f3  -               
 1  0  0  0 f4  -               
22 12  1  4 f5  - sbc $d1,x     
 2 12 12  6 f6  - inc $d1,x     
 1  0  0  0 f7 +- smb 7,$d1     
13  0  0  2 f8  - sed           
22 13  1  4 f9  - sbc $d2d1,y   
 0  6  2  4 fa +- plx           
 1  0  0  0 fb  -               
 1  0  0  0 fc  -               
 2 14 14  7 fe  - inc $d2d1,x   
 1  0  0  0 ff +- bbs 7,a,r     
!
) | while read op rd wr cy oc plus cmd
do
# [ "$op" != "1" ] && {
# Others for testing ...
[ "$cmd" != "" ] && {
# {

   # Comment for illegals
   [ "$cmd" = "" ] && cmd=".byte 0x$oc"

   # Illegals don't inc PC
   [ "$op" = 1 ] && rd=19

   # Read/mod/write instructions, do CSE
   [ $rd = 8  -a $wr = 8  ] && wr=91
   [ $rd = 10 -a $wr = 10 ] && wr=90
   [ $rd = 12 -a $wr = 12 ] && wr=91
   [ $rd = 14 -a $wr = 14 ] && wr=90
   
   [ "$plus" = "-" ] || echo '#ifdef R65C02'

step=1
sed 's/  */ /g' <<!
      case 0x$oc: /* $cmd */
      {
	 register uword tp;
	 register uword ta;

!

case $rd in
 1) echo ' tp = A;' ;;
 2) echo ' tp = X;' ;;
 3) echo ' tp = Y;' ;;
 4) echo ' tp = S;' ;;
 5) echo ' write_preg(CPU, flags1, flags2, flags3); tp = (P|X_FLAG|B_FLAG);' ;;
 6) echo ' tp = M_read(++S+0x100);' ;;
 7) step=2; 
    cat <<!
	 tp = M_exe(PC+1)+X;
	 tp = M_read(ZP_read(tp)+(ZP_read(tp+1)<<8));
!
      ;;
 8) step=2; 
    cat <<!
	 ta = M_exe(PC+1);
	 tp = ZP_read(ta);
!
      ;;
 9) step=2; 
    cat <<!
	 tp = M_exe(PC+1);
!
      ;;
 10) step=3; 
    cat <<!
	ta = M_exe(PC+1)+(M_exe(PC+2)<<8);
	tp = M_read(ta);
!
      ;;
 11) step=2; 
    cat <<!
	tp = M_exe(PC+1);
	tp = ((ZP_read(tp)+(ZP_read(tp+1)<<8)+Y)&0xFFFF);
	tp = M_read(tp);
!
      ;;
 12) step=2; 
    cat <<!
	ta = M_exe(PC+1)+X;
	tp = ZP_read(ta);
!
      ;;
 13) step=3; 
    cat <<!
	tp = ((M_exe(PC+1)+(M_exe(PC+2)<<8)+Y)&0xFFFF);
	tp = M_read(tp);
!
      ;;
 14) step=3; 
    cat <<!
	ta = ((M_exe(PC+1)+(M_exe(PC+2)<<8)+X)&0xFFFF);
	tp = M_read(ta);
!
      ;;
 15) step=2; 
    cat <<!
	tp = ZP_read(M_exe(PC+1)+Y);
!

      ;;
 16) # JUMP/JSR
     step=0; 
     cat <<!
	tp = M_exe(PC+1) + (M_exe(PC+2)<<8);
!
      ;;
 17) # JMP indirect
     step=0; 
     cat <<!
	tp = M_exe(PC+1) + (M_exe(PC+2)<<8);
	/* NB The 6502 has a bug here, but it was fixed in the CMOS
	   versions of the processor */
#ifdef R65C02
	tp = M_read(tp) + (M_read((tp+1)&0xFFFF)<<8);
#else
	tp = M_read(tp) + (M_read((tp&0xFF00)+((tp+1)&0xFF))<<8);
#endif
!
      ;;
 18) # Branch
     step=2; 
;;
 19) # BRK/RTI
     step=0;
;;
 20) step=2; 
    cat <<!
	tp = M_exe(PC+1);
	tp = ZP_read(tp)+(ZP_read(tp+1)<<8);
	tp = M_read(tp);
!
;;
 21) echo 'tp=0;'
 ;;
 22) # JMP indirect,x
     step=0; 
     cat <<!
	tp = ((M_exe(PC+1) + (M_exe(PC+2)<<8) + X)&0xFFFF);
	tp = M_read(tp) + (M_read((tp+1)&0xFFFF)<<8);
!
      ;;
esac

(
awk "/^[	 ]*case/{ fl=0; } /^[ 	]*case *$op:/{ fl=1; } fl!=0{ print; }" | \
sed -e 's/break *;//'  -e 's/^[ 	]*case *[0-9]* *://'
)<<\!
      case  1:
	       /* This is an UNIMPLEMENTED instruction ... */
	       goto exit_cpu;
      case  2:
	       flags1 = (++tp);
	       break;
      case  3:
	       flags1 = (--tp);
	       break;
      case  4: 
      /* Do we want the host code to deal with BRK (ie OS Call) ? */
      ta = M_exe(0xFFFE) + (M_exe(0xFFFF)<<8);
      if ( CPU->brk_ill || ta >= 0xFFFC )
      {
               write_preg(CPU, flags1, flags2, flags3);
#ifdef LOCAL_CPU
               cpu = l_cpu;
#endif
               return 2;
      }
               /* This should be the non BBC version */
               PC += 2;
               M_write((S-- +0x100), (PC>>8));
               M_write((S-- +0x100), PC);
               write_preg(CPU, flags1, flags2, flags3);
               P |= B_FLAG|X_FLAG;
               M_write((S-- +0x100), P);
               PC = ta;
               break;
      case  5: 
               flags2 = 0;
	       break;
      case  6: 
               flags2 = 0x100;
	       break;
      case  7: 
               P = M_read(++S+0x100);
               read_preg(CPU, &flags1, &flags2, &flags3);
               PC = M_read(++S+0x100);
               PC |= (M_read(++S+0x100) << 8);
               break;
      case  8: 
               P &= ~I_FLAG;
	       if( cpu.int_pending ) intr_6502();
	       break;
      case  9: 
               PC = M_read(++S +0x100);
               PC |= ( M_read(++S +0x100) << 8 );
               break;
      case 10: 
               P |= I_FLAG;
	       break;
      case 11: 
               flags3 = 0;
	       break;
      case 12: 
               P &= ~D_FLAG;
	       break;
      case 13: 
               P |= D_FLAG;
	       break;
      case 14: 
               flags2 = (tp <<= 1);
               break;
      case 15: 
               flags2 = (tp<<8);
               tp >>= 1;
               break;
      case 16: 
               tp <<= 1;
               tp |= ((flags2&0x100)>>8);
               flags2 = tp;
               break;
      case 17: 
               tp |= (flags2&0x100);
               flags2 = (tp<<8);
               tp >>= 1;
               break;
      case 18: 
               tp |= A;
	       break;
      case 19: 
               tp &= A;
	       break;
      case 20: 
               tp ^= A;
	       break;
      case 21: 
               if( P & D_FLAG )
               {  /* I hope this is never used, the carry and zero bits
	             should be set correctly. But a real 6502 set the Z
		     bit before it does the binary -> decimal adjustment
		     As for the N & V flags, well the 6502 doesn't get 
		     them right either.
		   */

                  flags2 = (A&0xF) + (tp&0xF) + ((flags2>>8)& 1);
                  if( flags2 > 9 )
                  {
                     flags2 -= 10;
                     flags3 = (A&0xF0) + (tp&0xF0) + 0x10;
                     if( flags3 > 159 )
                     {
                        flags3 = flags3 - 160 + 0x100;
                     }
                  }
                  else
                     flags3 = (A&0xF0) + (tp&0xF0);
                  
                  flags3 = flags2 = tp = flags2 + flags3;
               }
               else
                  flags3 = flags2 = tp = A + tp + ((flags2>>8)& 1);
               break;
      case 22: 
               if( P & D_FLAG )
	       {
	           goto exit_cpu;

	          /* Flags are messed up on the 6502 as it doesn't do any
		   * adjustment on them, IMO this makes SBC almost useless
		   * in decimal mode.
		   * 
		   * But because of the way I'm
		   * generating this the N and Z flags _will_ be automatically
		   * based on the value stored in A.
		   *
		   * My understanding is that the 65C02 sets the flags 
		   * correctly so this is probably my best option.
		   * Nevertheless it's a little obscure exactly how the
		   * N bit should be set, I'm assuming it's the same as
		   * bit 7 'cause in the other case it would always be
		   * zero as the BCD values are always unsigned.
		   */
                  flags3 = A + (tp^0xFF) + ((flags2>>8)&1);


	          flags2 = flags3;
	       }
	       else
                  flags3 = flags2 = tp = A + (tp^0xFF) + ((flags2>>8)&1);
               break;
      case 23: 
               flags2 = flags1 = tp = A + (tp^0xFF) + 1;
               break;
      case 24: 
               flags2 = flags1 = tp = X + (tp^0xFF) + 1;
               break;
      case 25: 
               flags2 = flags1 = tp = Y + (tp^0xFF) + 1;
               break;
      case 26: 
               if(tp & A)
               {
                  if( tp & 0x80 ) flags1 = 0x81;
                  else            flags1 = 0x01;
               }
               else
               {
                  if( tp & 0x80 ) flags1 = 0x8000;
                  else            flags1 = 0x00;
               }
               /* printf("*** M%02x A%02x F1 %04x\n", tp, A, flags1); */
               /* if( flags1 ) flags1 = 1; */
               /* flags1 |= ((tp << 8)&0x8000); For now */
               flags3 =  ((tp&0x40) << 1);
               break;
      case 27: /* check flags1 15,7 */
               if( (flags1 & 0x8080) == 0 )
	       {
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 28: 
               PC+=2;
               M_write((S-- +0x100), (PC>>8));
               M_write((S-- +0x100), PC);
               PC = tp;
	       break;
      case 29:
                /* check flags1 15,7 */
               if( (flags1 & 0x8080) != 0 )
	       {  
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 30: 
               PC = tp;
	       break;
      case 31: 
               flags3 &= 0x180;
               if( flags3 == 0 || flags3 == 0x180 )
	       {
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 32: 
               flags3 &= 0x180;
               if( flags3 == 0x100 || flags3 == 0x080 )
	       {
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 33: 
               if( (flags2 & 0x0100) == 0 )
	       {
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 34: 
               if( (flags2 & 0x0100) != 0 )
	       {
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 35:
               /* check flags1 7-0 */
               if( (flags1 & 0xFF) != 0 )
	       {
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 36: 
               /* check flags1 7-0 */
               if( (flags1 & 0xFF) == 0 )
	       {
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
#ifdef CYCLES
                  UTIMER--;
#endif
               }
               break;
      case 37: 
      	       flags1 = ((flags1&0x8080)?0x8000:0)
	              + (A | tp);
               break;
      case 38: 
      	       flags1 = ((flags1&0x8080)?0x8000:0)
	              + ((A^0xFF) & tp);
               break;
      case 39: 
	          tp = M_exe(PC+1);
#ifdef NO_INFINITE
		  if( tp == 0xFE ) goto exit_cpu;
#endif
	          PC += s8bit(tp);
               break;
      case 40: 
	       if(flags1 & 0x8080) flags1 = 0x8000;
               if(tp & A)          flags1 |= 1;
               break;
!
case $wr in
  1) echo 'A = flags1 = tp;' ;;
  2) echo 'X = flags1 = tp;' ;;
  3) echo 'Y = flags1 = tp;' ;;
  4) echo 'S = tp;' ;;
  5) echo 'P = tp; read_preg(CPU, &flags1, &flags2, &flags3);' ;;
  6) echo 'M_write((S-- +0x100), tp);' ;;
  7) 
      step=2;
     cat <<!
               ta = M_exe(PC+1)+X;
               M_write((ZP_read(ta)+(ZP_read(ta+1)<<8)), tp);
!
;;
   8) 
      step=2;
      cat <<!
               ZP_write(M_exe(PC+1), tp);
!
;;
   10) 
      step=3;
      cat <<!
               M_write(M_exe(PC+1)+(M_exe(PC+2)<<8), tp);
!
;;
   11) 
      step=2;
      cat <<!
               ta = M_exe(PC+1);
               ta = ((ZP_read(ta)+(ZP_read(ta+1)<<8)+Y)&0xFFFF);
               M_write(ta, tp);
!
;;
   12) 
      step=2;
      cat <<!
               ZP_write(M_exe(PC+1)+X, tp);
!
;;
   13) 
      step=3;
      cat <<!
      ta = ((M_exe(PC+1)+(M_exe(PC+2)<<8)+Y)&0xFFFF);
       M_write(ta, tp);
!
;;
   14) 
      step=3;
      cat <<!
               ta = ((M_exe(PC+1)+(M_exe(PC+2)<<8)+X)&0xFFFF);
               M_write(ta, tp);
!
;;
   15) 
      step=2;
      cat <<!
               ZP_write(M_exe(PC+1)+Y, tp);
!
;;
   20) 
      step=2;
      cat <<!
               ta = M_exe(PC+1);
               ta = ZP_read(ta)+(ZP_read(ta+1)<<8);
               M_write(ta, tp);
!
   ;;
   90) echo 'M_write(ta,tp);' ;;
   91) echo 'ZP_write(ta,tp);' ;;
esac

[ "$cy" != 0 ] && cat <<!
#ifdef CYCLES
         UTIMER-=$cy;
#endif
!

[ "$step" != 0 ] && echo "PC += $step;"
cat <<!
         }
         break;
!
   [ "$plus" = "-" ] || echo '#endif'
   echo
}
done

}

part1() {
cat <<\!
#include <stdio.h>
#include "mc6502.h"

/* #define R65C02		* Include 65c02 instructions too. */
/* #define INSTRS		* Count instructions */
/* #define CYCLES		* Count 6502 clock cycles. */
/* #define NOP_ILL		* Make illegal instrs NOPs (1-3 bytes) */
/* #define NO_INFINITE		* include check for infinite branch loop */
/* #define COUNTER		* Count a frequency table, display on exit */
/* #define CHECKFLAGS		* Use 'mflags' array */
/* #define CHECKPAGE		* Use mem_rd and mem_wr */
/* #define CHECKEXEC		* Use mem_ex */
/* #define LOCAL_CPU auto	* Copy cpu structure to a local. */
 
#define FUNC_EXE    0x00
#define FUNC_READ   0x02
#define FUNC_WRITE  0x04

#define F_ZP_READ   0x00
#define F_ZP_WRITE  0x04

#ifdef __GNU__
#define Inline inline
#else
#define Inline
#endif

#ifdef __STDC__
#define s8bit(x) ((signed char)(x))
#else
#ifdef CHAR_IS_SIGNED
#define s8bit(x) ((char)(x))
#else
#define s8bit(x) (((x)&0x80)?((x)&0xFF)-256:((x)&0xFF))
#endif
#endif

struct regs cpu = {
   { 0xFFFB },		/* PC */
   0,0,0,0xFF,0,	/* A,X,Y,SP,P */
   0x4c,		/* Reset jump in 'ir' */
   0			/* utimer */
};

#ifdef CHECKFLAGS
static int Inline
M_read(int loc)
{
   if( mflags[loc]&FUNC_READ ) return read_mem(loc);
   else                        return memory[loc];
}

static int Inline
M_exe(int loc)
{
   if( mflags[loc]&FUNC_EXE ) return read_exe(loc);
   else                       return memory[loc];
}

static void Inline
M_write(int loc, unsigned char val)
{
   if( mflags[loc]&FUNC_WRITE ) write_mem(loc, val);
   else                         memory[loc] = val;
}

static int Inline
ZP_read(int loc )
{
   loc &= 0xFF;
   if( mflags[loc]&F_ZP_READ ) return read_mem(loc);
   else                        return memory[loc];
}

static void Inline
ZP_write(int loc, unsigned char val)
{
   loc &= 0xFF;
   if( mflags[loc]&F_ZP_WRITE ) write_mem(loc, val);
   else                         memory[loc] = val;
}

#else

#ifdef CHECKPAGE
static int Inline
M_read(unsigned int loc)
{
   if ( mem_rd[loc>>8] == 0 )
      return memory[loc];
   else if ( mem_rd[loc>>8] > 0 )
      return memory[mem_rd[loc>>8]+(loc&0xFF)];
   else
      return read_mem(loc);
}

static void Inline
M_write(unsigned int loc, unsigned char val)
{
   if ( mem_wr[loc>>8] == 0 )
      memory[loc] = val;
   else if ( mem_wr[loc>>8] > 0 )
      memory[mem_wr[loc>>8]+(loc&0xFF)] = val;
   else
      write_mem(loc, val);
}

#ifdef CHECKEXEC
static int Inline
M_exe(unsigned int loc)
{
   if ( mem_ex[loc>>8] == 0 )
      return memory[loc];
   else if ( mem_ex[loc>>8] > 0 )
      return memory[mem_ex[loc>>8]+(loc&0xFF)];
   else
      return read_exe(loc);
}
#else
#define M_exe(loc)         memory[loc]
#endif

#define ZP_read(loc)       memory[(loc)&0xFF]
#define ZP_write(loc,val) (memory[(loc)&0xFF] = (val))

#else
#define M_read(loc)        memory[loc]
#define M_exe(loc)         memory[loc]
#define M_write(loc,val)  (memory[loc] = (val))
#define ZP_read(loc)       memory[(loc)&0xFF]
#define ZP_write(loc,val) (memory[(loc)&0xFF] = (val))
#endif
#endif

static void write_preg(cpu_p, flags1, flags2, flags3)
struct regs * cpu_p;
int flags1, flags2, flags3;
{
   cpu_p->preg &= ~(N_FLAG|V_FLAG|Z_FLAG|C_FLAG);
   if( ( flags1 & 0xFF ) == 0 )   cpu_p->preg |= Z_FLAG;
   if( ( flags1 & 0x8080 ) != 0 ) cpu_p->preg |= N_FLAG;
   if( ( flags2 & 0x0100 ) != 0 ) cpu_p->preg |= C_FLAG;
   flags3 &= 0x180;
   if( flags3 == 0x100 || flags3 == 0x080 ) cpu_p->preg |= V_FLAG;
}

static void read_preg(cpu_p, pflags1, pflags2, pflags3)
struct regs * cpu_p;
int *pflags1, *pflags2, *pflags3;
{
   int fl = 0;
   *pflags3 = 0;

   if( ( cpu_p->preg & Z_FLAG ) == 0 ) fl |= 0x0001;
   if( ( cpu_p->preg & C_FLAG ) != 0 ) fl |= 0x0100;
   if( ( cpu_p->preg & N_FLAG ) != 0 ) fl |= 0x8000;
   *pflags1 = *pflags2 = fl;

   if( ( cpu_p->preg & V_FLAG ) != 0 ) *pflags3 = 0x0100;
}

void reset_6502()
{
static struct regs reset_cpu = {
   { 0xFFFB },		/* PC */
   0,0,0,0xFF,0,	/* A,X,Y,SP,P */
   0x4c,		/* Reset jump */
   0			/* utimer */
};
   reset_cpu.utimer = cpu.utimer;
   cpu = reset_cpu;
}

run_6502()
{
   ubyte irc;	/* Instruction register */
   int flags1;	/* This is the value that the N and Z flags are based on */
   int flags2;	/* This is for the C flag */
   int flags3;	/* V flag probably rarely used */

#ifdef LOCAL_CPU
LOCAL_CPU
struct regs l_cpu;
   l_cpu = cpu;

#define A  l_cpu.acc
#define X  l_cpu.xreg
#define Y  l_cpu.yreg
#define P  l_cpu.preg
#define S  l_cpu.sreg
#define PC l_cpu.pc
#define IR l_cpu.ir
#define UTIMER cpu.utimer
#define CPU (&l_cpu)

#else
   struct regs * pcpu = &cpu; /* Using this pointer helps GCC */

#define A  pcpu->acc
#define X  pcpu->xreg
#define Y  pcpu->yreg
#define P  pcpu->preg
#define S  pcpu->sreg
#define PC pcpu->pc
#define IR pcpu->ir
#define UTIMER pcpu->utimer
#define CPU pcpu
#endif

   read_preg(CPU, &flags1, &flags2, &flags3);

   if( cpu.int_pending && (P & I_FLAG) == 0 )
   {
      if(( IR & ~0xFF ) == 0 )
         intr_6502();
      else
      {
	 M_write((S-- +0x100), (PC>>8));
	 M_write((S-- +0x100), PC);
	 write_preg(CPU, flags1, flags2, flags3);
	 M_write((S-- +0x100), P);
	 P &= ~B_FLAG;
	 PC = M_read(0xFFFE) + (M_read(0xFFFF)<<8);
      }
   }

   if(( IR & ~0xFF ) == 0 )
   {
      irc = IR;
      IR = -1;
      goto Skipit;
   }

   while(1)
   {
      /* This is in in such a way that the asm generated should have a branch
       * that's only taken if we are exiting, a branch that is taken is likely
       * to do nasty things with pre-fetch so this is a 'Good thing'
       *
       * NB: GCC/486 - 4% speed improvement!
       */
#if defined(INSTRS) || defined(CYCLES)
      if(UTIMER <= 0) break;
#endif
      irc = M_exe(PC);
#ifdef COUNTER
      counters[irc]++;
#endif

Skipit:
/*
 This switch has been sorted by frequency of use of the instructions, this
 helps the CPU's cache keep 'useful' data because the most frequently used
 code is in one place. It improves execution times by around 2-3% on some
 CPUs
 */
     switch(irc)
     {
!

}

part3() {

cat <<\!
#ifndef NOP_ILL
     default: goto exit_cpu; /* Illegal instructions ... */
#else
     /* This makes illegal instructions into 'NOP's of the correct
      length, not traps.
      In fact this is just as wrong as traps because real 
      6502s have a set of strange undocumented instructions */

     default:
#ifdef R65C02
     /* It's my understanding that all undocumented OPs on the
        65C02 are single byte NOPs
	*/
        UTIMER -=2;
	PC++;
#else
     /* NB: I'm using this table so I don't have to scatter changes 
      all through the code for all the 65C02 ops, it does hit the 
      performance of the illegal instructions but that's not a 
      problem because nobody will use them ... will they :-) */

        {
	   static unsigned char instr_len[] = {
 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
 3, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 2, 3,
 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3,
 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3,
 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3,
 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3,
 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3,
 3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3
	   };
#ifdef CYCLES
	   if( instr_len[irc] == 3 ) UTIMER -=3;
	   else UTIMER -=2;
#endif
	   PC += instr_len[irc];
	}
#endif
	break;
#endif
      }
#if defined(INSTRS) && !defined(CYCLES)
      UTIMER--;
#endif
   }
   write_preg(CPU, flags1, flags2, flags3);
#ifdef LOCAL_CPU
   l_cpu.utimer = cpu.utimer; cpu = l_cpu;
#endif
   return 0;

exit_cpu:
   write_preg(CPU, flags1, flags2, flags3);
#ifdef LOCAL_CPU
   l_cpu.utimer = cpu.utimer; cpu = l_cpu;
#endif
   return 1;
}

!

}

main "$@"
