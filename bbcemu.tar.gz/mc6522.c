
#include "mc6522.h"

struct via system_via = { 0xFF, 0xFF };
struct via user_via = { 0xFF, 0xFF };

read_via(which, regno)
int which;
int regno;
{
   struct via * pvia;
   int rv = 0xFF;

   if(which == 0) pvia = &system_via; else pvia = &user_via;

   switch(regno)
   {
   case VIA_REG_A: /* Do CA1 process ... */
   case VIA_RAW_A:
                   rv = ((pvia->line_a&pvia->ddr_a)
                       | (pvia->ira & ~pvia->ddr_a)); 
                   break;
   case VIA_DDR_A: rv = pvia->ddr_a; break;

   case VIA_REG_B: rv = ((pvia->orb&pvia->ddr_b) | (pvia->irb & ~pvia->ddr_b)); 
                   break;
   case VIA_DDR_B: rv = pvia->ddr_b; break;

   case VIA_ACR : rv = pvia->acr; break;
   case VIA_PCR : rv = pvia->pcr; break;
   case VIA_IFR : rv = pvia->ifr; break;
   case VIA_IEF : rv = (pvia->ier|0x80); break;

   case VIA_T1CL:
   case VIA_T1CH:
   case VIA_T1LL:
   case VIA_T1LH:
   case VIA_T2CL:
   case VIA_T2CH:
   case VIA_SREG:
      break;
   }
   return rv & 0xFF;
}

write_via(which, regno, value)
int which;
int regno;
int value;
{
   struct via * pvia;
   if(which == 0) pvia = &system_via; else pvia = &user_via;

   switch(regno)
   {
   case VIA_REG_A: 
   case VIA_RAW_A:
                   pvia->line_a = pvia->ora = value;
                   break;
   case VIA_DDR_A: pvia->ddr_a = value;
                   break;

   case VIA_REG_B: pvia->line_b = pvia->orb = value; break;
   case VIA_DDR_B: pvia->ddr_b = value; break;

   case VIA_ACR : pvia->acr = value; break;
   case VIA_PCR : pvia->pcr = value; break;
   case VIA_IFR : pvia->ifr = value; break;
   case VIA_IEF : pvia->ier = value; break;

   case VIA_T1CL:
   case VIA_T1CH:
   case VIA_T1LL:
   case VIA_T1LH:
   case VIA_T2CL:
   case VIA_T2CH:
   case VIA_SREG:
      break;
   }
}
