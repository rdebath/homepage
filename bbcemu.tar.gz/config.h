
#ifdef MSDOS
#define __MSDOS__
#endif

#ifdef __MSDOS__
 /* Humm */
#endif
