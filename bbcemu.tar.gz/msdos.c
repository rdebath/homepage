
#include <stdio.h>
#include <ctype.h>

long bios_time();

Getrez() { return 2;   /* 2 colour hi res */ }
aline_init() { } 
line() { }
plot() { }
term_screen() { }
system(s) char * s; { return -1; }

inchar()
{
   int ch;
   fflush(stdout);
   ch = (bios_getc()&0xFF);
   if( islower(ch) )      ch = toupper(ch);
   else if( isupper(ch) ) ch = tolower(ch);
   return ch;
}

keyhit()
{
   int count = 0;
   return bios_keyhit(); /* -1 if char waiting */
}

start_timer(log_tic)
unsigned long * log_tic;
{
   *log_tic = bios_time();
}

unsigned long
time_since(log_tic)
unsigned long * log_tic;
{
   /* Time in 200 hundreths of sec since log_tic was set */
   long now = bios_time();

   now = now - *log_tic;
   if( now < 0 ) now += 0x1800B0;

   /*  *1080/19663 */

#ifdef __BCC__
   return (unsigned long) (now*200*1080/19663);
#else
   return (unsigned long) (now*10.98509891);
#endif
}

#ifndef __BCC__
#include <bios.h>

long bios_time()
{
   union REGS regs;
   regs.x.ax = 0;
   int86(0x1A, &regs, &regs);
   return (regs.x.cx<<16L) + (unsigned)regs.x.dx;
}

bios_putc(ch)
{
   union REGS regs;
   regs.h.al = ch;
   regs.h.ah = 0xE;
   int86(0x10, &regs, &regs);
}

bios_getc()
{
   union REGS regs;
   regs.x.ax = 0;
   int86(0x16, &regs, &regs);
   return regs.x.ax;
}

bios_keyhit()
{
   union REGS regs;
   regs.x.ax = 0x01FF;
   int86(0x16, &regs, &regs);
   if( regs.x.ax == 0x1FF ) return 0;
   return -1;
}
#endif

#ifdef __BCC__
long bios_time()
{
#asm
 xor	ax,ax
 int	0x1A
 mov	ax,dx
 mov	dx,cx
#endasm
}

bios_putc(c)
{
#asm
  mov	bx,sp
  mov	ax,[bx+2]
  mov	ah,#$0E
  mov	bx,#7
  int	$10
#endasm
}

bios_getc()
{
#asm
  xor	ax,ax
  int	$16
#endasm
}
#endif
