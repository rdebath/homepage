
#ifdef __linux__
#define M_XENIX
#endif

#ifdef M_XENIX
#include "time.h"

Bconin(chan)
int chan;
{
   char buf[1];
   if( chan == 2 )
   {
      read(0, buf, 1);
      if( buf[0] == '\n' ) return '\r';
      return buf[0]&0xFF;
   }
   else
      return -1;
}

Bconstat(chan)
int chan;
{
   if( chan == 2 )
   {
      return 0; /* -1 if char waiting */
   }
   else
      return -1;
}


Getrez()
{
   /* do stty */
   set_mode(1);
   return 2;   /* 2 colour hi res */
}

aline_init()
{
}

line()
{
}

plot()
{
}

term_screen()
{
   /* do stty off */
   set_mode(0);
}

start_timer(log_tic)
unsigned long * log_tic;
{
  time(log_tic);
}

unsigned long
time_since(log_tic)
unsigned long * log_tic;
{
   /* Time in 200 hundreths of sec since log_tic was set */
   return (time((long*)0)-*log_tic)*200L;
}

#include <stdio.h>

int intr_pending = 0;

#include <sgtty.h>
#include <signal.h>

/* This is Version 7 unix code it should work on any unix machine */
/* If you believe that you'll believe anything :-) */

static struct sgttyb tty, tty_save; /* terminal line characteristics */
static int tty_mode = -1;
static int tty_fd = 0;

q_die()
{
   set_mode(0);
   exit(1);
}

set_mode(which)
int which;
{
    if( tty_mode == -1 )
    {
       if(ioctl(tty_fd, TIOCGETP, &tty))
	   return;
       tty_save = tty;
       tty_mode = 0;
    }

    tty = tty_save;
    switch(which)
    {
    case 0: /* Normal cooked */
#ifdef CBREAK
            which = 0;
	    break;
    case 1: /* Pref CBREAK cooked ok */
    case 2: /* Pref CBREAK, RAW ok */
            tty.sg_flags &= ~ECHO;
            tty.sg_flags |= CBREAK; /* Allow break & cr/nl mapping */
            signal(SIGINT, q_die);
	    break;
#else
    case 1: /* Pref CBREAK cooked ok */
            which = 0;
	    break;
    case 2: /* Pref CBREAK, RAW ok */
#endif
    case 3: /* RAW */
            tty.sg_flags &= ~ECHO;
            tty.sg_flags |= RAW;
	    which = 3;
            break;
    }
    if(ioctl(tty_fd, TIOCSETP, &tty))
    {
	perror("Unable to change terminal mode");
    }
    else tty_mode = which;
}
#endif
