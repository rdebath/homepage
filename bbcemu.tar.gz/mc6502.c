/*
 * This file contains the emulator for the 6502 or 65c02 processor.
 * 
 * This emulator is designed to emulate all the documented features of the
 * processor plus a number of additional items.
 * 
 * It does not emulate any illegal or undocumented instructions, these cause
 * the emulator to drop out. The emulator doesn't emulate some of the
 * 'well known' features of the 6502 either: there is no extra memory
 * write for the read/modify/write instructions, branches and returns do
 * not access the first byte following the instruction even if the branch
 * is taken, the extra cycles for accesses to another page are not
 * calculated nor are the the accesses these cycles represent executed.
 * 
 * Currently the 'rmb,smb,bbr,bbs' instructions are not implemented and ADC
 * and SBC are not correct in decimal mode.
 * 
 * In addition to all illegal instructions causing the emulator to drop out
 * the BRK instruction can be switched to do the same thing if the flag
 * 'brk_ill' is set or the vector for BRK at $FFFE/F is >=$FFFC.
 */

#include <stdio.h>
#include "mc6502.h"

/* #define R65C02		* Include 65c02 instructions too. */
/* #define INSTRS		* Count instructions */
/* #define CYCLES		* Count 6502 clock cycles. */
/* #define NOP_ILL		* Make illegal instrs NOPs (1-3 bytes) */
/* #define NO_INFINITE		* include check for infinite branch loop */
/* #define COUNTER		* Count a frequency table, display on exit */
/* #define CHECKFLAGS		* Use 'mflags' array */
/* #define CHECKPAGE		* Use mem_rd and mem_wr */
/* #define CHECKEXEC		* Use mem_ex */
/* #define LOCAL_CPU auto	* Copy cpu structure to a local. */

#define FUNC_EXE    0x00
#define FUNC_READ   0x02
#define FUNC_WRITE  0x04

#define F_ZP_READ   0x00
#define F_ZP_WRITE  0x04

#ifdef __GNU__
#define Inline inline
#else
#define Inline
#endif

#ifdef __STDC__
#define s8bit(x) ((signed char)(x))
#else
#ifdef CHAR_IS_SIGNED
#define s8bit(x) ((char)(x))
#else
#define s8bit(x) (((x)&0x80)?((x)&0xFF)-256:((x)&0xFF))
#endif
#endif

struct regs cpu =
{
   {0xFFFB},			/* PC */
   0, 0, 0, 0xFF, 0,		/* A,X,Y,SP,P */
   0x4c,			/* Reset jump in 'ir' */
   0				/* utimer */
};

#ifdef CHECKFLAGS
static int Inline
M_read(int loc)
{
   if (mflags[loc] & FUNC_READ)
      return read_mem(loc);
   else
      return memory[loc];
}

static int Inline
M_exe(int loc)
{
   if (mflags[loc] & FUNC_EXE)
      return read_exe(loc);
   else
      return memory[loc];
}

static void Inline
M_write(int loc, unsigned char val)
{
   if (mflags[loc] & FUNC_WRITE)
      write_mem(loc, val);
   else
      memory[loc] = val;
}

static int Inline
ZP_read(int loc)
{
   loc &= 0xFF;
   if (mflags[loc] & F_ZP_READ)
      return read_mem(loc);
   else
      return memory[loc];
}

static void Inline
ZP_write(int loc, unsigned char val)
{
   loc &= 0xFF;
   if (mflags[loc] & F_ZP_WRITE)
      write_mem(loc, val);
   else
      memory[loc] = val;
}

#else

#ifdef CHECKPAGE
static int Inline
M_read(unsigned int loc)
{
   if (mem_rd[loc >> 8] == 0)
      return memory[loc];
   else if (mem_rd[loc >> 8] > 0)
      return memory[mem_rd[loc >> 8] + (loc & 0xFF)];
   else
      return read_mem(loc);
}

static void Inline
M_write(unsigned int loc, unsigned char val)
{
   if (mem_wr[loc >> 8] == 0)
      memory[loc] = val;
   else if (mem_wr[loc >> 8] > 0)
      memory[mem_wr[loc >> 8] + (loc & 0xFF)] = val;
   else
      write_mem(loc, val);
}

#ifdef CHECKEXEC
static int Inline
M_exe(unsigned int loc)
{
   if (mem_ex[loc >> 8] == 0)
      return memory[loc];
   else if (mem_ex[loc >> 8] > 0)
      return memory[mem_ex[loc >> 8] + (loc & 0xFF)];
   else
      return read_exe(loc);
}
#else
#define M_exe(loc)         memory[loc]
#endif

#define ZP_read(loc)       memory[(loc)&0xFF]
#define ZP_write(loc,val) (memory[(loc)&0xFF] = (val))

#else
#define M_read(loc)        memory[loc]
#define M_exe(loc)         memory[loc]
#define M_write(loc,val)  (memory[loc] = (val))
#define ZP_read(loc)       memory[(loc)&0xFF]
#define ZP_write(loc,val) (memory[(loc)&0xFF] = (val))
#endif
#endif

static void 
write_preg(cpu_p, flags1, flags2, flags3)
struct regs *cpu_p;
int   flags1, flags2, flags3;
{
   cpu_p->preg &= ~(N_FLAG | V_FLAG | Z_FLAG | C_FLAG);
   if ((flags1 & 0xFF) == 0)
      cpu_p->preg |= Z_FLAG;
   if ((flags1 & 0x8080) != 0)
      cpu_p->preg |= N_FLAG;
   if ((flags2 & 0x0100) != 0)
      cpu_p->preg |= C_FLAG;
   flags3 &= 0x180;
   if (flags3 == 0x100 || flags3 == 0x080)
      cpu_p->preg |= V_FLAG;
}

static void 
read_preg(cpu_p, pflags1, pflags2, pflags3)
struct regs *cpu_p;
int  *pflags1, *pflags2, *pflags3;
{
   int   fl = 0;
   *pflags3 = 0;

   if ((cpu_p->preg & Z_FLAG) == 0)
      fl |= 0x0001;
   if ((cpu_p->preg & C_FLAG) != 0)
      fl |= 0x0100;
   if ((cpu_p->preg & N_FLAG) != 0)
      fl |= 0x8000;
   *pflags1 = *pflags2 = fl;

   if ((cpu_p->preg & V_FLAG) != 0)
      *pflags3 = 0x0100;
}

void 
reset_6502()
{
   static struct regs reset_cpu =
   {
      {0xFFFB},			/* PC */
      0, 0, 0, 0xFF, 0,		/* A,X,Y,SP,P */
      0x4c,			/* Reset jump */
      0				/* utimer */
   };
   reset_cpu.utimer = cpu.utimer;
   cpu = reset_cpu;
}

run_6502()
{
   ubyte irc;			/* Instruction register */
   int   flags1;		/* This is the value that the N and Z
				 * flags are based on */
   int   flags2;		/* This is for the C flag */
   int   flags3;		/* V flag probably rarely used */

#ifdef LOCAL_CPU
   LOCAL_CPU
       struct regs l_cpu;
   l_cpu = cpu;

#define A  l_cpu.acc
#define X  l_cpu.xreg
#define Y  l_cpu.yreg
#define P  l_cpu.preg
#define S  l_cpu.sreg
#define PC l_cpu.pc
#define IR l_cpu.ir
#define UTIMER cpu.utimer
#define CPU (&l_cpu)

#else
   struct regs *pcpu = &cpu;	/* Using this pointer helps GCC */

#define A  pcpu->acc
#define X  pcpu->xreg
#define Y  pcpu->yreg
#define P  pcpu->preg
#define S  pcpu->sreg
#define PC pcpu->pc
#define IR pcpu->ir
#define UTIMER pcpu->utimer
#define CPU pcpu
#endif

   read_preg(CPU, &flags1, &flags2, &flags3);

   if (cpu.int_pending && (P & I_FLAG) == 0)
   {
      if ((IR & ~0xFF) == 0)
	 intr_6502();
      else
      {
	 M_write((S-- + 0x100), (PC >> 8));
	 M_write((S-- + 0x100), PC);
	 write_preg(CPU, flags1, flags2, flags3);
	 M_write((S-- + 0x100), P);
	 P &= ~B_FLAG;
	 PC = M_read(0xFFFE) + (M_read(0xFFFF) << 8);
      }
   }

   if ((IR & ~0xFF) == 0)
   {
      irc = IR;
      IR = -1;
      goto Skipit;
   }

   while (1)
   {
      /*
       * This is in in such a way that the asm generated should have a
       * branch that's only taken if we are exiting, a branch that is
       * taken is likely to do nasty things with pre-fetch so this is a
       * 'Good thing'
       * 
       * NB: GCC/486 - 4% speed improvement!
       */
#if defined(INSTRS) || defined(CYCLES)
      if (UTIMER <= 0)
	 break;
#endif
      irc = M_exe(PC);
#ifdef COUNTER
      counters[irc]++;
#endif

    Skipit:
      /*
       * This switch has been sorted by frequency of use of the
       * instructions, this helps the CPU's cache keep 'useful' data
       * because the most frequently used code is in one place. It
       * improves execution times by around 2-3% on some CPUs
       */
      switch (irc)
      {
      case 0xf0:		/* beq $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    /* check flags1 7-0 */
	    if ((flags1 & 0xFF) == 0)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0xc9:		/* cmp #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x85:		/* sta $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    ZP_write(M_exe(PC + 1), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xa5:		/* lda $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0x26:		/* rol $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    tp <<= 1;
	    tp |= ((flags2 & 0x100) >> 8);
	    flags2 = tp;

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0xb1:		/* lda ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ((ZP_read(tp) + (ZP_read(tp + 1) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0xc8:		/* iny */
	 {
	    register uword tp;
	    register uword ta;

	    tp = Y;

	    flags1 = (++tp);

	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xd0:		/* bne $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    /* check flags1 7-0 */
	    if ((flags1 & 0xFF) != 0)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x20:		/* jsr $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + (M_exe(PC + 2) << 8);

	    PC += 2;
	    M_write((S-- + 0x100), (PC >> 8));
	    M_write((S-- + 0x100), PC);
	    PC = tp;

#ifdef CYCLES
	    UTIMER -= 6;
#endif
	 }
	 break;

      case 0x60:		/* rts */
	 {
	    register uword tp;
	    register uword ta;


	    PC = M_read(++S + 0x100);
	    PC |= (M_read(++S + 0x100) << 8);

#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 1;
	 }
	 break;

      case 0x90:		/* bcc $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    if ((flags2 & 0x0100) == 0)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x65:		/* adc $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xb0:		/* bcs $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    if ((flags2 & 0x0100) != 0)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x88:		/* dey */
	 {
	    register uword tp;
	    register uword ta;

	    tp = Y;

	    flags1 = (--tp);

	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x86:		/* stx $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;
	    ZP_write(M_exe(PC + 1), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xe0:		/* cpx #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    flags2 = flags1 = tp = X + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0xa0:		/* ldy #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x91:		/* sta ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    ta = M_exe(PC + 1);
	    ta = ((ZP_read(ta) + (ZP_read(ta + 1) << 8) + Y) & 0xFFFF);
	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

      case 0xa6:		/* ldx $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xa4:		/* ldy $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);
	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0x84:		/* sty $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = Y;
	    ZP_write(M_exe(PC + 1), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xb9:		/* lda $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x0a:		/* asl a */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;

	    flags2 = (tp <<= 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x48:		/* pha */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    M_write((S-- + 0x100), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 1;
	 }
	 break;

      case 0x68:		/* pla */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_read(++S + 0x100);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 1;
	 }
	 break;

      case 0x05:		/* ora $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0x30:		/* bmi $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    /* check flags1 15,7 */
	    if ((flags1 & 0x8080) != 0)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x18:		/* clc */
	 {
	    register uword tp;
	    register uword ta;


	    flags2 = 0;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x98:		/* tya */
	 {
	    register uword tp;
	    register uword ta;

	    tp = Y;
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xa8:		/* tay */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xc4:		/* cpy $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags2 = flags1 = tp = Y + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xe6:		/* inc $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags1 = (++tp);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0xa9:		/* lda #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0xe9:		/* sbc #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x38:		/* sec */
	 {
	    register uword tp;
	    register uword ta;


	    flags2 = 0x100;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xe8:		/* inx */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;

	    flags1 = (++tp);

	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x06:		/* asl $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags2 = (tp <<= 1);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0x9d:		/* sta $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 3;
	 }
	 break;

      case 0xa2:		/* ldx #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x4c:		/* jmp $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + (M_exe(PC + 2) << 8);

	    PC = tp;

#ifdef CYCLES
	    UTIMER -= 3;
#endif
	 }
	 break;

      case 0x8a:		/* txa */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xaa:		/* tax */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xc6:		/* dec $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags1 = (--tp);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0x46:		/* lsr $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags2 = (tp << 8);
	    tp >>= 1;

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0x66:		/* ror $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    tp |= (flags2 & 0x100);
	    flags2 = (tp << 8);
	    tp >>= 1;

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0x69:		/* adc #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x95:		/* sta $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    ZP_write(M_exe(PC + 1) + X, tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0x10:		/* bpl $1234 */
	 {
	    register uword tp;
	    register uword ta;

	    /* check flags1 15,7 */
	    if ((flags1 & 0x8080) == 0)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x24:		/* bit $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    if (tp & A)
	    {
	       if (tp & 0x80)
		  flags1 = 0x81;
	       else
		  flags1 = 0x01;
	    }
	    else
	    {
	       if (tp & 0x80)
		  flags1 = 0x8000;
	       else
		  flags1 = 0x00;
	    }
	    /* printf("*** M%02x A%02x F1 %04x\n", tp, A, flags1); */
	    /* if( flags1 ) flags1 = 1; */
	    /* flags1 |= ((tp << 8)&0x8000); For now */
	    flags3 = ((tp & 0x40) << 1);

#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0x99:		/* sta $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 3;
	 }
	 break;

      case 0xbd:		/* lda $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xca:		/* dex */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;

	    flags1 = (--tp);

	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x29:		/* and #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x2a:		/* rol a */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;

	    tp <<= 1;
	    tp |= ((flags2 & 0x100) >> 8);
	    flags2 = tp;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x7d:		/* adc $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xb5:		/* lda $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0xc5:		/* cmp $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xfd:		/* sbc $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x45:		/* eor $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0x5d:		/* eor $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xbc:		/* ldy $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);
	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xc0:		/* cpy #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    flags2 = flags1 = tp = Y + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0xd1:		/* cmp ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ((ZP_read(tp) + (ZP_read(tp + 1) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

      case 0xdd:		/* cmp $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x00:		/* brk */
	 {
	    register uword tp;
	    register uword ta;


	    /* Do we want the host code to deal with BRK (ie OS Call) ? */
	    ta = M_exe(0xFFFE) + (M_exe(0xFFFF) << 8);
	    if (CPU->brk_ill || ta >= 0xFFFC)
	    {
	       write_preg(CPU, flags1, flags2, flags3);
#ifdef LOCAL_CPU
	       cpu = l_cpu;
#endif
	       return 2;
	    }
	    /* This should be the non BBC version */
	    PC += 2;
	    M_write((S-- + 0x100), (PC >> 8));
	    M_write((S-- + 0x100), PC);
	    write_preg(CPU, flags1, flags2, flags3);
	    P |= B_FLAG | X_FLAG;
	    M_write((S-- + 0x100), P);
	    PC = ta;

#ifdef CYCLES
	    UTIMER -= 7;
#endif
	 }
	 break;

      case 0x01:		/* ora ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + X;
	    tp = M_read(ZP_read(tp) + (ZP_read(tp + 1) << 8));

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x02:		/* mul # from 65C29 ? */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x04:		/* tsb $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags1 = ((flags1 & 0x8080) ? 0x8000 : 0)
		+ (A | tp);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x07:		/* rmb 0,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x08:		/* php */
	 {
	    register uword tp;
	    register uword ta;

	    write_preg(CPU, flags1, flags2, flags3);
	    tp = (P | X_FLAG | B_FLAG);
	    M_write((S-- + 0x100), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 1;
	 }
	 break;

      case 0x09:		/* ora #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x0c:		/* tsb $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags1 = ((flags1 & 0x8080) ? 0x8000 : 0)
		+ (A | tp);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;
#endif

      case 0x0d:		/* ora $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x0e:		/* asl $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags2 = (tp <<= 1);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x0f:		/* bbr 0,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x11:		/* ora ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ((ZP_read(tp) + (ZP_read(tp + 1) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x12:		/* ora ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ZP_read(tp) + (ZP_read(tp + 1) << 8);
	    tp = M_read(tp);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x14:		/* trb $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags1 = ((flags1 & 0x8080) ? 0x8000 : 0)
		+ ((A ^ 0xFF) & tp);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0x15:		/* ora $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0x16:		/* asl $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    flags2 = (tp <<= 1);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x17:		/* rmb 1,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x19:		/* ora $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x1a:		/* ina */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;

	    flags1 = (++tp);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x1c:		/* trb $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags1 = ((flags1 & 0x8080) ? 0x8000 : 0)
		+ ((A ^ 0xFF) & tp);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;
#endif

      case 0x1d:		/* ora $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    tp |= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x1e:		/* asl $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    flags2 = (tp <<= 1);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 7;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x1f:		/* bbr 1,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x21:		/* and ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + X;
	    tp = M_read(ZP_read(tp) + (ZP_read(tp + 1) << 8));

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

      case 0x25:		/* and $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x27:		/* rmb 2,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x28:		/* plp */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_read(++S + 0x100);
	    P = tp;
	    read_preg(CPU, &flags1, &flags2, &flags3);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 1;
	 }
	 break;

      case 0x2c:		/* bit $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    if (tp & A)
	    {
	       if (tp & 0x80)
		  flags1 = 0x81;
	       else
		  flags1 = 0x01;
	    }
	    else
	    {
	       if (tp & 0x80)
		  flags1 = 0x8000;
	       else
		  flags1 = 0x00;
	    }
	    /* printf("*** M%02x A%02x F1 %04x\n", tp, A, flags1); */
	    /* if( flags1 ) flags1 = 1; */
	    /* flags1 |= ((tp << 8)&0x8000); For now */
	    flags3 = ((tp & 0x40) << 1);

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x2d:		/* and $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x2e:		/* rol $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    tp <<= 1;
	    tp |= ((flags2 & 0x100) >> 8);
	    flags2 = tp;

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x2f:		/* bbr 2,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x31:		/* and ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ((ZP_read(tp) + (ZP_read(tp + 1) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x32:		/* and ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ZP_read(tp) + (ZP_read(tp + 1) << 8);
	    tp = M_read(tp);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x34:		/* bit $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    if (tp & A)
	    {
	       if (tp & 0x80)
		  flags1 = 0x81;
	       else
		  flags1 = 0x01;
	    }
	    else
	    {
	       if (tp & 0x80)
		  flags1 = 0x8000;
	       else
		  flags1 = 0x00;
	    }
	    /* printf("*** M%02x A%02x F1 %04x\n", tp, A, flags1); */
	    /* if( flags1 ) flags1 = 1; */
	    /* flags1 |= ((tp << 8)&0x8000); For now */
	    flags3 = ((tp & 0x40) << 1);

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0x35:		/* and $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0x36:		/* rol $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    tp <<= 1;
	    tp |= ((flags2 & 0x100) >> 8);
	    flags2 = tp;

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x37:		/* rmb 3,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x39:		/* and $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x3a:		/* dea */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;

	    flags1 = (--tp);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x3c:		/* bit $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    if (tp & A)
	    {
	       if (tp & 0x80)
		  flags1 = 0x81;
	       else
		  flags1 = 0x01;
	    }
	    else
	    {
	       if (tp & 0x80)
		  flags1 = 0x8000;
	       else
		  flags1 = 0x00;
	    }
	    /* printf("*** M%02x A%02x F1 %04x\n", tp, A, flags1); */
	    /* if( flags1 ) flags1 = 1; */
	    /* flags1 |= ((tp << 8)&0x8000); For now */
	    flags3 = ((tp & 0x40) << 1);

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;
#endif

      case 0x3d:		/* and $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    tp &= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x3e:		/* rol $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    tp <<= 1;
	    tp |= ((flags2 & 0x100) >> 8);
	    flags2 = tp;

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 7;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x3f:		/* bbr 3,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x40:		/* rti */
	 {
	    register uword tp;
	    register uword ta;


	    P = M_read(++S + 0x100);
	    read_preg(CPU, &flags1, &flags2, &flags3);
	    PC = M_read(++S + 0x100);
	    PC |= (M_read(++S + 0x100) << 8);

#ifdef CYCLES
	    UTIMER -= 6;
#endif
	 }
	 break;

      case 0x41:		/* eor ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + X;
	    tp = M_read(ZP_read(tp) + (ZP_read(tp + 1) << 8));

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x47:		/* rmb 4,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x49:		/* eor #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x4a:		/* lsr a */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;

	    flags2 = (tp << 8);
	    tp >>= 1;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x4d:		/* eor $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x4e:		/* lsr $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags2 = (tp << 8);
	    tp >>= 1;

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x4f:		/* bbr 4,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x50:		/* bvc $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    flags3 &= 0x180;
	    if (flags3 == 0 || flags3 == 0x180)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x51:		/* eor ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ((ZP_read(tp) + (ZP_read(tp + 1) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x52:		/* eor ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ZP_read(tp) + (ZP_read(tp + 1) << 8);
	    tp = M_read(tp);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0x55:		/* eor $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0x56:		/* lsr $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    flags2 = (tp << 8);
	    tp >>= 1;

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x57:		/* rmb 5,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x58:		/* cli */
	 {
	    register uword tp;
	    register uword ta;


	    P &= ~I_FLAG;
	    if (cpu.int_pending)
	       intr_6502();

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x59:		/* eor $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    tp ^= A;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x5a:		/* phy */
	 {
	    register uword tp;
	    register uword ta;

	    tp = Y;
	    M_write((S-- + 0x100), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 1;
	 }
	 break;
#endif

      case 0x5e:		/* lsr $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    flags2 = (tp << 8);
	    tp >>= 1;

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 7;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x5f:		/* bbr 5,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x61:		/* adc ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + X;
	    tp = M_read(ZP_read(tp) + (ZP_read(tp + 1) << 8));

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x64:		/* stz $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = 0;
	    ZP_write(M_exe(PC + 1), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x67:		/* rmb 6,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x6a:		/* ror a */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;

	    tp |= (flags2 & 0x100);
	    flags2 = (tp << 8);
	    tp >>= 1;

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x6c:		/* jmp ($d2d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    /*
	     * NB The 6502 has a bug here, but it was fixed in the CMOS
	     * versions of the processor
	     */
#ifdef R65C02
	    tp = M_read(tp) + (M_read((tp + 1) & 0xFFFF) << 8);
#else
	    tp = M_read(tp) + (M_read((tp & 0xFF00) + ((tp + 1) & 0xFF)) << 8);
#endif

	    PC = tp;

#ifdef CYCLES
	    UTIMER -= 5;
#endif
	 }
	 break;

      case 0x6d:		/* adc $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x6e:		/* ror $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    tp |= (flags2 & 0x100);
	    flags2 = (tp << 8);
	    tp >>= 1;

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x6f:		/* bbr 6,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x70:		/* bvs $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    flags3 &= 0x180;
	    if (flags3 == 0x100 || flags3 == 0x080)
	    {
	       tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	       if (tp == 0xFE)
		  goto exit_cpu;
#endif
	       PC += s8bit(tp);
#ifdef CYCLES
	       UTIMER--;
#endif
	    }

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;

      case 0x71:		/* adc ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ((ZP_read(tp) + (ZP_read(tp + 1) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x72:		/* adc ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ZP_read(tp) + (ZP_read(tp + 1) << 8);
	    tp = M_read(tp);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x74:		/* stz $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    tp = 0;
	    ZP_write(M_exe(PC + 1) + X, tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0x75:		/* adc $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0x76:		/* ror $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    tp |= (flags2 & 0x100);
	    flags2 = (tp << 8);
	    tp >>= 1;

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x77:		/* rmb 7,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x78:		/* sei */
	 {
	    register uword tp;
	    register uword ta;


	    P |= I_FLAG;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0x79:		/* adc $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    if (P & D_FLAG)
	    {			/* I hope this is never used, the carry
				 * and zero bits should be set correctly.
				 * But a real 6502 set the Z bit before it
				 * does the binary -> decimal adjustment
				 * As for the N & V flags, well the 6502
				 * doesn't get them right either. */

	       flags2 = (A & 0xF) + (tp & 0xF) + ((flags2 >> 8) & 1);
	       if (flags2 > 9)
	       {
		  flags2 -= 10;
		  flags3 = (A & 0xF0) + (tp & 0xF0) + 0x10;
		  if (flags3 > 159)
		  {
		     flags3 = flags3 - 160 + 0x100;
		  }
	       }
	       else
		  flags3 = (A & 0xF0) + (tp & 0xF0);

	       flags3 = flags2 = tp = flags2 + flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + tp + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x7a:		/* ply */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_read(++S + 0x100);
	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 1;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x7c:		/* jmp ($d2d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(tp) + (M_read((tp + 1) & 0xFFFF) << 8);

	    PC = tp;

#ifdef CYCLES
	    UTIMER -= 6;
#endif
	 }
	 break;
#endif

      case 0x7e:		/* ror $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    tp |= (flags2 & 0x100);
	    flags2 = (tp << 8);
	    tp >>= 1;

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 7;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x7f:		/* bbr 7,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x80:		/* bra $1234 */
	 {
	    register uword tp;
	    register uword ta;


	    tp = M_exe(PC + 1);
#ifdef NO_INFINITE
	    if (tp == 0xFE)
	       goto exit_cpu;
#endif
	    PC += s8bit(tp);

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0x81:		/* sta ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    ta = M_exe(PC + 1) + X;
	    M_write((ZP_read(ta) + (ZP_read(ta + 1) << 8)), tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x87:		/* smb 0,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x89:		/* bit #$d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);

	    if (flags1 & 0x8080)
	       flags1 = 0x8000;
	    if (tp & A)
	       flags1 |= 1;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0x8c:		/* sty $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = Y;
	    M_write(M_exe(PC + 1) + (M_exe(PC + 2) << 8), tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x8d:		/* sta $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    M_write(M_exe(PC + 1) + (M_exe(PC + 2) << 8), tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0x8e:		/* stx $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;
	    M_write(M_exe(PC + 1) + (M_exe(PC + 2) << 8), tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0x8f:		/* bbs 0,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x92:		/* sta ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = A;
	    ta = M_exe(PC + 1);
	    ta = ZP_read(ta) + (ZP_read(ta + 1) << 8);
	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0x94:		/* sty $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    tp = Y;
	    ZP_write(M_exe(PC + 1) + X, tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0x96:		/* stx $d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;
	    ZP_write(M_exe(PC + 1) + Y, tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0x97:		/* smb 1,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0x9a:		/* txs */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;
	    S = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

#ifdef R65C02
      case 0x9c:		/* stz $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    tp = 0;
	    M_write(M_exe(PC + 1) + (M_exe(PC + 2) << 8), tp);
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x9e:		/* stz $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    tp = 0;
	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 3;
	 }
	 break;
#endif

#ifdef R65C02
      case 0x9f:		/* bbs 1,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xa1:		/* lda ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + X;
	    tp = M_read(ZP_read(tp) + (ZP_read(tp + 1) << 8));
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0xa7:		/* smb 2,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xac:		/* ldy $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);
	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xad:		/* lda $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xae:		/* ldx $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xaf:		/* bbs 2,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

#ifdef R65C02
      case 0xb2:		/* lda ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ZP_read(tp) + (ZP_read(tp + 1) << 8);
	    tp = M_read(tp);
	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0xb4:		/* ldy $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);
	    Y = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0xb6:		/* ldx $d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ZP_read(M_exe(PC + 1) + Y);
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0xb7:		/* smb 3,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xb8:		/* clv */
	 {
	    register uword tp;
	    register uword ta;


	    flags3 = 0;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xba:		/* tsx */
	 {
	    register uword tp;
	    register uword ta;

	    tp = S;
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xbe:		/* ldx $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xbf:		/* bbs 3,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xc1:		/* cmp ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + X;
	    tp = M_read(ZP_read(tp) + (ZP_read(tp + 1) << 8));

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0xc7:		/* smb 4,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xcc:		/* cpy $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags2 = flags1 = tp = Y + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xcd:		/* cmp $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xce:		/* dec $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags1 = (--tp);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xcf:		/* bbs 4,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

#ifdef R65C02
      case 0xd2:		/* cmp ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ZP_read(tp) + (ZP_read(tp + 1) << 8);
	    tp = M_read(tp);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0xd5:		/* cmp $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0xd6:		/* dec $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    flags1 = (--tp);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0xd7:		/* smb 5,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xd8:		/* cld */
	 {
	    register uword tp;
	    register uword ta;


	    P &= ~D_FLAG;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xd9:		/* cmp $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    flags2 = flags1 = tp = A + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xda:		/* phx */
	 {
	    register uword tp;
	    register uword ta;

	    tp = X;
	    M_write((S-- + 0x100), tp);
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 1;
	 }
	 break;
#endif

      case 0xde:		/* dec $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    flags1 = (--tp);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 7;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xdf:		/* bbs 5,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xe1:		/* sbc ($d1,x) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1) + X;
	    tp = M_read(ZP_read(tp) + (ZP_read(tp + 1) << 8));

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

      case 0xe4:		/* cpx $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    flags2 = flags1 = tp = X + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

      case 0xe5:		/* sbc $d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1);
	    tp = ZP_read(ta);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 3;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0xe7:		/* smb 6,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xea:		/* nop */
	 {
	    register uword tp;
	    register uword ta;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xec:		/* cpx $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags2 = flags1 = tp = X + (tp ^ 0xFF) + 1;

#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xed:		/* sbc $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

      case 0xee:		/* inc $d2d1 */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + (M_exe(PC + 2) << 8);
	    tp = M_read(ta);

	    flags1 = (++tp);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xef:		/* bbs 6,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xf1:		/* sbc ($d1),y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ((ZP_read(tp) + (ZP_read(tp + 1) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0xf2:		/* sbc ($d1) */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_exe(PC + 1);
	    tp = ZP_read(tp) + (ZP_read(tp + 1) << 8);
	    tp = M_read(tp);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 5;
#endif
	    PC += 2;
	 }
	 break;
#endif

      case 0xf5:		/* sbc $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 2;
	 }
	 break;

      case 0xf6:		/* inc $d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = M_exe(PC + 1) + X;
	    tp = ZP_read(ta);

	    flags1 = (++tp);

	    ZP_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 6;
#endif
	    PC += 2;
	 }
	 break;

#ifdef R65C02
      case 0xf7:		/* smb 7,$d1 */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

      case 0xf8:		/* sed */
	 {
	    register uword tp;
	    register uword ta;


	    P |= D_FLAG;

#ifdef CYCLES
	    UTIMER -= 2;
#endif
	    PC += 1;
	 }
	 break;

      case 0xf9:		/* sbc $d2d1,y */
	 {
	    register uword tp;
	    register uword ta;

	    tp = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + Y) & 0xFFFF);
	    tp = M_read(tp);

	    if (P & D_FLAG)
	    {
	       goto exit_cpu;

	       /*
	        * Flags are messed up on the 6502 as it doesn't do any
	        * adjustment on them, IMO this makes SBC almost useless in
	        * decimal mode.
	        * 
	        * But because of the way I'm generating this the N and Z
	        * flags _will_ be automatically based on the value stored
	        * in A.
	        * 
	        * My understanding is that the 65C02 sets the flags correctly
	        * so this is probably my best option. Nevertheless it's a
	        * little obscure exactly how the N bit should be set, I'm
	        * assuming it's the same as bit 7 'cause in the other case
	        * it would always be zero as the BCD values are always
	        * unsigned.
	        */
	       flags3 = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);


	       flags2 = flags3;
	    }
	    else
	       flags3 = flags2 = tp = A + (tp ^ 0xFF) + ((flags2 >> 8) & 1);

	    A = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xfa:		/* plx */
	 {
	    register uword tp;
	    register uword ta;

	    tp = M_read(++S + 0x100);
	    X = flags1 = tp;
#ifdef CYCLES
	    UTIMER -= 4;
#endif
	    PC += 1;
	 }
	 break;
#endif

      case 0xfe:		/* inc $d2d1,x */
	 {
	    register uword tp;
	    register uword ta;

	    ta = ((M_exe(PC + 1) + (M_exe(PC + 2) << 8) + X) & 0xFFFF);
	    tp = M_read(ta);

	    flags1 = (++tp);

	    M_write(ta, tp);
#ifdef CYCLES
	    UTIMER -= 7;
#endif
	    PC += 3;
	 }
	 break;

#ifdef R65C02
      case 0xff:		/* bbs 7,a,r */
	 {
	    register uword tp;
	    register uword ta;


	    /* This is an UNIMPLEMENTED instruction ... */
	    goto exit_cpu;
	 }
	 break;
#endif

#ifndef NOP_ILL
      default:
	 goto exit_cpu;		/* Illegal instructions ... */
#else
	 /*
	  * This makes illegal instructions into 'NOP's of the correct
	  * length, not traps. In fact this is just as wrong as traps
	  * because real 6502s have a set of strange undocumented
	  * instructions
	  */

      default:
#ifdef R65C02
	 /*
	  * It's my understanding that all undocumented OPs on the 65C02
	  * are single byte NOPs
	  */
	 UTIMER -= 2;
	 PC++;
#else
	 /*
	  * NB: I'm using this table so I don't have to scatter changes
	  * all through the code for all the 65C02 ops, it does hit the
	  * performance of the illegal instructions but that's not a
	  * problem because nobody will use them ... will they :-)
	  */

	 {
	    static unsigned char instr_len[] =
	    {
	       2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
	       2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
	       3, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
	       2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
	       1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
	       2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
	       1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
	       2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3, 3,
	       2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3, 3,
	       2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 2, 3,
	       3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3,
	       3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3,
	       3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3,
	       3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3,
	       3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 3, 3, 3,
	       3, 2, 2, 2, 2, 2, 2, 2, 2, 1, 3, 1, 1, 3, 3, 3
	    };
#ifdef CYCLES
	    if (instr_len[irc] == 3)
	       UTIMER -= 3;
	    else
	       UTIMER -= 2;
#endif
	    PC += instr_len[irc];
	 }
#endif
	 break;
#endif
      }
#if defined(INSTRS) && !defined(CYCLES)
      UTIMER--;
#endif
   }
   write_preg(CPU, flags1, flags2, flags3);
#ifdef LOCAL_CPU
   l_cpu.utimer = cpu.utimer;
   cpu = l_cpu;
#endif
   return 0;

 exit_cpu:
   write_preg(CPU, flags1, flags2, flags3);
#ifdef LOCAL_CPU
   l_cpu.utimer = cpu.utimer;
   cpu = l_cpu;
#endif
   return 1;
}
