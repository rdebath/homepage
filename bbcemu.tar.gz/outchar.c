
#ifdef ATARI_ST
#include <osbind.h>

#define output(ch) Bconout(2, (ch));
#define VT52
#else
#define ANSI
#include <stdio.h>
#define output(ch) putchar(ch)
#endif

char vdubuf[11];
int  vdubufcnt = 0;

static int ctrllen[] = 
{
   0, 1, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0,
   0, 1, 2, 5, 0, 0, 1, 9,
   8, 5, 0, 0, 4, 5, 0, 2
};

static doneinit = 0;
static int mode;
int xpos1, ypos1, xpos2, ypos2;
int gfcolour = 15;
int gbcolour = 0;

outchar(ch)
int ch;
{
   int i;

   if( !doneinit )
   {
      doneinit = 1;
      aline_init();
      mode = Getrez();
      setmode(mode);
   }
   vdubuf[vdubufcnt] = (ch&0xFF);
   if( vdubufcnt != 0 )
   {
      if( vdubufcnt < ctrllen[vdubuf[0]] )
      {
         vdubufcnt++;
         return;
      }
   }
   else if( (ch & 0xE0) == 0 && ctrllen[ch] != 0 )
   {
      vdubufcnt = 1;
      return;
   }
   vdubufcnt = 0;
   ch = vdubuf[0];
   if( (ch &0xE0) == 0 )
   {
      /* Control char */
      switch(ch)
      {
      case 0: /* ignore */ break;

      case '\n': case '\r': case '\b': case '\007':
                 output(ch);
                 break;

#ifdef VT52
      case 9: output('\033'); output('C'); break;
      case 11: output('\033'); output('A'); break;
      case 12: output('\033'); output('E'); break;
      case 17: output('\033'); output('b');
               output(vdubuf[1]); break;
#endif
#ifdef ANSI
      case 9:  printf("\033[C"); break;
      case 11: printf("\033[A"); break;
      case 12: printf("\033[H\033[J"); break;
#endif

      case 18: if( vdubuf[1]&0x80 )
                  gbcolour = vdubuf[1];
               else
                  gfcolour = vdubuf[1];
               break;

      case 22: setmode(vdubuf[1]); break;

      case 25: do_plot(); break;

#ifdef VT52
      case 30: output('\033'); output('H'); break;
      case 31: output('\033'); output('Y');
               output(vdubuf[2]+32);
               output(vdubuf[1]+32);
               break;
#endif
#ifdef ANSI
      case 30: printf("\033[H"); break;
      case 31: printf("\033[%d;%dH", vdubuf[2]+1, vdubuf[1]+1); break;
#endif

      default: put_code(ch);
               for(i=0; i<ctrllen[ch]; i++)
	          put_code(vdubuf[i+1]);
      }
   }
   else if( ch != '\177' )
      output(ch);
   else /* if( ch == '\177' ) */
   {
      output('\b');
      output(' ');
      output('\b');
   }
#ifdef ANSI
   if( ch == '\n' ) fflush(stdout);
#endif
}

setmode(ch)
{
   /* Only certain changes are legal */
#ifdef ATARI_ST
   if( mode == 2 ) ch = 2;
   else if( ch != 0 && ch != 1 ) ch = 1;

   Setscreen(-1L, -1L, ch);
   mode = ch;
   output('\033');
   output('e');
   output('\033');
   output('v');
#endif
}

static int x1, x2, y1, y2;

do_plot()
{
   int ptype = vdubuf[1];
   int wcolour, pcolour;
   int curxpos;
   int curypos;

   curxpos = (vdubuf[2]&0xFF) + (vdubuf[3]<<8);
   curypos = (vdubuf[4]&0xFF) + (vdubuf[5]<<8);

   if( ( ptype & 4 ) == 0 )
   {
      ptype &= 0xFB;
      curxpos += xpos1;
      curypos += ypos1;
   }

   wcolour = ( ptype & 0x3 );
   ptype = ((ptype >> 3) & 0x1F);

   switch( wcolour )
   {
   case 1: pcolour = (gfcolour&0xF); break;
   case 2: pcolour = -1; break;
   case 3: pcolour = (gbcolour&0xF); break;
   }
   pcolour = colourclip(pcolour);
   if( wcolour ) switch(ptype)
   {
   case 0: if( lineclip(curxpos, curypos))
              line(x1, y1, x2, y2, pcolour);
           break;
   case 8: if( pointclip(curxpos, curypos))
              plot(x1, y1, pcolour);
           break;
   }

   xpos2 = xpos1;
   ypos2 = ypos1;
   xpos1 = curxpos;
   ypos1 = curypos;   
}

pointclip(x,y)
int x,y;
{
   if( x < 0 || y < 0 || x > 1279 || y > 1023 ) return 0;
   switch( mode )
   {
   case 0: x1 = x / 4;
           y1 = 199 - y * 25 / 128;
           break;
   case 1: x1 = x / 2;
           y1 = 199 - y * 25 / 128;
           break;
   case 2: x1 = x / 2;
           y1 = 399 - y * 25 / 64;
           break;
   }
   return 1;
}

lineclip(x,y)
{
   if( pointclip(x,y) )
   {
      x2 = x1; y2 = y1;
      if( pointclip(xpos1, ypos1) )
         return 1;
   }
   return 0;
}

colourclip(c)
int c;
{
   int m = 15;
   if( c < 0 ) return -1;
   switch( mode )
   {
   case 1: m = 3; break;
   case 2: m = 1; break;
   }
   if( c > m ) return 1+(c%m);
   return c;
}

put_code(ch)
int ch;
{
   char buf[16], *p;
   sprintf(buf, "[%d]", ch);
   for(p=buf; *p; p++) output(*p);
}
