
#include <stdio.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>

#ifndef __BCC__
#define TELNET
#endif

#ifdef TELNET
#include <arpa/telnet.h>
#endif

#include <termios.h>

void set_mode();
static int tty_mode = -1;
static char pending_char = 0;

/* Quick die function ... if we lose the tty or are shot */
void q_die() { set_mode(0); exit(1); } 

inchar()
{
   unsigned char buf[2];
   int cc;

   if( pending_char ) { cc = pending_char; pending_char=0; return cc; }

   fflush(stdout);

   set_mode(1);
try_again:;
   cc=read(0, buf, 1);
   if( cc <= 0 ) q_die();

#ifdef TELNET
   if( tty_mode == -2 & buf[0] == IAC )
   {
      /* Telnet options */
      cc = read(0, buf, 2);
      if( cc <= 0 ) q_die();
      if( buf[0] != IAC )
      {
	 if( buf[0] == DO && buf[1] == TELOPT_ECHO )
	    printf("%c%c%c", IAC, WILL, TELOPT_ECHO );
	 if( buf[0] == DO && buf[1] == TELOPT_BINARY )
	    printf("%c%c%c", IAC, WILL, TELOPT_BINARY );
	 fflush(stdout);
	 goto try_again;
      }
      /* NB char may be lost after xFF xFF - no matter */
   }
#endif

   if( buf[0] == '\177' ) return '\b';
   if( buf[0] == '\b' ) return '\177';
   if( buf[0] == '\n' && tty_mode == -2 ) return '\0';
   if( buf[0] == '\n' ) return '\r';

   if( isascii(buf[0]))
   {
      if( isupper(buf[0]) ) buf[0] = tolower(buf[0]);
      else if( islower(buf[0]) ) buf[0] = toupper(buf[0]);
   }

   return buf[0]&0xFF;
}

keyhit()
{
   int count = 0;
   if( pending_char ) return 1;

#ifdef TIOCINQ
   set_mode(1);
   if( ioctl(0, TIOCINQ, &count) < 0 || count > 0 ) return 1;
#else
#ifdef FIONREAD
   set_mode(1);
   if( ioctl(0, FIONREAD, &count) < 0 || count > 0 ) return 1;
#else
   set_mode(3);
   if( read(0, &pending_char, 1) > 0 ) return 1;
#endif
#endif
   return 0; /* 1 if char waiting */
}


Getrez()
{
   /* do stty */
   set_mode(1);
   return 2;   /* 2 colour hi res */
}

aline_init()
{
}

line()
{
}

plot()
{
}

term_screen()
{
   /* do stty off */
   set_mode(0);
}

start_timer(log_tic)
unsigned long * log_tic;
{
   struct timeval tv;
   gettimeofday(&tv, (struct timezone*)0);
   *log_tic = tv.tv_sec*200L+tv.tv_usec/5000L;
}

unsigned long
time_since(log_tic)
unsigned long * log_tic;
{
   /* Time in 200 hundreths of sec since log_tic was set */
   struct timeval tv;
   gettimeofday(&tv, (struct timezone*)0);
   return ( tv.tv_sec*200L+tv.tv_usec/5000L - *log_tic );
}

static struct termios tty, tty_save;

int intr_pending = 0;
static int tty_fd = 0;

void
set_mode(which)
int which;
{
    if( tty_mode == -1 )
    {
       if(tcgetattr(tty_fd, &tty))
       {
	   tty_mode = -2;
#ifdef TELNET
           printf("%c%c%c", IAC, WILL, TELOPT_ECHO );
           printf("%c%c%c", IAC, WILL, TELOPT_BINARY );
#else
	   perror("tcgetattr");
#endif
       }
       else
       {
          tty_save = tty;
          tty_mode = 0;
       }
    }
    if( tty_mode < 0 || tty_mode == which ) return;

    signal(SIGHUP, q_die);
    signal(SIGINT, q_die);
    signal(SIGTERM, q_die);
    signal(SIGPIPE, q_die);

    tty = tty_save;
    switch(which)
    {
    case 0: /* Normal cooked */
	    break;
    case 1: /* CBREAK */
	    tty.c_lflag &= ~(ICANON|ECHO|ECHOE|ECHONL);
	    tty.c_lflag |= ICRNL|ISIG;
	    tty.c_cc[VTIME] = 0;
	    tty.c_cc[VMIN]  = 1;
	    break;
    case 2: /* RAW */
	    tty.c_oflag &= ~OPOST;
	    tty.c_iflag &= ~(ICRNL|IGNCR|INLCR);
	    tty.c_lflag &= ~(ICANON|ECHO|ECHOE|ECHONL|ICRNL|ISIG);
	    tty.c_cc[VTIME] = 0;
	    tty.c_cc[VMIN]  = 1;
	    break;
    case 3: /* CBREAK - nowait */
	    tty.c_lflag &= ~(ICANON|ECHO|ECHOE|ECHONL);
	    tty.c_lflag |= ICRNL|ISIG;
	    tty.c_cc[VTIME] = 0;
	    tty.c_cc[VMIN]  = 0;
	    break;
    }

    if(tcsetattr(tty_fd, TCSANOW, &tty))
    {
	perror("Unable to change terminal mode");
    }
    else tty_mode = which;
}
