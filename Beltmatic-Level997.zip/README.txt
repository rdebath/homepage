Place the *.sav file in
C:\Users\%USERNAME%\AppData\Roaming\Beltmatic\Saves
