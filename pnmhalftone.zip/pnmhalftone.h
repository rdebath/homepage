
#define MAX_PALLET 256
#define MAX_VALUE  256

#define XL(fn) XDLIB_##fn

#define fatal	  XL(fatal)

#define idx_red	  XL(idx_red)
#define idx_grn	  XL(idx_grn)
#define idx_blu	  XL(idx_blu)
#define num_red	  XL(num_red)
#define num_grn	  XL(num_grn)
#define num_blu	  XL(num_blu)
#define num_wht	  XL(num_wht)
#define greystyle XL(greystyle)
#define clut	  XL(clut)
#define clut_size XL(clut_size)
#define clut_conv XL(clut_conv)

#define build_colourmaps XL(build_colourmaps)
#define parse_palstr     XL(parse_palstr)

extern void  parse_palstr(char * palname);
extern void  build_colourmaps(void);

/* The lookup table. */
extern int clut_size;
extern unsigned char clut[MAX_PALLET][3];

/* Colour quantised to abs indexes in minicube (add together). */
extern int idx_red[MAX_VALUE], idx_grn[MAX_VALUE], idx_blu[MAX_VALUE];

#if MAX_PALLET > 256
#if MAX_PALLET > 65536
int * clut_conv;
#else
unsigned short * clut_conv;
#endif
#else
unsigned char * clut_conv;
#endif

extern int   greystyle;
extern int   num_red;
extern int   num_grn;
extern int   num_blu;
extern int   num_wht;

