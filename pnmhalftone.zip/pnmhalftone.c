
#include <string.h>

#ifndef MKLIB
#include <stdio.h>
#include <pam.h>

#define MAX_PALLET 65536
#define MAX_VALUE  256

int   exit_val = 0;
char *progname = "pnmhalftone";
int   verbose = 0;
int   flg_c = 0;
int   disable_palette = 0;
int   max_level = 256;

void  do_file(FILE * fd);

#else
static char *progname = "DitherLib";
static int   max_level = 64;

#include "pnmhalftone.h"

#endif

/******************************************************************************/

void  parse_palstr(char * palname);
void  build_colourmaps(void);

/* The lookup table. */
int clut_size = 0;
unsigned char clut[MAX_PALLET][3];

/* Colour quantised to abs indexes in minicube (add together). */
int idx_red[MAX_VALUE], idx_grn[MAX_VALUE], idx_blu[MAX_VALUE];
static int cnt_cells;

#if MAX_PALLET > 256
#if MAX_PALLET > 65536
int * clut_conv;
#else
unsigned short * clut_conv;
#endif
#else
unsigned char * clut_conv;
#endif

/******************************************************************************/

static void  build_regular_clut(int *red, int *green, int *blue, int *white,
                         int *clut_mono_index, int *clut_colour_index);
static void  fill_lum(char * name, int size, int *rgb);
static void  fill_ht_tabs(int num, int *pal, int *down, int *up, int *ht);
static void  fill_rev_tab(int num, int *pal, int *tone);
static int find_diff(int red_a, int green_a, int blue_a, int red_b, int green_b, int blue_b);

static void fill_vga_pal(int * white, int * mixed, int * num_mixed, int *clut_mono_index, int *clut_colour_index);
static int  find_palette_entry(int pix_red, int pix_grn, int pix_blu);

static int   to_grey(int red, int green, int blue);

static int   quant_red_down[MAX_VALUE];	       /* Quantization on 'down' pixels */
static int   quant_grn_down[MAX_VALUE];
static int   quant_blu_down[MAX_VALUE];

static int   quant_red_up[MAX_VALUE];	       /* Quantization on 'up' pixels */
static int   quant_grn_up[MAX_VALUE];
static int   quant_blu_up[MAX_VALUE];

static int   quant_red_ht[MAX_VALUE];	       /* Average quantization values. */
static int   quant_grn_ht[MAX_VALUE];
static int   quant_blu_ht[MAX_VALUE];

static int   quant_wht_down[MAX_VALUE];	       /* Grey entries */
static int   quant_wht_up[MAX_VALUE];
static int   quant_wht_ht[MAX_VALUE];

static unsigned char vgaDefault[768];	       /* Default VGA palette */
static unsigned char yuvDefault[768];
static unsigned char * defined_pal = 0;

int   greystyle = 1;
int   num_red = 0;
int   num_grn = 0;
int   num_blu = 0;
int   num_wht = 0;

#ifndef MKLIB
void
Usage(void) {
   fprintf(stderr, "%s [options] [filename]\n", progname);
   fprintf(stderr, "Options:\n");
   fprintf(stderr, "  -p PS\tSet an r,g,b,w palette string.\n");
   fprintf(stderr, "  -c N\tSet counts of red, green and blue levels each to N.\n");
   fprintf(stderr, "  -r N\tSet count of red levels\n");
   fprintf(stderr, "  -g N\tSet count of green levels\n");
   fprintf(stderr, "  -b N\tSet count of blue levels\n");
   fprintf(stderr, "  -w N\tSet count of white/grey levels\n");
   fprintf(stderr, "  -G N\tN selects rgb to greyscale style.\n");

   fprintf(stderr, "  -v\tMore verbose\n");
   fprintf(stderr, "  -q\tLess verbose\n");
   fprintf(stderr, "\n");
   fprintf(stderr, "Pallet strings are between 1 and 4 comma seperated numbers.\n");
   fprintf(stderr, "A single value less than 20 is passed to -c.\n");
   fprintf(stderr, "A pair of values are passed to -c and -w.\n");
   fprintf(stderr, "Three values are passed to -r, -g and -b in that order\n");
   fprintf(stderr, "and four values are in the order r,g,b,w\n");
   fprintf(stderr, "Sometimes you don't need to include the commas.\n");
   fprintf(stderr, "\n");
   fprintf(stderr, "Grey styles are:\n");
   fprintf(stderr, "  -G 0   Arithmetic average.\n");
   fprintf(stderr, "  -G 1   Black & white TV or RGB->YUV. (default)\n");
   fprintf(stderr, "  -G 2   HDTV ratios or CIE XYZ.\n");
   fprintf(stderr, "  -G 3   HSL Average of min and max.\n");
   fprintf(stderr, "  -G 4   HSV Maximum component.\n");
   fprintf(stderr, "  -G 5   Average of brightest pair.\n");
   fprintf(stderr, "  -G 6   RDBv1 Homegrown.\n");

   exit(255);
}

int
main(int argc, char **argv)
{
   int done=0;
   int ar, flg=1;
   char * p;
   char * filename = 0;
   FILE *fd;

   pm_init(progname, 0);

   /* Traditional option processing. */
   for(ar=1; ar<argc; ar++) 
      if(flg && argv[ar][0] == '-' && argv[ar][1] != 0) 
	 for(p=argv[ar]+1;*p;p++)
	    switch(*p) {
	       case '-': flg = 0; break;
	       case 'v': verbose++; break;
	       case 'q': verbose--; break;

	       case 'V': defined_pal = vgaDefault; flg_c = 1; 
			 num_red = num_grn = num_blu = num_wht = 0;
			 break;

	       case 'Y': defined_pal = yuvDefault; flg_c = 1; 
			 num_red = num_grn = num_blu = num_wht = 0;
			 break;

	       case 'D': disable_palette = 1; break;

	       default: 
		  if (ar+1>=argc) Usage();
		  else switch(*p) {
		     case 'c': flg_c = 1; num_red = num_grn = num_blu = atoi(argv[++ar]); break;
		     case 'r': flg_c = 1; num_red = atoi(argv[++ar]); break;
		     case 'g': flg_c = 1; num_grn = atoi(argv[++ar]); break;
		     case 'b': flg_c = 1; num_blu = atoi(argv[++ar]); break;
		     case 'w': flg_c = 1; num_wht = atoi(argv[++ar]); break;

		     case 'p': parse_palstr(argv[++ar]); break;

		     case 'G': greystyle = atoi(argv[++ar]); break;
		     case 'R': max_level = atoi(argv[++ar]); break;

		     default:  
			fprintf(stderr, "Unknown option -%c\n", *p);
			Usage();
		  }
		  break;
	    }
      else {
	 if (done) Usage();
	 filename = argv[ar];
	 done = 1;
      }

   if (!flg_c && !disable_palette) {
      num_red = 6;	/* My fav 8 bit. */
      num_grn = 10;
      num_blu = 4;
      num_wht = 16;
   }

   if (num_red > MAX_VALUE) num_blu = MAX_VALUE;
   if (num_grn > MAX_VALUE) num_grn = MAX_VALUE;
   if (num_blu > MAX_VALUE) num_blu = MAX_VALUE;
   if (num_wht > MAX_VALUE) num_wht = MAX_VALUE;

   if (num_red < 0) num_blu = 0;
   if (num_grn < 0) num_grn = 0;
   if (num_blu < 0) num_blu = 0;
   if (num_wht < 0) num_wht = 0;

   if (verbose)
      fprintf(stderr, "%s: Building colourmap %d,%d,%d,%d\n", progname,
	      num_red, num_grn, num_blu, num_wht);
   build_colourmaps();

   if (done && strcmp(filename, "-") == 0) done = 0;

   if (done) {
      if (verbose)
	 fprintf(stderr, "%s: Processing %s\n", progname, filename);

      fd = fopen(filename, "r");
      if (fd == 0)
	 perror(filename);
      else {
	 do_file(fd);
	 fclose(fd);
      }
      done = 1;

   } else {

      if (verbose)
	 fprintf(stderr, "%s: Processing stdin\n", progname);
      do_file(stdin);
   }

   return (exit_val);
}

void
do_file(FILE * fd)
{
   struct pam inpam, outpam;
   unsigned int row, column;
   tuple *tuplerow;

   pnm_readpaminit(fd, &inpam, sizeof(inpam));

   outpam = inpam;
   if (outpam.depth <= 3) {
      outpam.format = RPPM_FORMAT;
      outpam.depth = 3;
   }
   outpam.maxval = MAX_VALUE-1;
   outpam.file = stdout;

   if (inpam.depth == 1)
      fprintf(stderr, "%s: Converting input PGM to PPM\n", progname);
   else if (outpam.depth != inpam.depth)
      fprintf(stderr, "%s: Converting input depth %d to PPM\n", progname, inpam.depth);
   if (outpam.maxval != inpam.maxval)
      fprintf(stderr, "%s: Converting input maxval %d to %d\n", 
                      progname, inpam.maxval, outpam.maxval);

   pnm_writepaminit(&outpam);

   /* NOTE outpam: is same or larger than inpam */
   tuplerow = pnm_allocpamrow(&outpam); 

   for (row = 0; row < inpam.height; row++) {
      unsigned int col;
      pnm_readpamrow(&inpam, tuplerow);

      /* Fix depth if needed; I need PPM. */
      if (inpam.depth < outpam.depth) {
         for (column = 0; column < inpam.width; column++) {
	    int i;
	    for(i=inpam.depth; i<outpam.depth; i++)
	       tuplerow[column][i] = tuplerow[column][0];
	 }
      }

      /* Fix maxval if needed; I need 255. */
      if (inpam.maxval != outpam.maxval) {
         for (column = 0; column < inpam.width; column++) {
	    int i;
	    for(i=0; i<outpam.depth; i++)
	       tuplerow[column][i] = tuplerow[column][i] 
	                           * outpam.maxval / inpam.maxval;
	 }
      }

      for (column = 0; column < inpam.width; column++) {

	 int quant_up = ((row ^ column) & 1);
	 /* Alternate 4 level dither. */
	 /* int quant_num = (((row & 1)<<1) + (column & 1)); */
	 tuple tp;

	 if (clut_size > 0) { /* => If we have an 8-bit palette */
	    int   clutno;

	    tp = tuplerow[column];

	    clutno = clut_conv[
		       idx_red[tp[PAM_RED_PLANE]] +
		       idx_grn[tp[PAM_GRN_PLANE]] +
		       idx_blu[tp[PAM_BLU_PLANE]] +
		       quant_up];

	    tp[PAM_RED_PLANE] = clut[clutno][0];
	    tp[PAM_GRN_PLANE] = clut[clutno][1];
	    tp[PAM_BLU_PLANE] = clut[clutno][2];

	 } else {
	    tp = tuplerow[column];

	    /* Fallback, just use first table with data */
	    if (num_red != 0 && num_grn != 0 && num_blu != 0) {
	       /* Use colour palette, haltone each primary in turn. */
	       if (quant_up) {
		  tp[PAM_RED_PLANE] = quant_red_up[tp[PAM_RED_PLANE]];
		  tp[PAM_GRN_PLANE] = quant_grn_up[tp[PAM_GRN_PLANE]];
		  tp[PAM_BLU_PLANE] = quant_blu_up[tp[PAM_BLU_PLANE]];
	       } else {
		  tp[PAM_RED_PLANE] = quant_red_down[tp[PAM_RED_PLANE]];
		  tp[PAM_GRN_PLANE] = quant_grn_down[tp[PAM_GRN_PLANE]];
		  tp[PAM_BLU_PLANE] = quant_blu_down[tp[PAM_BLU_PLANE]];
	       }
	    } else {
	       /* Set to grey and halftone that. */
	       int greycol = to_grey(tp[PAM_RED_PLANE],
				     tp[PAM_GRN_PLANE],
				     tp[PAM_BLU_PLANE]);

	       if (num_wht>1) {
		  if (quant_up) {
		     tp[PAM_RED_PLANE] = quant_wht_up[greycol];
		  } else {
		     tp[PAM_RED_PLANE] = quant_wht_down[greycol];
		  }
	       } else {
		  tp[PAM_RED_PLANE] = greycol;
	       }
	       tp[PAM_GRN_PLANE] = tp[PAM_RED_PLANE];
	       tp[PAM_BLU_PLANE] = tp[PAM_RED_PLANE];
	    }
	 }
      }
      pnm_writepamrow(&outpam, tuplerow);
   }

   pnm_freepamrow(tuplerow);
}
#endif

void
parse_palstr(char * palname)
{
   int commas = (strchr(palname, ',') != 0);
   char * p = palname;
   int  vals[8], vidx = 0;

#ifndef MKLIB
   flg_c = 1;
#endif

   if (!p || !*p) return;

   if (strcasecmp(p, "vga") == 0) {
      defined_pal = vgaDefault;
      num_red = num_grn = num_blu = num_wht = 0;
      return;
   } else if (strcasecmp(p, "yuv") == 0) {
      defined_pal = yuvDefault;
      num_red = num_grn = num_blu = num_wht = 0;
      return;
   }

   if (commas) {
      for(vidx=0, p=palname; p&&*p;) {
         char * e = strchr(p, ',');

	 if (e) *e = 0;
	 if (vidx<8) vals[vidx++] = atoi(p);
	 if (e) { *e = ','; p=e+1; }
	 else   { p=0; }
      }
      switch (vidx)
      {
         case 2: num_wht = vals[1];
         case 1: num_red = num_grn = num_blu = vals[0]; break;
	 case 6: max_level = vals[5];
	 case 5: greystyle = vals[4];
         case 4: num_wht = vals[3];
         case 3: num_red = vals[0];
	         num_grn = vals[1];
		 num_blu = vals[2]; 
		 break;
      }

   } else if (strlen(palname) == 8) {
      num_red = *p++ - '0';
      num_red = num_red * 10 + *p++ - '0';
      num_grn = *p++ - '0';
      num_grn = num_grn * 10 + *p++ - '0';
      num_blu = *p++ - '0';
      num_blu = num_blu * 10 + *p++ - '0';
      num_wht = *p++ - '0';
      num_wht = num_wht * 10 + *p++ - '0';
   } else {
      if (*p == '1' && p[1]) {
         num_red = 10 + *++p - '0'; p++;
      } else if (*p)
         num_red = *p++ - '0';

      if (*p == '1' && p[1]) {
         num_grn = 10 + *++p - '0'; p++;
      } else if (*p) {
         num_grn = *p++ - '0';
      } else
         num_grn = 0;

      if (*p == '1' && p[1]) {
	 num_blu = 10 + *++p - '0'; p++;
      } else if (*p)
	 num_blu = *p++ - '0';
      else {
	 num_wht = num_grn;
	 num_grn = num_blu = num_red;
      }

      if (*p == '1' && p[1]) {
         num_wht = 10 + *++p - '0'; p++;
      } else if (*p)
         num_wht = *p++ - '0';

      if (*p) {
         if (strlen(palname) == 6) {
	    p = palname;
	    num_red = *p++ - '0';
	    num_red = num_red * 10 + *p++ - '0';
	    num_grn = *p++ - '0';
	    num_grn = num_grn * 10 + *p++ - '0';
	    num_blu = *p++ - '0';
	    num_blu = num_blu * 10 + *p++ - '0';
	    num_wht = 0;
	 } else {
#ifdef MKLIB
            fatal("Cannot decode palette string");
#else
	    fprintf(stderr, "%s: Cannot decode palette %s\n", progname, palname);
	    exit(255);
#endif
         }
      }
   }
}

void
build_colourmaps(void)
{
   int   random_palette = 0;

   int   r,g,b,w, i,j,k;

   /* The colours available for each of r,g,b,w */
   int   red[MAX_VALUE], green[MAX_VALUE], blue[MAX_VALUE], white[MAX_VALUE];
   int   num_mixed, mixed[MAX_VALUE];

   /* Quantize from a normal colour index to an availablke colours index */
   int   fidx_red[MAX_VALUE], fidx_grn[MAX_VALUE], fidx_blu[MAX_VALUE], fidx_wht[MAX_VALUE];
   int   fidx_mix[MAX_VALUE];

   /* Minicube index number to colour. */
   int cnt_red = 0, cnt_blu = 0, cnt_grn = 0;
   int idx_to_red[MAX_VALUE+1], idx_to_grn[MAX_VALUE+1], idx_to_blu[MAX_VALUE+1];

   int   clut_colour_index[MAX_PALLET]; /* RGB cube to clut index */
   int   clut_mono_index[MAX_PALLET]; /* Greyscale to clut index */

   if (clut_conv) free(clut_conv); clut_conv = 0; clut_size = 0;

   if (defined_pal) {
#ifndef MKLIB
      if (verbose)
	 fprintf(stderr, "%s: Switching to predefined VGA colourmap.\n", progname);
#endif
      fill_lum("red", 0, red);
      fill_lum("grn", 0, green);
      fill_lum("blu", 0, blue);
      fill_vga_pal(white, mixed, &num_mixed, clut_mono_index, clut_colour_index);
      random_palette = 1;
   }

   if (!random_palette) {
      /* Calculate even spaced brightness levels. */
      fill_lum("red", num_red, red);
      fill_lum("grn", num_grn, green);
      fill_lum("blu", num_blu, blue);
      fill_lum("wht", num_wht, white);
   }

   /* Choose closest ht colour levels for each input level. */
   fill_ht_tabs(num_red, red, quant_red_down, quant_red_up, quant_red_ht);
   fill_ht_tabs(num_grn, green, quant_grn_down, quant_grn_up, quant_grn_ht);
   fill_ht_tabs(num_blu, blue, quant_blu_down, quant_blu_up, quant_blu_ht);
   fill_ht_tabs(num_wht, white, quant_wht_down, quant_wht_up, quant_wht_ht);

#ifndef MKLIB
   if (disable_palette) {
      clut_size = 0;
      if (verbose)
	 fprintf(stderr, "%s: Palette generation turned off.\n", progname);
      return;
   }
#endif

   /* Create 8-bit clut if possible. */
   if (!random_palette)
      build_regular_clut(red, green, blue, white, clut_mono_index, clut_colour_index);

#ifndef MKLIB
   /* Built the clut, display it */
   if (verbose) {
      fprintf(stderr, "%s: Colourmap size %d\n", progname, clut_size);

      if (verbose>1) {
	 int j;
	 for(j=0; j<clut_size; j++) {
	    fprintf(stderr, "clut[%3d] = (%3d,%3d,%3d),C=%3d,M=%3d\n",
	       j, clut[j][0], clut[j][1], clut[j][2],
	       clut_colour_index[j],
	       clut_mono_index[j]);
	 }
      }
   }
#endif

   /* Didn't get an 8-bit clut. Use the quant_* tables directly. */
   if (clut_size < 2 || clut_size > MAX_PALLET) { 
#ifdef MKLIB
      fatal("Unable to generate usable palette from specification");
#else
      if (verbose)
	 fprintf(stderr, "%s: Not using colourmap.\n", progname);
#endif
      clut_size = 0;
      return;
   }

   /* Reverse mapping, colour to palette index. */
   fill_rev_tab(num_red, red, fidx_red);
   fill_rev_tab(num_grn, green, fidx_grn);
   fill_rev_tab(num_blu, blue, fidx_blu);
   fill_rev_tab(num_wht, white, fidx_wht);

   /* Enough cubes for a random palette */
   fill_rev_tab(num_mixed, mixed, fidx_mix);

#ifndef MKLIB
   /* Display quantisation tables */
   if (verbose>2) {
      int   i;

      for(i=0; i<MAX_VALUE; i++) {
	 fprintf(stderr, "%-3d ", i);
	 if (num_wht > 0) {
	    fprintf(stderr, "WHT%c F%03d(%d) H%03d U%03d D%03d, ",
		 white[fidx_wht[i]]==i?'*':' ',
		 white[fidx_wht[i]],
		 fidx_wht[i],
		 quant_wht_ht[i],
		 quant_wht_up[i],
		 quant_wht_down[i]
		 );
	 }

	 fprintf(stderr, "RED%c F%03d(%d) H%03d U%03d D%03d, ",
		 red[fidx_red[i]]==i?'*':' ',
		 red[fidx_red[i]],
	         fidx_red[i],
		 quant_red_ht[i],
		 quant_red_up[i],
		 quant_red_down[i]
		 );

	 fprintf(stderr, "GRN%c F%03d(%d) H%03d U%03d D%03d, ",
		 green[fidx_grn[i]]==i?'*':' ',
		 green[fidx_grn[i]],
		 fidx_grn[i],
		 quant_grn_ht[i],
		 quant_grn_up[i],
		 quant_grn_down[i]
		 );

	 fprintf(stderr, "BLU%c F%03d(%d) H%03d U%03d D%03d",
		 blue[fidx_blu[i]]==i?'*':' ',
		 blue[fidx_blu[i]],
		 fidx_blu[i],
		 quant_blu_ht[i],
		 quant_blu_up[i],
		 quant_blu_down[i]
		 );

	 fprintf(stderr, "\n");
      }
   }
#endif

   /* Choose the collection of minicubes to use. */
   {
      int lv_red = 0, lv_blu = 0, lv_grn = 0, lv_wht = 0;
      int lv_mix = 0;
      int lastc = 1;

      for(i=0; i<MAX_VALUE+1; i++)
         idx_to_red[i] = idx_to_grn[i] = idx_to_blu[i] = 0;
      for(i=0; i<MAX_VALUE; i++)
         idx_red[i] = idx_grn[i] = idx_blu[i] = 0;

      /* Find quantisation counts. Inc on each change of white or colour. */
      for(i=0; i<MAX_VALUE; i++) {
         int ar=0, ag=0, ab=0;

	 if ((double) (i+1) * max_level / MAX_VALUE > lastc ) {
	    if (num_wht > 0) {
	       if (quant_wht_ht[i] > lv_wht) {
		  lv_wht = quant_wht_ht[i];
		  ar=1; ag=1; ab=1;
	       }
	    }
	    if (num_mixed > 0) {
	       if (mixed[fidx_mix[i]] > lv_mix) {
	          lv_mix = mixed[fidx_mix[i]];
		  ar=1; ag=1; ab=1;
	       }
	    }
	    if (quant_red_ht[i] > lv_red) {
	       lv_red = quant_red_ht[i];
	       ar=1;
	    }
	    if (quant_grn_ht[i] > lv_grn) {
	       lv_grn = quant_grn_ht[i];
	       ag=1;
	    }
	    if (quant_blu_ht[i] > lv_blu) {
	       lv_blu = quant_blu_ht[i];
	       ab=1;
	    }
	 }

	 cnt_red += ar;
	 cnt_grn += ag;
	 cnt_blu += ab;

         idx_red[i] = cnt_red;
         idx_grn[i] = cnt_grn;
         idx_blu[i] = cnt_blu;

#ifndef MKLIB
	 if (verbose>2)
	    fprintf(stderr, "idx[%d] = (%d,%d,%d)", i,
	       idx_red[i], idx_grn[i], idx_blu[i]);
#endif

         if(ar) {
	    idx_to_red[cnt_red] = i;
#ifndef MKLIB
	    if (verbose>2)
	       fprintf(stderr, ", to_red[%d] <%d>", cnt_red, lv_red);
#endif
	 }
         if(ag) {
	    idx_to_grn[cnt_grn] = i;
#ifndef MKLIB
	    if (verbose>2)
	       fprintf(stderr, ", to_grn[%d] <%d>", cnt_grn, lv_grn);
#endif
	 }
         if(ab) {
	    idx_to_blu[cnt_blu] = i;
#ifndef MKLIB
	    if (verbose>2)
	       fprintf(stderr, ", to_blu[%d] <%d>", cnt_blu, lv_blu);
#endif
	 }
	 if (ar || ag || ab ) lastc ++;
#ifndef MKLIB
	 if (verbose>2) fprintf(stderr, "\n");
#endif
      }

      cnt_red++; cnt_grn++; cnt_blu++;

      idx_to_red[cnt_red] = MAX_VALUE-1;
      idx_to_grn[cnt_grn] = MAX_VALUE-1;
      idx_to_blu[cnt_blu] = MAX_VALUE-1;
   }

#ifndef MKLIB
   if (verbose>2) {
      for (i=0; i<cnt_red+1; i++)
	 fprintf(stderr, "red_minicube[%d] = %d\n", i, idx_to_red[i]);
      for (i=0; i<cnt_grn+1; i++)
	 fprintf(stderr, "grn_minicube[%d] = %d\n", i, idx_to_grn[i]);
      for (i=0; i<cnt_blu+1; i++)
	 fprintf(stderr, "blu_minicube[%d] = %d\n", i, idx_to_blu[i]);
   }
#endif

   /* Scale the quantisation index lookup tables for each colour */
   for(i=0; i<MAX_VALUE; i++)
      idx_red[i] = idx_red[i] * cnt_grn * cnt_blu * 2;
   for(i=0; i<MAX_VALUE; i++)
      idx_grn[i] = idx_grn[i] * cnt_blu * 2;
   for(i=0; i<MAX_VALUE; i++)
      idx_blu[i] = idx_blu[i] * 2;

   /* Populate translation table for mini-cubes to 256 colour map. */
   {
      cnt_cells = cnt_red * cnt_grn * cnt_blu;
      clut_conv = malloc(cnt_cells * 2 * sizeof(clut_conv[0]));

#ifndef MKLIB
      if (verbose)
         fprintf(stderr, "%s: Building array of %d*%d*%d => %d mini cubes\n", 
		  progname, 
	          cnt_red, cnt_grn, cnt_blu, cnt_cells);
#endif

      for(r=0; r<cnt_red; r++)
	 for(g=0; g<cnt_grn; g++)
	    for(b=0; b<cnt_blu; b++)
	    {
	       int pix_red, pix_grn, pix_blu;

	       int pix_mono, pix_col_red, pix_col_grn, pix_col_blu;
	       int mono_error, colour_error, random_error;

	       int clutno;
	       int mono_ht = 0, colour_ht = 0;
	       int to_use = 0;

	       /* Choose centre of minicube to represent it. */
	       pix_red = (idx_to_red[r] + idx_to_red[r+1]) / 2;
	       pix_grn = (idx_to_grn[g] + idx_to_grn[g+1]) / 2;
	       pix_blu = (idx_to_blu[b] + idx_to_blu[b+1]) / 2;

	       pix_col_red = quant_red_ht[pix_red];
	       pix_col_grn = quant_grn_ht[pix_grn];
	       pix_col_blu = quant_blu_ht[pix_blu];

	       /* Prefer single entry over ht */
	       colour_ht =
	           ( (quant_red_down[pix_red] != quant_red_up[pix_red]) ||
	             (quant_grn_down[pix_grn] != quant_grn_up[pix_grn]) ||
	             (quant_blu_down[pix_blu] != quant_blu_up[pix_blu]));

	       pix_mono = quant_wht_ht[to_grey(pix_red, pix_grn, pix_blu)];

	       /* Prefer single entry over ht for mono too. */
	       mono_ht = (quant_wht_down[pix_mono] != quant_wht_up[pix_mono]);

#ifndef MKLIB
               if (verbose>3) {
		  fprintf(stderr, "clut_conv[%d] = ", (((r*cnt_grn)+g)*cnt_blu + b)*2 );
		  fprintf(stderr, "(%d,%d,%d) => ", r,g,b);
		  fprintf(stderr, "(%d,%d,%d) => ", 
		          pix_red, pix_grn, pix_blu, pix_mono);
		  fprintf(stderr, "(%d,%d,%d,%d) => ", 
		          pix_col_red, pix_col_grn, pix_col_blu, pix_mono);
	       }
#endif

	       if (num_red != 0 && num_grn != 0 && num_blu != 0)
		  colour_error = find_diff(pix_red, pix_grn, pix_blu,
				       pix_col_red, pix_col_grn, pix_col_blu) +
				 colour_ht;
               else
	          colour_error = -1;

	       if (num_wht != 0) {
		  mono_error = find_diff(pix_red, pix_grn, pix_blu,
					  pix_mono, pix_mono, pix_mono) +
			       mono_ht;

		  /* Prefer mono entries for mono input */
		  if (pix_mono == quant_wht_ht[pix_red] &&
		      pix_mono == quant_wht_ht[pix_grn] &&
		      pix_mono == quant_wht_ht[pix_blu])
		     mono_error /= 2;

	       } else
	          mono_error = -1;

	       if (random_palette) {
	          clutno = find_palette_entry(pix_red, pix_grn, pix_blu);
		  random_error = find_diff(pix_red, pix_grn, pix_blu,
				    clut[clutno][0], clut[clutno][1], clut[clutno][2]);
	       } else
	          random_error = -1;

#ifndef MKLIB
               if (verbose>3) {
		  fprintf(stderr, "M%d,C%d,R%d => ", mono_error, colour_error, random_error);
	       }
#endif

	       to_use = 0;
	       if (mono_error != -1) to_use |= 1;
	       if (colour_error != -1) to_use |= 2;
	       if (random_error != -1) to_use |= 4;

	       if ((to_use & 3) == 3) {
		  if (colour_error > mono_error) to_use &= ~2;
		  if (mono_error > colour_error) to_use &= ~1;
	       }
	       if ((to_use & 5) == 5) {
		  if (random_error > mono_error) to_use &= ~4;
		  if (mono_error > random_error) to_use &= ~1;
	       }

	       if (to_use & 1) {
#ifndef MKLIB
		  if (verbose>3) {
		     fprintf(stderr, "M clut[%d],",
			clut_mono_index[fidx_wht[quant_wht_up[pix_mono]]]);
		     fprintf(stderr, "clut[%d]\n",
			clut_mono_index[fidx_wht[quant_wht_down[pix_mono]]]);
		  }
#endif

		  // If this is a grey pixel ?
		  clut_conv[(((r*cnt_grn)+g)*cnt_blu+b)*2+1] =
		     clut_mono_index[fidx_wht[quant_wht_up[pix_mono]]];

		  clut_conv[(((r*cnt_grn)+g)*cnt_blu+b)*2] =
		     clut_mono_index[fidx_wht[quant_wht_down[pix_mono]]];
	       }
	       else if (to_use & 2)
	       {
		  int colour_index_up =
		     clut_colour_index[
		        ((fidx_red[quant_red_up[pix_col_red]] * num_grn) +
		          fidx_grn[quant_grn_up[pix_col_grn]]) * num_blu +
		          fidx_blu[quant_blu_up[pix_col_blu]]
			  ];

		  int colour_index_down =
		     clut_colour_index[
		        ((fidx_red[quant_red_down[pix_col_red]] * num_grn) +
		          fidx_grn[quant_grn_down[pix_col_grn]]) * num_blu +
		          fidx_blu[quant_blu_down[pix_col_blu]]
			  ];

#ifndef MKLIB
		  if (verbose>3) {
		     fprintf(stderr, "C clut[%d],", colour_index_up);
		     fprintf(stderr, "clut[%d]\n", colour_index_down);
		  }
#endif

		  clut_conv[(((r*cnt_grn)+g)*cnt_blu+b)*2+1] =
		     colour_index_up;

		  clut_conv[(((r*cnt_grn)+g)*cnt_blu+b)*2] =
		     colour_index_down;
	       }
	       else if (to_use & 4)
	       {
#ifndef MKLIB
		  if (verbose>3)
		     fprintf(stderr, "P clut[%d]\n", clutno);
#endif

		  clut_conv[(((r*cnt_grn)+g)*cnt_blu+b)*2] =
		  clut_conv[(((r*cnt_grn)+g)*cnt_blu+b)*2+1] =
		     clutno;
	       }
	    }

      /* Check the table, the conversion for a clut entry may not be converted
       * to that clut entry if the distance function measures another colour
       * as closer. This should only happen with '-R'. */

      for(i=0; i<clut_size; i++) {
	 int clutno1 = 
	    clut_conv[
	      idx_red[clut[i][0]] +
	      idx_grn[clut[i][1]] +
	      idx_blu[clut[i][2]] ];

	 int clutno2 = 
	    clut_conv[
	      idx_red[clut[i][0]] +
	      idx_grn[clut[i][1]] +
	      idx_blu[clut[i][2]] + 1];


	 if (clutno1 != i || clutno2 != i) {
	    int fixable = 0;

	    if (clutno1 == clutno2) {
	       if (idx_red[clut[i][0]] +
		   idx_grn[clut[i][1]] +
		   idx_blu[clut[i][2]] !=
	           idx_red[clut[clutno1][0]] +
		   idx_grn[clut[clutno1][1]] +
		   idx_blu[clut[clutno1][2]])

		  fixable = 1;
	    } else 
	       fixable = 1;

#ifndef MKLIB
	    if (verbose>=fixable) {
	       fprintf(stderr, "%s: ", progname);
	       fprintf(stderr, "Conversion for clut %d maps to %d,%d: ", i, 
				clutno1, clutno2);
	       fprintf(stderr, "ie (%d,%d,%d) ",
		    clut[i][0], clut[i][1], clut[i][2]);
	       fprintf(stderr, "maps to (%d,%d,%d),(%d,%d,%d): ",
		    clut[clutno1][0], clut[clutno1][1], clut[clutno1][2],
		    clut[clutno2][0], clut[clutno2][1], clut[clutno2][2]);
	       fprintf(stderr, "minicube= %d+%d+%d => %d",
		    idx_red[clut[i][0]] / cnt_grn / cnt_blu / 2,
		    idx_grn[clut[i][1]] / cnt_blu / 2,
		    idx_blu[clut[i][2]] / 2,
		       idx_red[clut[i][0]] +
		       idx_grn[clut[i][1]] +
		       idx_blu[clut[i][2]]
		    );
	       if (fixable)
		  fprintf(stderr, " fixed");
	       else
		  fprintf(stderr, " -- ERRORED");
	       fprintf(stderr, "\n");
	    }
#endif

	    if (fixable) {
	       clut_conv[
		 idx_red[clut[i][0]] +
		 idx_grn[clut[i][1]] +
		 idx_blu[clut[i][2]] ] = 
	       clut_conv[
		 idx_red[clut[i][0]] +
		 idx_grn[clut[i][1]] +
		 idx_blu[clut[i][2]] + 1 ] = 
	       i;
	    }
	 }
      }
   }

#ifndef MKLIB
   if (verbose>4) {
      int i,j,k;

      fprintf(stderr, "unsigned char clut[%d][3] = {\n", clut_size);
      for(i=0; i<clut_size; i++) {
	 fprintf(stderr, "   {%3d,%3d,%3d},\n", 
	                 clut[i][0], clut[i][1], clut[i][2]);
      }
      fprintf(stderr, "};\n\n");

      fprintf(stderr, "int idx_red[] = {\n");
      for(i=0; i<MAX_VALUE; i+=16) {
         for(j=0; j<16; j++)
	    fprintf(stderr, "%4d,", idx_red[i+j]);
	 fprintf(stderr, "\n");
      }
      fprintf(stderr, "};\n\n");

      fprintf(stderr, "int idx_grn[] = {\n");
      for(i=0; i<MAX_VALUE; i+=16) {
         for(j=0; j<16; j++)
	    fprintf(stderr, "%4d,", idx_grn[i+j]);
	 fprintf(stderr, "\n");
      }
      fprintf(stderr, "};\n\n");

      fprintf(stderr, "int idx_blu[] = {\n");
      for(i=0; i<MAX_VALUE; i+=16) {
         for(j=0; j<16; j++)
	    fprintf(stderr, "%4d,", idx_blu[i+j]);
	 fprintf(stderr, "\n");
      }
      fprintf(stderr, "};\n\n");

      fprintf(stderr, "static unsigned char clut_conv_data[] = {\n");
      for(i=0; i<cnt_cells*2; i+=cnt_blu) {
         for(j=0; j<cnt_blu; j++)
	    fprintf(stderr, "%3d,", clut_conv[i+j]);
	 fprintf(stderr, "\n");
	 if ((i+cnt_blu) % (cnt_grn*cnt_blu*2) == 0)
	    fprintf(stderr, "\n");
      }
      fprintf(stderr, "};\n\n");
      fprintf(stderr, "unsigned char * clut_conv = clut_conv_data;\n");
   }
#endif
   return;
}

void
fill_ht_tabs(int num, int *pal, int *down, int *up, int *ht)
{
   /* This divides the counts between each pair of colours into four equal
    * zones; these zones are where colours are quantized up or down to the
    * normal colour or the 50% dither. */

   int   col, i, qt;
   for (col = 0; col < MAX_VALUE; col++) {
      up[col] = down[col] = ht[col] = 0;
   }
   if (num == 0) return;

   for (col = 0; col < MAX_VALUE; col++) {
      for (i = -1; i < num; i++) {
	 if (col <= pal[i + 1])
	    break;
      }
      /* Col is in pal[i]+1 .. pal[i+1] */

      if (col == pal[i + 1]) {	/* An exact palette entry (including zero). */
	 down[col] = col;
	 up[col] = col;
	 ht[col] = col;
	 continue;
      }
      /* Col is in pal[i]+1 .. pal[i+1]-1 */

      ht[col] = (pal[i] + pal[i + 1]) / 2;

      if (col == ht[col]) {	/* An exact halftone value */
	 down[col] = pal[i];
	 up[col] = pal[i + 1];
	 continue;
      }

      qt = (pal[i] + ht[col]) / 2;

      if (col <= qt) {		/* Lower quarter, round to pure lower */
	 down[col] = pal[i];
	 up[col] = pal[i];
	 ht[col] = pal[i];
	 continue;
      }

      qt = (pal[i + 1] + ht[col]) / 2;

      if (col > qt) {		/* Upper quarter, round to pure upper */
	 down[col] = pal[i + 1];
	 up[col] = pal[i + 1];
	 ht[col] = pal[i + 1];
	 continue;
      }

      down[col] = pal[i];
      up[col] = pal[i + 1];
   }
}

void
fill_rev_tab(int num, int *pal, int *tone)
{
   int   col, i, ht;
   for (col = 0; col < MAX_VALUE; col++) tone[col] = 0;
   if (num == 0) return;

   for (col = 0; col < MAX_VALUE; col++) {
      for (i = -1; i < num; i++) {
	 if (col <= pal[i + 1])
	    break;
      }
      /* Col is in pal[i]+1 .. pal[i+1] */

      if (col == pal[i + 1]) {	/* An exact palette entry (including zero). */
	 tone[col] = i+1;
	 continue;
      }
      /* Col is in pal[i]+1 .. pal[i+1]-1 */

      ht = (pal[i] + pal[i + 1]) / 2;

      if (col <= ht) {	/* Lower value */
	 tone[col] = i;
	 continue;
      }

      tone[col] = i+1; /* Upper value */
   }
}

void
fill_lum(char * name, int size, int *rgb)
{
   /* This generates even spaced values, but the rest of the code works fine
    * with any random spacing. */
   int   c, i;
   double col, v;

   for (c = 0; c < MAX_VALUE; c++) rgb[c] = 0;

   switch (size) 
   {
      case 16: for (c = 0; c < size; c++) rgb[c] = (c<<4) + (c); break;

      /* Standard version.
      */
      case 32: for (c = 0; c < size; c++) rgb[c] = (c<<3) + (c>>2); break;
      case 64: for (c = 0; c < size; c++) rgb[c] = (c<<2) + (c>>4); break;

      /* Alternate version that includes all the levels from the 32 case.
      case 32: for (c = 0; c < size; c++) rgb[c] = (c<<3) + (c>>2); break;
      case 64: for (c = 0; c < size; c++) rgb[c] = (c<<2) + ((c>>3)&3); break;
       */

      /* This adjusts the 32 level case by extending it twice. To 6 then 8.
      case 32: for (c = 0; c < size; c++) {
		  i = (c<<1) + (c>>4);
                  rgb[c] = (i<<2) + (i>>4);
               }
	       break;

      case 64: for (c = 0; c < size; c++) rgb[c] = (c<<2) + (c>>4); break;
      */

      case 128: for (c = 0; c < size; c++) rgb[c] = (c<<1) + (c>>6); break;
      case 256: for (c = 0; c < size; c++) rgb[c] = c; break;

      default:
	 /* This should give exactly the same answers as above.
	  * Except for the alternate 64/32 level ones. */

	 for (c = 0; c < size; c++) {
	    col = 0;
	    v = (double) c / size;
	    for (i = 1; i < 10; i++) {
	       col = col + v;
	       v = v / size;
	    }

	    rgb[c] = (int) (col * (MAX_VALUE-1) + 0.5);

	 }
	 break;
   }

#ifndef MKLIB
   if (verbose>2)
      for (c = 0; c < size; c++)
        fprintf(stderr, "%s[%d] = %d\n", name, c, rgb[c]);
#endif
}

void
build_regular_clut(int *red, int *green, int *blue, int *white,
                   int *clut_mono_index, int *clut_colour_index)
{
   int r,g,b,w;
   int i,j,k;

#ifndef MKLIB
   /* Build a clut */
   if (verbose>2)
      fprintf(stderr, "Est Colourmap size %d*%d*%d & %d => %d\n",
	 num_red, num_grn, num_blu, num_wht,
	 num_red * num_grn * num_blu + num_wht -
	 ((num_red * num_grn * num_blu != 0 && num_wht != 0)?2:0));
#endif

   clut_size = 0;

   /* Clut limited to 256 colours */
   if (num_red * num_grn * num_blu > MAX_PALLET) return;

   for(i=0; i<MAX_PALLET; i++)
      clut_mono_index[i] = clut_colour_index[i] = 0;

   if (num_wht > 1) {
      /* First two cells B&W */
      clut[0][0] = clut[0][1] = clut[0][2] = 0;
      clut[1][0] = clut[1][1] = clut[1][2] = (MAX_VALUE-1);

      clut_mono_index[num_wht-1] = 1;

      /* Next the grey scale */
      i = 2;
      for(w=0; w<num_wht; w++) {
	 if (white[w] == 0 || white[w] == (MAX_VALUE-1)) continue;
	 clut[i][0] = clut[i][1] = clut[i][2] = white[w];
	 clut_mono_index[w] = i;
	 i++;
	 if (i>MAX_PALLET) return;
      }
      k = i;
   } else
      k = i = 0;

   /* And the colour cube */
   j = 0;
   for(r=0; r<num_red; r++)
      for(g=0; g<num_grn; g++)
	 for(b=0; b<num_blu; b++)
	 {
	    int ok = 1;
	    if (red[r] == green[g] && red[r] == blue[b]) {
               for(w=0;w<k; w++) {
                  if (clut[w][0] == red[r] &&
                      clut[w][1] == green[g] &&
                      clut[w][2] == blue[b]) {
		     ok = 0;
		     clut_colour_index[j++] = w;
	             break;
		  }
	       }
	    }
	    if (ok) {
	       clut[i][0] = red[r];
	       clut[i][1] = green[g];
	       clut[i][2] = blue[b];
	       clut_colour_index[j++] = i;
	       i++;
	       if (i>MAX_PALLET) return;
	    }
	 }
   clut_size = i;
}

int
to_grey(int red, int green, int blue)
{
   /* Lots of options so you can choose the wrong one every time. */
   switch(greystyle) {
   default:
      /* Use plain ratio. */
      return (red + green + blue) / 3;

   case 1:
      /* Use B&W TV ratio. AKA RGB to YUV (YCrCb) conversion. */
      return (red * 2989 + green * 5866 + blue * 1145) / 10000;

   case 2:
      /* Use Ratios from Rec 709 (CIE XYZ) */
      return (red * 212671 + green * 715160 + blue *  72169) / 1000000;

   case 3:
      {
	 /* Use luminosity from HSL. Average of min & max. */
	 int maxcol = red, mincol = red;

	 if (green > maxcol) maxcol = green;
	 if (blue > maxcol) maxcol = blue;

	 if (green < mincol) mincol = green;
	 if (blue < mincol) mincol = blue;

	 return (maxcol+mincol)/2;
      }

   case 4:
      {
	 /* Use max of r/g/b (from HSV). */
	 int maxcol = red;

	 if (green > maxcol) maxcol = green;
	 if (blue > maxcol) maxcol = blue;

	 return maxcol;
      }

   case 5:
      {
	 /* Use average of brightest. */
	 int mincol = red;

	 if (green < mincol) mincol = green;
	 if (blue < mincol) mincol = blue;

	 return (red + green + blue - mincol) / 2;
      }

   case 6:
      {
	 /* My eyes ... almost. */
	 int rb;
	 if (blue > red)  rb = ( blue * 80 + red * 20 ) / 100;
	 else             rb = ( blue * 20 + red * 80 ) / 100;
	 if (green > rb ) return (green * 66 + rb * 34) / 100;
	 else             return (green * 34 + rb * 66) / 100;
      }
   }
}

int
find_diff(int red_a, int green_a, int blue_a, int red_b, int green_b, int blue_b)
{
   /* How to describe the error ... humm. */
   /* I suppose we should use pythagoras, but I don't need exact numbers. */
   /* Also note I'm only interested in this when comparing against a uniform 
    * palette, this means the 3:6:1 ratio isn't important. */
   /* OTOH this isn't a true uniform palette because of the greys */

   int toterr=0, err;
   int grey_a, grey_b;

   /* Need to adjust for the non-linear rgb->grey conversion */
   grey_a = to_grey(red_a, green_a, blue_a);
   grey_b = to_grey(red_b, green_b, blue_b);

   err = grey_a - grey_b;
   toterr += err*err;

   /* Now the approx differences in the chroma */
   red_a -= grey_a; green_a -= grey_a; blue_a -= grey_a;
   red_b -= grey_b; green_b -= grey_b; blue_b -= grey_b;

   err = red_a - red_b;
   toterr += err*err;

   err = green_a - green_b;
   toterr += err*err;

   err = blue_a - blue_b;
   toterr += err*err;

   return toterr;
}

int
find_palette_entry(int red, int green, int blue)
{
   int i, e;
   int clutno = 0;
   int cur_error = find_diff(red, green, blue, clut[0][0], clut[0][1], clut[0][2]);

   for(i=1; i<clut_size; i++) 
   {
      e = find_diff(red, green, blue, clut[i][0], clut[i][1], clut[i][2]);
      if (e < cur_error) {
         cur_error = e;
	 clutno = i;
      }
   }
   return clutno;
}

void fill_vga_pal(int * white, int * mixed, int * num_mixed, int *clut_mono_index, int *clut_colour_index) {
   int i;
   int maxval = 0;

   for(i=0; i<MAX_PALLET; i++)
      clut_mono_index[i] = clut_colour_index[i] = 0;

   for(i=0; i<256*3; i++)
      if( defined_pal[i] > maxval ) maxval = defined_pal[i];

   num_wht = 0;
   clut_size = 256;
   for(i=0; i<256; i++) {
      clut[i][0] = defined_pal[i*3 + 0] * (MAX_VALUE-1) / maxval;
      clut[i][1] = defined_pal[i*3 + 1] * (MAX_VALUE-1) / maxval;
      clut[i][2] = defined_pal[i*3 + 2] * (MAX_VALUE-1) / maxval;

      if (clut[i][0] == clut[i][1] && 
          clut[i][0] == clut[i][2]) {
         /* It's a grey */
	 int dupl = 0, j;

	 for(j=0; j<num_wht; j++)
	    if(white[j] == clut[i][0]) {
	       dupl = 1;
	       break;
	    }

	 if (!dupl) {
	    /* Insertion sort. */
	    white[num_wht] = clut[i][0];
	    clut_mono_index[num_wht] = i;
	    num_wht++;
	    for(j=num_wht-1; j>0; j--) {
	       if (white[j-1] > white[j]) {
	          int k = white[j-1];
		  white[j-1] = white[j];
		  white[j] = k;
	          k = clut_mono_index[j-1];
		  clut_mono_index[j-1] = clut_mono_index[j];
		  clut_mono_index[j] = k;
	       }
	    }
	 }
      }
   }

   /* Find levels used in palette. */
   *num_mixed = 0;
   for(i=0; i<256 * 3; i++) {
      int dupl = 0, j;
      int sample = defined_pal[i] * (MAX_VALUE-1) / maxval;

      for(j=0; j<*num_mixed; j++)
	 if(mixed[j] == sample) {
	    dupl = 1;
	    break;
	 }

      if (!dupl) {
	 /* Insertion sort. */
	 mixed[*num_mixed] = sample;
	 (*num_mixed)++;
	 for(j=*num_mixed-1; j>0; j--) {
	    if (mixed[j-1] > mixed[j]) {
	       int k = mixed[j-1];
	       mixed[j-1] = mixed[j];
	       mixed[j] = k;
	    }
	 }
      }
   }

#ifndef MKLIB
   if (verbose>2) {
      for(i=0; i<num_wht; i++)
        fprintf(stderr, "vgagrey[%d] = %d\n", i, white[i]);
      for(i=0; i<*num_mixed; i++)
        fprintf(stderr, "vgamix[%d] = %d\n", i, mixed[i]);
   }
#endif
}

static unsigned char vgaDefault[768] =
{
     0,  0,  0,    0,  0, 42,    0, 42,  0,    0, 42, 42,
    42,  0,  0,   42,  0, 42,   42, 21,  0,   42, 42, 42,
    21, 21, 21,   21, 21, 63,   21, 63, 21,   21, 63, 63,
    63, 21, 21,   63, 21, 63,   63, 63, 21,   63, 63, 63,
     0,  0,  0,    5,  5,  5,    8,  8,  8,   11, 11, 11,
    14, 14, 14,   17, 17, 17,   20, 20, 20,   24, 24, 24,
    28, 28, 28,   32, 32, 32,   36, 36, 36,   40, 40, 40,
    45, 45, 45,   50, 50, 50,   56, 56, 56,   63, 63, 63,
     0,  0, 63,   16,  0, 63,   31,  0, 63,   47,  0, 63,
    63,  0, 63,   63,  0, 47,   63,  0, 31,   63,  0, 16,
    63,  0,  0,   63, 16,  0,   63, 31,  0,   63, 47,  0,
    63, 63,  0,   47, 63,  0,   31, 63,  0,   16, 63,  0,
     0, 63,  0,    0, 63, 16,    0, 63, 31,    0, 63, 47,
     0, 63, 63,    0, 47, 63,    0, 31, 63,    0, 16, 63,
    31, 31, 63,   39, 31, 63,   47, 31, 63,   55, 31, 63,
    63, 31, 63,   63, 31, 55,   63, 31, 47,   63, 31, 39,
    63, 31, 31,   63, 39, 31,   63, 47, 31,   63, 55, 31,
    63, 63, 31,   55, 63, 31,   47, 63, 31,   39, 63, 31,
    31, 63, 31,   31, 63, 39,   31, 63, 47,   31, 63, 55,
    31, 63, 63,   31, 55, 63,   31, 47, 63,   31, 39, 63,
    45, 45, 63,   49, 45, 63,   54, 45, 63,   58, 45, 63,
    63, 45, 63,   63, 45, 58,   63, 45, 54,   63, 45, 49,
    63, 45, 45,   63, 49, 45,   63, 54, 45,   63, 58, 45,
    63, 63, 45,   58, 63, 45,   54, 63, 45,   49, 63, 45,
    45, 63, 45,   45, 63, 49,   45, 63, 54,   45, 63, 58,
    45, 63, 63,   45, 58, 63,   45, 54, 63,   45, 49, 63,
     0,  0, 28,    7,  0, 28,   14,  0, 28,   21,  0, 28,
    28,  0, 28,   28,  0, 21,   28,  0, 14,   28,  0,  7,
    28,  0,  0,   28,  7,  0,   28, 14,  0,   28, 21,  0,
    28, 28,  0,   21, 28,  0,   14, 28,  0,    7, 28,  0,
     0, 28,  0,    0, 28,  7,    0, 28, 14,    0, 28, 21,
     0, 28, 28,    0, 21, 28,    0, 14, 28,    0,  7, 28,
    14, 14, 28,   17, 14, 28,   21, 14, 28,   24, 14, 28,
    28, 14, 28,   28, 14, 24,   28, 14, 21,   28, 14, 17,
    28, 14, 14,   28, 17, 14,   28, 21, 14,   28, 24, 14,
    28, 28, 14,   24, 28, 14,   21, 28, 14,   17, 28, 14,
    14, 28, 14,   14, 28, 17,   14, 28, 21,   14, 28, 24,
    14, 28, 28,   14, 24, 28,   14, 21, 28,   14, 17, 28,
    20, 20, 28,   22, 20, 28,   24, 20, 28,   26, 20, 28,
    28, 20, 28,   28, 20, 26,   28, 20, 24,   28, 20, 22,
    28, 20, 20,   28, 22, 20,   28, 24, 20,   28, 26, 20,
    28, 28, 20,   26, 28, 20,   24, 28, 20,   22, 28, 20,
    20, 28, 20,   20, 28, 22,   20, 28, 24,   20, 28, 26,
    20, 28, 28,   20, 26, 28,   20, 24, 28,   20, 22, 28,
     0,  0, 16,    4,  0, 16,    8,  0, 16,   12,  0, 16,
    16,  0, 16,   16,  0, 12,   16,  0,  8,   16,  0,  4,
    16,  0,  0,   16,  4,  0,   16,  8,  0,   16, 12,  0,
    16, 16,  0,   12, 16,  0,    8, 16,  0,    4, 16,  0,
     0, 16,  0,    0, 16,  4,    0, 16,  8,    0, 16, 12,
     0, 16, 16,    0, 12, 16,    0,  8, 16,    0,  4, 16,
     8,  8, 16,   10,  8, 16,   12,  8, 16,   14,  8, 16,
    16,  8, 16,   16,  8, 14,   16,  8, 12,   16,  8, 10,
    16,  8,  8,   16, 10,  8,   16, 12,  8,   16, 14,  8,
    16, 16,  8,   14, 16,  8,   12, 16,  8,   10, 16,  8,
     8, 16,  8,    8, 16, 10,    8, 16, 12,    8, 16, 14,
     8, 16, 16,    8, 14, 16,    8, 12, 16,    8, 10, 16,
    11, 11, 16,   12, 11, 16,   13, 11, 16,   15, 11, 16,
    16, 11, 16,   16, 11, 15,   16, 11, 13,   16, 11, 12,
    16, 11, 11,   16, 12, 11,   16, 13, 11,   16, 15, 11,
    16, 16, 11,   15, 16, 11,   13, 16, 11,   12, 16, 11,
    11, 16, 11,   11, 16, 12,   11, 16, 13,   11, 16, 15,
    11, 16, 16,   11, 15, 16,   11, 13, 16,   11, 12, 16,
     0,  0,  0,    0,  0,  0,    0,  0,  0,    0,  0,  0,
     0,  0,  0,    0,  0,  0,    0,  0,  0,    0,  0,  0,
};

static unsigned char yuvDefault[768] =
{
  0,  0,  0,
  0,254,231,
  4, 38,214,
  4, 48,158,
  4, 59,103,
  4, 70, 48,
  8,119,206,
  8,129,151,
  8,140, 96,
  8,151, 40,
 12,189,254,
 12,200,199,
 12,211,144,
 12,221, 88,
 12,232, 33,
 16,  5, 71,
 16, 16, 16,
 20, 54,230,
 20, 64,174,
 20, 75,119,
 20, 86, 64,
 20, 97,  8,
 24,135,222,
 24,145,167,
 24,156,112,
 24,167, 56,
 24,178,  1,
 28,216,215,
 28,227,160,
 28,237,104,
 28,248, 49,
 32, 10,142,
 32, 21, 87,
 32, 32, 32,
 36, 70,246,
 36, 80,190,
 36, 91,135,
 36,102, 80,
 36,113, 24,
 40,151,238,
 40,161,183,
 40,172,128,
 40,183, 72,
 40,194, 17,
 44,232,231,
 44,243,176,
 44,253,120,
 48, 15,214,
 48, 26,158,
 48, 37,103,
 48, 48, 48,
 52, 96,206,
 52,107,151,
 52,118, 96,
 52,129, 40,
 56,167,254,
 56,177,199,
 56,188,144,
 56,199, 88,
 56,210, 33,
 60,248,247,
 64, 31,230,
 64, 42,174,
 64, 53,119,
 64, 64, 64,
 64, 74,  8,
 68,112,222,
 68,123,167,
 68,134,112,
 68,145, 56,
 68,155,  1,
 72,193,215,
 72,204,160,
 72,215,104,
 72,226, 49,
 75,  9, 32,
 80, 47,246,
 80, 58,190,
 80, 69,135,
 80, 80, 80,
 80, 90, 24,
 84,128,238,
 84,139,183,
 84,150,128,
 84,161, 72,
 84,171, 17,
 88,209,231,
 88,220,176,
 88,231,120,
 88,242, 65,
 88,252,  9,
 91,  4,158,
 91, 14,103,
 91, 25, 48,
 96, 74,206,
 96, 85,151,
 96, 96, 96,
 96,106, 40,
100,144,254,
100,155,199,
100,166,144,
100,177, 88,
100,187, 33,
104,225,247,
104,236,192,
104,247,136,
107,  9,230,
107, 20,174,
107, 30,119,
107, 41, 64,
107, 52,  8,
112, 90,222,
112,101,167,
112,112,112,
112,122, 56,
112,133,  1,
116,171,215,
116,182,160,
116,193,104,
116,203, 49,
120,252,208,
123, 25,246,
123, 36,190,
123, 46,135,
123, 57, 80,
123, 68, 24,
128,106,238,
128,117,183,
128,128,128,
128,138, 72,
128,149, 17,
132,187,231,
132,198,176,
132,209,120,
132,219, 65,
132,230,  9,
135,  3, 48,
139, 52,206,
139, 62,151,
139, 73, 96,
139, 84, 40,
144,122,254,
144,133,199,
144,144,144,
144,154, 88,
144,165, 33,
148,203,247,
148,214,192,
148,225,136,
148,235, 81,
148,246, 25,
151,  8,119,
151, 19, 64,
151, 30,  8,
155, 68,222,
155, 78,167,
155, 89,112,
155,100, 56,
155,111,  1,
160,149,215,
160,160,160,
160,170,104,
160,181, 49,
164,230,208,
164,241,152,
164,251, 97,
167,  3,246,
167, 13,190,
167, 24,135,
167, 35, 80,
167, 46, 24,
171, 84,238,
171, 94,183,
171,105,128,
171,116, 72,
171,127, 17,
176,165,231,
176,176,176,
176,186,120,
176,197, 65,
176,208,  9,
180,246,224,
183, 29,206,
183, 40,151,
183, 51, 96,
183, 62, 40,
187,100,254,
187,110,199,
187,121,144,
187,132, 88,
187,143, 33,
192,181,247,
192,192,192,
192,202,136,
192,213, 81,
192,224, 25,
195,  7,  8,
199, 45,222,
199, 56,167,
199, 67,112,
199, 78, 56,
199, 88,  1,
203,126,215,
203,137,160,
203,148,104,
203,159, 49,
208,208,208,
208,218,152,
208,229, 97,
208,240, 41,
211,  2,135,
211, 12, 80,
211, 23, 24,
215, 61,238,
215, 72,183,
215, 83,128,
215, 94, 72,
215,104, 17,
219,142,231,
219,153,176,
219,164,120,
219,175, 65,
219,185,  9,
224,224,224,
224,234,168,
224,245,113,
227,  7,206,
227, 18,151,
227, 28, 96,
227, 39, 40,
231, 77,254,
231, 88,199,
231, 99,144,
231,110, 88,
231,120, 33,
235,158,247,
235,169,192,
235,180,136,
235,191, 81,
235,201, 25,
240,240,240,
240,250,184,
243, 23,222,
243, 34,167,
243, 44,112,
243, 55, 56,
243, 66,  1,
247,104,215,
247,115,160,
247,126,104,
247,136, 49,
251,185,208,
251,196,152,
251,207, 97,
251,217, 41,
255,  1, 24,
};

/* TODO
 *
 * 1) If there are only greys and grey style is linear (0,1 or 2) the cube
 *    table isn't required; the addition is sufficient. The table can contain
 *    256 entries of 0..255 or 768 entries for proper rounding. More entries 
 *    also allows for a pseudo (or deep) grey scale.
 *
 * 2) Allow a non-linear constructor; user specified sets of levels for each
 *    of r,g,b,w
 *
 */

