/*
 * Terminal emulator. (c) Copyright R de Bath (1988-1999)
 *
 * This program is a terminal emulator for the IBM PC.
 * It's basic emulation is as very close to the SCO-Xenix ANSI console
 * but it's had a few additions that seemed a good idea at the time.
 *
 * In addition just recently I've added some features that should get it
 * a bit closer to the SCO Unix console too, I'm not likely to do a perfect
 * emulation thought because the SCO-Unix console has so many 'undocumented
 * features'! One thing I have added though is a substitute for the 'mapchan'
 * SCO command - see "ESC ( B"
 *
 * Performance: I have used this on a 16Mhz 286 at 115k2 baud without
 *              RTS flow control and experience NO lost characters.
 *              BUT, it only just manages to keep up so flow control
 *              should still be used.
 *              
 *              I have used it at 115k2 on a 4.77 XT, the serial driver
 *              switches to a polling mode and disables all interrupts
 *              losing characters only if there's a conflict between the
 *              keyboard BIOS and the serial line. This tries to detect
 *              the speed of the PC and configure the delay to fit the PC,
 *              it should work on any PC. But beware, power managment can
 *              defeat this by dropping the CPU speed too far.
 *
 * This program is freely distributible for non-commercial use providing
 * original source and copyrights are intact.
 *                   R. de Bath <rdebath@poboxes.com> <rdebath@cix.co.uk>
 */

#define VERSION "1.1.17"

/*
 * $Compile: bcc -O -Ob -Oe -Oi -Ot talk.c
 *
 * TODO:
 *
 * - If TCP host is of form 'user@hostname' do rlogin to host.
 * - Implement RFC 1097
 * - Bitmap support for AT&T 6300 mode $40 (640x400x2)
 * - Add support for Xterm mouse
 * - Buffer printer output
 * - Add CSI to prevent update for N (<10) seconds (N=0 => doit now)
 * - Add file operations (open, read/write block, close)
 * - Add ZMODEM challange string, built in Zmodem?
 * - Add scan code mode (Raw and cooked)
 * - Add local echo mode. (Only ascii chars ?)
 * - Add magic echo mode - like local echo but display tempoary.
 * - Add CP437 -> CP850 translation
 *
 *****************************************************************************

      ANSI Emulation.
      ===============

   Special characters

   ^G      Beep
   ^H      Backspace
   ^I      Tab
   ^J      Linefeed
   ^L      Clear screen
   ^M      Carriage return
   ^V      Avatar code prefix.
   ^X      Cancel Escape code or string                    (XXX But ZMODEM)
   ^[      Escape code prefix

   Escape codes

   ^[ [    CSI code - see below.
   ^[ P    DCS Code, as CSI followed by string and ST (DEC)
   ^[ \    ST - String terminator. (DEC)

   ^[ (    Font select (DEC)
	    U  IBM CP 437
	    u  IBM CP 437 with 0x00-0x7f replicated to 0x80-0xFF
	    B  ISO 8859-1         + DIRECT FONT 0x00-0x1F in 0x80-0x9F.
	    0  VT100 Graphics     + DIRECT FONT 0x80-0xFF
	    A  UK ASCII

   ^[ 7    Save cursor position    (DEC)                   (XXX Attributes?)
   ^[ 8    Restore cursor position (DEC)                   (XXX Attributes?)

   ^[ M    Reverse LF                                      (Not implemented)
   ^[ c    Reset emulator page.

   ^[ Q    SCO Function key redefinition.

   ^[ >    Keyboard normal				   (if AT_BIOS_KEY)
   ^[ =    Keyboard in dosemu keypad mode. v0.66.6	   (if AT_BIOS_KEY)
   ^[ <    Keyboard in dos codes mode.			   (if AT_BIOS_KEY)

   ^[ ...  Escape followed by an non-printable ascii character makes that
           character a literal raw font printable.         (Extra)

   Simple ANSI CSI codes

   CSI  A  Cursor Up
   CSI  B  Cursor Down
   CSI  C  Cursor Right
   CSI  D  Cursor Left
   CSI  H  Cursor to position.
   CSI  J  Screen area clear (SCO honours attributes)
   CSI  K  Line area clear (SCO honours attributes)
   CSI  m  Attributes (See detail)
   CSI  s  Save cursor position
   CSI  u  Restore cursor position

   ANSI attributes (max 3 in one seq for SCO Xenix)

           Using the sequence: CSI ... m
   0       Clear attributes
   1       Bold
   2       Set Standard video colour
   3       Enable/disable Blink
   4       Underlink
   5       Blink (or background bold)
   7       Reverse (Also set standard reverse)
   10      Revert character set.
   11      Charset Raw, Print ALL characters except the sequence ^[[
   12      As 11 + flip MSB of character.
   27      Unset reverse.  (SCO Unix)
   30-37   Set foreground colour
   40-47   Set background colour

   SCO ANSI CSI codes

   CSI  @  Insert chars
   CSI  E  Col 0, Cursor Down
   CSI  F  Col 0, Cursor Up
   CSI  H  Cursor to (r,c) position.
   CSI  L  Insert lines
   CSI  M  Delete lines
   CSI  P  Delete characters
   CSI  S  Scroll up
   CSI  T  Scroll Down
   CSI  X  Clear characters
   CSI  Z  Back tab
   CSI  a  Cursor Right
   CSI  e  Col 0, Cursor Down
   CSI  f  Cursor to (r,c) position.
   CSI  g  Write Specific font char (AM=0, Font=Raw, colour=gr_attr)
   CSI =B  Beep type
   CSI =C  Cursor type
   CSI =E  Background bold or blink.
   CSI =F  Default foreground colour (NB Colour is in IBM VGA order)
   CSI =G  Default background colour (NB Colour is in IBM VGA order)
   CSI =H  Reverse foreground colour (NB Colour is in IBM VGA order)
   CSI =I  Reverse background colour (NB Colour is in IBM VGA order)
   CSI =J  Graphic foreground colour (NB Colour is in IBM VGA order)
   CSI =K  Graphic background colour (NB Colour is in IBM VGA order)
   CSI =L  Area clear colour, 0=>current, 1=>standard. (SCO Unix)
   CSI =g  Write Specific font char (AM=0, Font=Raw, colour=current_attr)

   Additional ANSI CSI codes (non-SCO)

   CSI ?lh Set/reset mode (am if arg == 7)
   CSI  i  Printer control.

   CSI $P  Select screen page (0-9)
   CSI $S  Save and replay macros.
   DCS $~  Message line (DCS code)

   OTHERS TODO ...
	   DCS for full setup (Keyboard, font, am, zapmsg, default attrs)
	       - (This page or all pages and default)

	   CSI/DCS for open/read/write/close file.
	   CSI for inquire session hash key.

           Dangerous codes to have 4 digit PIN number (generated for session)

   VT 52 codes - (Not implemented)

         AM type is 0 or 2.
      if c in "ABCDHJK" do_ansi of same code.
      if c == Y -> cursor position.
      if c == I -> ^[M  (Reverse index)
      if c == Z -> xmits("\033\\Z") or something

      if c == .. -> Add attribute and charset extras.
              M -> Delete line
              L -> Insert line
              q -> smso
              p -> rmso

*****************************************************************************
*****************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <dos.h>
#include <bios.h>
#include <process.h>
#include <signal.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>

#define RS8250		/* Hardware RS-232 driver */
#define BEEPER		/* Interrupt driven beeper */
#define MEM_SCR 	/* Use Hardware screen memory */
#define AT_BIOS_KEY	/* AT keyboard + DOSemu keymapping */
#define SCO_KEYMAP	/* Make keyboard look SCOish */

#define XBITMAP		/* Use an AT&T 6300 bitmap screen */

#define NS_EOI		/* Ack the keyboard IRQ early */
#define XKBDRTS		/* Flow control on keyboard interrupt */
#define XFORKDOS 	/* Key to spawn shell */
#define XPRINTER 	/* Almost useless but does (just) work */
#define XZMODEM		/* Beware DSZ has an 16bit for the speed! */
#define XAVATAR		/* Decode dos 'AVATAR' screen codes */

#ifdef MEM_SCR /* All the following are possible only if MEM_SCR is set */

#define SCO_ANSI	/* Decode SCO ansi control codes. */
#define SCO_REMAP	/* Allow SCO key remap functions */
#define MAXPAGE 10	/* Multiple screens */
#define SAVEBLOCK 3072	/* Screen macros */

#define XTSRPROG	/* Currently only works with MSC 5.1 */
#define XAVATAR_PLUS	/* More avatar functions */
#endif

#define	POLL_MODE	/* Switch to polling mode if slow processor */

#ifndef RS8250
#undef  KBDRTS
#endif

/* Old or non-working stuff */
#define XOLDBEEPER
#define XFLDATTR

#if defined(__STDC__) || defined(__BORLANDC__)
#define _(x) x
#else
#define _(x) ()
#endif

#ifdef OLDBEEPER
int duration = 0x800;
int freq     = 0x1000;
int warble   = 1;

int soundval = -1;
int soundcnt = -1;
int soundfreq= -1;
int sounddir = -1;
#endif
#ifdef BEEPER
int duration = 5;
int freq     = 0x600;
int lastfreq;

int soundval = -1;
int soundcnt = -1;

#define TIMER    0x1C
void ( interrupt far *orig_timer_int)();
void interrupt far timer_int();
#endif

#define KBDINT 0x09
void ( interrupt far *orig_kbd_int) _((void));
void interrupt far kbd_int _((void));
#ifdef NS_EOI
int early_ack = 1;
#endif

#ifdef PRINTER
int in_transprt = 0;
int print_dev = 0;
#endif

#define FALSE    0
#define TRUE     !FALSE

#define RS232    0x14
#define INITRS   0
#define WRITECH  1
#define READCH   2
#define STATUS   3
#define FOSINIT  4

#define DTARDY   0x100
#define ZFLAG    0x40

#define CHAROUT  2
#define CHARIN   6

#ifdef AT_BIOS_KEY
#define KEY_PAD     0x8000
#define KEY_SPECIAL 0x4000
#define KEY_OTHER   0x2000
#define KEY_DIRECT  0x1000
#define KEY_ALT     0x0800
#define KEY_ALTGR   0x0400
#define KEY_CTRL    0x0200
#define KEY_SHIFT   0x0100

#define DOS_KEY  (KEY_SPECIAL+KEY_ALT+'d')
#define EXITKEY  (KEY_SPECIAL+KEY_SHIFT)
#define SYSLKEY  (KEY_SPECIAL+KEY_SHIFT)

#define STATE_FLAGS (*(int  far *)0x00400017L)	/* BIOS Shift state */
#define STATE_ALTCD (*(char far *)0x00400019L)	/* BIOS ALT-Compose byte */
#define BIOS_CLOCK  (*(int  far *)0x0040006CL)	/* BIOS Timer */

int kbd_type = -1;
int sysline_warn = 0;
int irq_flag = -1;
#else
#define EXITKEY  0x2D00
#define DOS_KEY  0x2000
#define SYSLKEY  0x1F00
#endif

int doze_type = 0;	/* How to give up a timeslice ... */
int enable_snooze = 1;

void main _((int argc, char ** argv));
void Usage _((void));
int keybd _((void));
int xmit _((int ch));
void putstr _((char * str));
void init_vid _((void));
int test_svga_mode _((void));
void end_vid _((void));
void putscrn _((int c));

void init_beep _((void));
void beep_on _((void));
void sounder _((void));
void beep_set _((int f, int p));
void clear_beep _((void));

#ifdef MEM_SCR
void putansi _((int c));
void litput _((int c));
void rawput _((int c));
void rawpage0 _((int c));
void set_pos _((int line, int col));
void update_page _((void));
void updateline _((int to));
void fetch_page _((void));
void fetch_line _((int from));
void do_ansi _((int cmd, int subcmd, int * args, int argc));
void scroll _((int from, int to, int lines));
void clrline _((int to));
int reset_page _((void));
void clr_eol _((void));
void clr_sol _((void));
void delch _((int chars));
void inch _((int chars));
void zapch _((int chars));
void set_blink _((int flg));
void move_cur _((int row, int col));
void set_curtype _((int a, int top, int bot));
#endif
#ifdef SAVEBLOCK
void read_block _((int blk));
void save_block _((int blk));
#endif

void setup _((int port, int flags));
void clearup _((void));
void do_xmit _((void));
int get_c _((void));
void serial _((void));
void chfetch _((void));

#ifdef RS8250
void setints _((void));
void clrints _((void));
void rtsflow _((void));
#endif
void init_kbd _((void));
void clear_kbd _((void));

int get_key _((void));
void write_scan _((int scan));
void write_doscode _((int ch));
void write_dosemu _((int ch));
void write_unix _((int ch));
void write_ascii _((int ch));

void add_fnchar _((int ch));
void set_key _((int kno));
void reset_fkeys _((void));
void init_doze _((void));
void snooze _((void));

/* XXX */
void message();

#define CON_HW		0
#define CON_BIOS	1
#define CON_LINK	2

int con_type   = -1;	/* Connection type */
int fossilfunc = 0;
int mnp_fossil = 0;
int quiet = 0;
int use_linux_defaults = 1;

char * terminal_type = "ansi";	/* Assume default 'dos' ansi */
int terminal_lines = 25;
int terminal_cols  = 80;

int mask   = 0xFF;

union REGS iregs, oregs;

int nsize = 0;
char    empty[4096];
#define full (empty+sizeof(empty))
char *  putptr = empty;
char *  getptr = empty;
#define FLOW_ON	 1024	/* Choose these so that 115k2 using polling mode */
#define FLOW_OFF 512	/* will not prevent the 18.2Hz timer running. */

char xmit_buf[512];
char *xmit_put=xmit_buf, *xmit_get=xmit_buf;

/***************************************************************************/

#ifdef MEM_SCR

#define intvid(reg) int86(0x10, &reg, &reg)
#ifndef MAXPAGE
#define MAXPAGE 1
#endif

int page_no;
int dos_cur;
int dos_mode;
int dos_line;
int dos_col;
int line_len;
int scr_len;
int is_ega_plus;

struct physical_scr
{
   int far * scrptr;
   int dumb   ;
   int this_page ;
   int line;
   int col;
}
   phy_scr;

struct page_descr
{
   int ** lines;
   int col;
   int line;
   int charsave;
   int chartran;
   int attr;
   int dirtypg;
   int * dirty;

   int * page;
   int scol, sline;
   int std_col;
   int rev_col;
   int gr_col;
   int clr_col;

#ifdef AT_BIOS_KEY
   int key_mode;	/* 0 = Unix, 1 = dosemu, 2 = doscodes, 3 = scancodes */
#endif
#ifdef SCO_ANSI
   int am;		/* 1 = can't use col 80, 2 = no autowrap */
#endif
   int honour_attr;	/* Area clears honour attribute */
   int reset_done;
}
   pages[MAXPAGE];

#if MAXPAGE == 1
#define curpage pages
#else
struct page_descr * curpage = pages;
#endif

int args[10];
int argc;
int tchar;
int echar;

char dcs[256], *dcs_ptr;

int sysline[80];
int syslineno = -1;
int syslinetmp = 0;
int syslinedirty = 0;
int syslineold = -1;
int update_now = 0;

extern unsigned char iso8859_1_cp437[];
extern unsigned char iso8859_1_cp850[];

unsigned char *iso8859_1 = iso8859_1_cp437;

#ifdef BITMAP
int text_screen[2048];
unsigned char far * bm_lines[400];
int use_bitmap = 0;
#endif

#endif

/***************************************************************************/

#ifdef SAVEBLOCK

#define max_blk 100

int save_flag = 0;
int read_flag = 0;
char save_buf[SAVEBLOCK];
char * save_ptr;
char * blocks[max_blk];

#endif

/***************************************************************************/

#ifdef TSRPROG
#define TSR		0x31
#define KEYBD		0x16
#define OLDKB		0x65

void ( interrupt far *orig_key_int)();
void interrupt far key_int();
int tsrflag = 0;
char far * dos_screen;

#ifndef __BORLANDC__
extern
struct irq_stack
{
   int es;
   int ds;
   int di;
   int si;
   int bp;
   int sp;
   int bx;
   int dx;
   int cx;
   int ax;
   int pc;
   int cs;
   int flgs;
} far * sp_save;
#endif

#endif

/***************************************************************************/

long speeds[] = {  110,   150,   300,   600,
                  1200,  2400,  4800,  9600,
#ifdef RS8250
                 19200, 38400, 57600,  1800,
		 14400, 23040, 28800, 115200,
		    50,    75,   134,   200,
#endif
                 0 };

int    port_no;
long   port_speed;
int    dumb_flag = 0;

#ifdef LINK_COMM
char * port_name;
int link_open _((char * port_name, int port_no, long port_speed));
void link_close _((void));
int link_poll _((void));
int link_read _(( char * ptr, int len ));
int link_write _(( char * ptr, int len ));
#endif

/***************************************************************************
 * Main, here we go
 */
void main(argc, argv)
int argc;
char ** argv;
{
   int ar, i;
   int init_bits  = 0x1E3; /* 115200 or 9600, np, 1s, 8b */

   for(ar=1; ar<argc; ar++)
   {
      if(argv[ar][0] == '-' || argv[ar][0] == '/')
	 switch(argv[ar][1])
	 {
	 case 'q': quiet = 1; break;
	 case '8': mask = 0xFF; break;
	 case '7': mask = 0x7F; break;
	 case 's': port_speed = atol(argv[ar]+2); break;
	 case 'p': port_no = atol(argv[ar]+2); break;
#ifdef TSRPROG
	 case 't': tsrflag = 1; break;
#endif
#ifdef MEM_SCR
	 case 'd': dumb_flag = 1; break;
	 case 'c': iso8859_1 = iso8859_1_cp850; break;
	 case 'x': use_linux_defaults = 0; break;
#ifdef BITMAP
	 case 'B': use_bitmap = 1; break;
#endif
#endif
	 case 'b': con_type=CON_BIOS; fossilfunc=0; enable_snooze = 0; break;
#ifdef NS_EOI
	 case 'X': early_ack = 0; break;
#endif

	 default:  printf("Illegal argument '%s'\n", argv[ar]);

	 case 'h': Usage();
	 }
      else
      {
#ifdef LINK_COMM
	 if( port_name == 0 )
	 {
	    port_name = argv[ar];
	    con_type = CON_LINK;
	    enable_snooze = 0;
	    continue;
	 }
#endif
	 printf("Illegal argument '%s'\n", argv[ar]);
	 Usage();
      }
   }

   if( port_speed )
   { 
      for(i=0; speeds[i] && speeds[i] != port_speed ; i++);
      if( speeds[i] == 0 || (con_type == CON_BIOS && port_speed > 9600L) )
      {
         printf("Speed unsupported by BIOS\n");
         exit(1);
      }
      init_bits = (init_bits & 0x1F) | (i<<5);
   }

   if( con_type != CON_LINK && ( port_no > 3 || port_no < 0 ))
   {
      printf("Illegal Port number\n");
      exit(1);
   }
   
   init_vid();
   init_doze();

#ifdef LINK_COMM
   if( con_type == CON_LINK &&
	 link_open(port_name, port_no, port_speed) < 0 ) exit(1);
#endif

   signal(SIGINT, SIG_IGN); /* Ignore ^C */

   if( !quiet )
      printf("Terminal emulator. Version %s\n", VERSION);

   setup(port_no, init_bits);

#ifdef TSRPROG
   tsrinit();
#endif

   init_kbd();
#ifdef BEEPER
   init_beep();
#endif

#ifdef MEM_SCR
   fetch_page();
   for(ar=0; ar<80; ar++) sysline[ar] = 0x7020;
#endif

   if( !quiet )
   {
      switch(con_type)
      {
      case CON_BIOS:
	 if( fossilfunc == 0 )
	    putstr("Using BIOS communications driver\r\n");
	 else if( mnp_fossil )
	    putstr("Using Fossil communications driver with MNP support\r\n");
	 else if( fossilfunc >= 0x18 )
	    putstr("Using Fossil communications driver\r\n");
	 else
	    putstr("Using old Fossil communications driver\r\n");
	 break;
      }
      putstr("Connected\r\n");
   }

   while(keybd())
   {
#ifdef AT_BIOS_KEY
#ifdef RS8250
      /* Be nice to multi-taskers */
      if( !nsize && enable_snooze && !irq_flag && xmit_put == xmit_buf )
         snooze();
#endif
#endif

#ifdef OLDBEEPER
      sounder();
#endif
      serial();

#ifdef LINK_COMM
      if( con_type == CON_LINK && link_poll() < 0 )
	 break;
#endif
   }
#ifdef MEM_SCR
   update_page();
#endif

#ifdef OLDBEEPER
   clear_beep();
#endif
#ifdef TSRPROG
   tsrexit(0);
#endif
#ifdef BEEPER
   clear_beep();
#endif
   clear_kbd();
   clearup();
   end_vid();
   exit(0);
}

void
Usage() {
#ifdef LINK_COMM
   printf("Usage: talk [options] [hostname] [options]\n");
#else
   printf("Usage: talk [options]\n");
#endif
   printf("Options:\n");
   printf(" -h\tThis message\n");
   printf(" -q\tQuiet; supress many messages.\n");
#if 0
   printf(" -8\tEnsure connection is 8-bit\n");
#endif
   printf(" -7\tMask displayed characters to 7 bit.\n");
   printf(" -sN\tSet speed to N\n");
   printf(" -pN\tSelect port number N\n");
#ifdef TSRPROG
   printf(" -t\tGo into TSR mode\n");
#endif
#ifdef MEM_SCR
   printf(" -d\tScreen is DUMB not ANSI\n");
   printf(" -c\tAssume screen uses codepage 850\n");
   printf(" -x\tSetup the emulator with Xenix defaults\n");
#endif
   printf(" -b\tUse int14 bios\n");
#ifdef NS_EOI
   printf(" -X\tDo not ACK keyboard early. (May help with bad BIOSes)\n");
#endif
   exit(1);
}

/***************************************************************************/

#ifdef TSRPROG

/***************************************************************************
 * Check the tsr isn't already running and install our IRQ handler.
 */
tsrinit()
{
   orig_key_int = _dos_getvect(OLDKB);

   if( orig_key_int != 0 )
   {
      printf("ALREADY RUNNING USE HOTKEY\n");
      exit(0);
   }

   if( tsrflag )
   {
      save_stack(100);

      orig_key_int = _dos_getvect(KEYBD);
      _dos_setvect(OLDKB, orig_key_int);

      dos_screen = (char far *) malloc(line_len*scr_len*2);
      movedata( FP_SEG(phy_scr.scrptr), FP_OFF(phy_scr.scrptr),
                FP_SEG(dos_screen), FP_OFF(dos_screen),
                scr_len*line_len*2);
   }
}

/***************************************************************************
 * Actually go TSR.
 */
tsrexit(rtn)
int rtn;
{
   extern unsigned int _psp;
   extern unsigned int _abrktb, _asizds, _atopsp, _abrkp;
   unsigned int pgmsz;
   struct SREGS srg;

   if( tsrflag )
   {
      int i;

      movedata( FP_SEG(dos_screen), FP_OFF(dos_screen),
                FP_SEG(phy_scr.scrptr), FP_OFF(phy_scr.scrptr),
                scr_len*line_len*2);
      move_cur(dos_line, dos_col);

      _dos_setvect(KEYBD, key_int);

      /* pgmsz Should be Data seg size + DS - PSP */
      segread(&srg);
      pgmsz  = (_asizds>>4);
      pgmsz += 1;
      pgmsz += srg.ds;
      pgmsz -= _psp;

      _dos_keep(rtn, pgmsz);
   }
   /* Not tsring return */
}

/***************************************************************************
 * Check for keycodes to bring TSR in and out
 */
void interrupt far key_int()
{
static int c;
static union REGS regs;
static int flg = 0;

   set_stack();
   c = (((sp_save->ax)>>8) & 0xFF);
   if( c == 0 || c == 0x10 )
   {
      regs.h.ah = c;
      int86(OLDKB, &regs, &regs);
      c = regs.x.ax;
      sp_save->ax = c;

      if( flg == 0 && c == EXITKEY )
      {
         flg=1;
         _enable();
         do_looper();
         _disable();
         flg=0;
      }
      unset_stack();
   }
   else
   {
      unset_stack();
      _chain_intr(orig_key_int);
   }
}

/***************************************************************************
 * This is the routine to run the TSR terminal in the foreground.
 */
do_looper()
{
   int c;
   union REGS regs;

   regs.h.ah = 3; regs.h.bh = page_no; intvid(regs);
   dos_line = regs.h.dh;
   dos_col = regs.h.dl;
   movedata( FP_SEG(phy_scr.scrptr), FP_OFF(phy_scr.scrptr),
             FP_SEG(dos_screen), FP_OFF(dos_screen),
             scr_len*line_len*2);

   curpage->dirtypg = 1; /* Whole screen will be updated 'soon' */
   phy_scr.line = -1;     /* Cursor probably isn't in the right place */

   while(keybd())
   {
#ifdef OLDBEEPER
      sounder();
#endif
      serial();
   }

#ifdef BEEPER
   soundcnt = -1;   /* Turn off beep asap */
#endif

   movedata( FP_SEG(dos_screen), FP_OFF(dos_screen),
             FP_SEG(phy_scr.scrptr), FP_OFF(phy_scr.scrptr),
             scr_len*line_len*2);
   move_cur(dos_line, dos_col);
}

#endif

/***************************************************************************
 * Beeper routines, standard version
 */

#ifdef BEEPER
void
init_beep()
{
   orig_timer_int = _dos_getvect(TIMER);
   _dos_setvect(TIMER, timer_int);
}

void
beep_on()
{
   _disable();
   if(soundval == -1 )
   {
      soundval = inp(0x61);
      lastfreq = freq;
   }
   else if( lastfreq > 128 )
      lastfreq = lastfreq/2;
   else
      lastfreq = freq;
   outp(0x61, soundval|3);
   outp(0x43, 0xb6);
   outp(0x42, lastfreq&0xFF);
   outp(0x42, (lastfreq>>8)&0xFF);
   soundcnt = duration;
   _enable();
}

void interrupt far timer_int()
{
   if(soundval != -1)
   {
      if(soundcnt <= 0)
      {
         outp(0x61, soundval);
         soundval = -1;
      }
      soundcnt--;
   }
#ifdef MEM_SCR
   update_now++;
#endif
   _chain_intr(orig_timer_int);
}

void
beep_set(f,p)
int f,p;
{
   freq = f;
   duration = (p%100)*182/100+1;
}

void
clear_beep()
{
   _dos_setvect(TIMER, orig_timer_int);
   if( soundval != -1 )
      outp(0x61, soundval);
}
#endif

/***************************************************************************
 * Beeper routines, older non-interrupt version.
 */
#ifdef OLDBEEPER
void
beep_on()
{
   if(soundval == -1 )
      soundval = inp(0x61);
   outp(0x61, soundval|3);
   outp(0x43, 0xb6);
   outp(0x42, freq&0xFF);
   outp(0x42, (freq>>8)&0xFF);
   soundcnt = duration;
   soundfreq= freq;
   sounddir = -warble;

   enable_snooze=0;
}

void
sounder()
{
   if( soundcnt > 0 )
   {
      soundcnt--;
      outp(0x42, soundfreq&0xFF);
      outp(0x42, (soundfreq>>8)&0xFF);
      soundfreq += sounddir;
      if( soundfreq < freq-500 || soundfreq > freq )
         sounddir = -sounddir;
   }
   else if( soundcnt == 0 )
   {
      soundcnt--;
      outp(0x61, soundval);
      soundval = -1;
      sounddir = -warble;
   }
}

void
beep_set(f,p)
int f,p;
{
   freq = f;
   duration = (p%100+1)*700;
   if( p > 99 ) warble=1;
   else warble = 0;
}

void
clear_beep()
{
   if( soundval != -1 )
      outp(0x61, soundval);
}
#endif

/***************************************************************************
 * Fetch a key and forward it to the serial port.
 * While doing this look for the EXIT key and return FALSE if it is pressed
 */

int
keybd()
{
   int c;
   if( (c=get_key()) == -1 ) return TRUE;
#if SYSLKEY == EXITKEY
   if( syslineno >= 0 && sysline_warn && (c&0xFF) == '\033' )
#else
   if( c == EXITKEY )
#endif
#ifdef LINK_COMM
   {
#if SYSLKEY == EXITKEY
      syslineno = -1;
#endif
      if( con_type == CON_LINK )
	 link_close();
      else
	 return FALSE;
   }
#else
      return FALSE;
#endif

#ifdef FORKDOS
#ifdef TSRPROG
   else if(c == DOS_KEY && !tsrflag)
#else
   else if(c == DOS_KEY)
#endif
   {
      int err;
      char * cmd = getenv("COMSPEC");
      if( !cmd || !*cmd ) cmd = "command";
      err = spawnlp(P_WAIT, cmd, "command.com", NULL);
      fetch_page();
      if( err == -1 )
         message("Error trying to run command.com");
      curpage->dirtypg = 1;
      return TRUE;
   }
#endif
#ifdef MEM_SCR
   else if( c == SYSLKEY )
   {
#if SYSLKEY == EXITKEY
      if(syslineno < 0 || syslineno >= scr_len)
      {
	 syslineno = 0;
	 message("Press Escape to exit terminal emulator");
	 sysline_warn = 1;
      }
      else
	 syslineno = -1;
#else
      if(syslineno < 0 || syslineno >= scr_len)
	 syslineno = 0;
      else
	 syslineno = -1;
#endif
   }
#endif
#ifdef AT_BIOS_KEY
   else switch(curpage->key_mode)
   {
   default: write_unix(c); break;
   case 1:  write_dosemu(c); break;
   case 2:  write_doscode(c); break;
   }
#else
#ifdef SCO_KEYMAP
   else if( bios_keymap(c) )
      ;
#endif
   else if( c&0xFF )
      xmit(c & mask);
   else
   {
      xmit(0);
      xmit((c>>8)&mask);
   }
#endif
   return TRUE;
}

int
xmit(ch)
int ch;
{
   if( xmit_put >= xmit_buf+sizeof(xmit_buf) && xmit_get != xmit_buf )
   {
      int count = xmit_put-xmit_get;
      memcpy(xmit_buf, xmit_get, count);
      count = xmit_get - xmit_buf;
      xmit_put -= count;
      xmit_get -= count;
   }

   if( xmit_put >= xmit_buf+sizeof(xmit_buf) )
      return -1;

   *xmit_put++ = ch;

   return 0;
}

/***************************************************************************
 * Simple routine to forward output to LPT1 or the print device set as the
 * second argument of the '<ESC> [ 5 ; <dev> i'
 */
#ifdef PRINTER
putprnt(ch)
{
union REGS prt_regs;

   if( in_transprt )
   {
      switch(in_transprt)
      {
      case 2: if( ch == '[' ) { in_transprt++; return; }
	      in_transprt = 0;
              putprnt('\033'); break;
      case 3: if( ch == '4' ) { in_transprt++; return; }
	      in_transprt = 0;
              putprnt('\033'); putprnt('['); break;
      case 4: if( ch == 'i' ) { in_transprt=0; return; }
	      in_transprt = 0;
              putprnt('\033'); putprnt('['); putprnt('4'); break;
      }
      in_transprt = 1;
      if( ch == '\033' ) { in_transprt++; return; }
   }

   prt_regs.x.ax = 0x0200;
   prt_regs.x.dx = print_dev;
   int86(0x17, &prt_regs, &prt_regs);
   if( ( prt_regs.x.ax & 0x2A00 ) != 0 )
   {
      message("Printer Not Ready ... Please correct");
      return;
   }
   prt_regs.x.ax = ch;
   prt_regs.x.dx = print_dev;
   int86(0x17, &prt_regs, &prt_regs);
}
#endif

/***************************************************************************
 * 
 */
void init_doze()
{
   doze_type = 0;
   iregs.x.ax = 0x1600;
   int86(0x2F, &iregs, &oregs);
   if( oregs.h.al > 1 && oregs.h.al != 0x80 )
   {
      /* Detected windows ... */
      doze_type = 2;
      return;
   }

   iregs.x.ax = 0x1680;
   int86(0x2F, &iregs, &oregs);
   if( oregs.h.al == 0 )
      doze_type = 1;
}

void snooze()
{
   if( doze_type == 0 )
   {
#ifdef __BORLANDC__
      /* Wait for an interrupt 1/18 sec max */
      asm hlt;
#endif
      return;
   }
   /* This should do the same, Win 3.1 has the nasty habit of descheduling
      a dos program for several seconds on occasion, I _think_ this avoids
      the problem. (It definitly does on Win95)
    */
   iregs.x.ax = 0x1680;
   int86(0x2F, &iregs, &oregs);

   if( doze_type == 2 )
   {
      /* Something special for Windows ? */ ;
   }
}

/***************************************************************************
 * Quick routine to print a string to the screen.
 */
void
putstr(str)
char * str;
{
   while(*str)
      putscrn(*str++);
}

#ifndef MEM_SCR

/***************************************************************************
 * Dummy init and end for BIOS screen.
 */
void init_vid() { }
void end_vid() { }

/***************************************************************************
 * BIOS screen message line; just print the text
 */
void
message(str, val1, val2)
char * str;
int val1, val2;
{
   static char buf[128];
   char * p;
   int i=0;

   sprintf(buf, str, val1, val2);
   strcat(buf, "\r\n");

   putstr(buf);
}

/***************************************************************************
 * BIOS screen put char.
 */
void
putscrn(c)
int c;
{
#ifdef ZMODEM
static lastchar = ' ';
#endif
#ifdef AVATAR
   extern int avcnt;
   if( avcnt > 0 || ( avcnt == 0 && ( c == '\026' || c == '\031')))
   {
      do_avatar(c);
      return;
   }
   if( c == '\f' )
   {
      putstr("\033[2J");
      return;
   }
#endif
#ifdef OLDBEEPER
   if( c == '\007' )
   {
      beep_on();
      return;
   }
#endif /* OLDBEEPER */
#ifdef BEEPER
   if( c == '\007' )
   {
      beep_on();
      return;
   }
#endif /* BEEPER */
#ifdef ZMODEM
   else if( c == 24 && lastchar == '*' ) /* CTRL-X */
   {
#ifdef TSRPROG
       if( !tsrflag )
#endif
         system("dsz d handshake slow rz -rr");
   }

   lastchar = c;
#endif

   if( (c&-32)==0
     && c != '\r'
     && c != '\n'
     && c != '\b'
     && c != '\007'
		  ) return;

   iregs.h.ah = CHAROUT;
   iregs.h.dl = c;
   intdos(&iregs, &oregs);
}

#else

/***************************************************************************
 * Hardware screen, message line is mobile between TOS and BOS.
 */
void
message(str, val1, val2)
char * str;
int val1, val2;
{
   static char buf[128];
   int i;
   int flg=0;

   memset(buf, '\0', sizeof(buf));
   sprintf(buf, str, val1, val2);

   for(i=0; i<80; i++)
   {
      if( buf[i] == '\0' )
      {
         if( sysline[i] == 0x7000 )
            break;
         else
            sysline[i] = 0x7000;
      }
      else
      {
         if( flg == 1 || buf[i] != ' ' )
            sysline[i] = buf[i]|(0x7000);
         else
            sysline[i] = 0x7000;
         if( buf[i] != ' ' ) flg = 1;
      }
   }
   syslinedirty = 1;
   if( syslineno == -1 ) syslinetmp = 1;
#if SYSLKEY == EXITKEY
   sysline_warn = 0;
#endif
}

/***************************************************************************
 * Hardware screen, print character.
 */
void
putscrn(c)
int c;
{ 
static int ansi_state=0;
   int i;

#ifdef AVATAR
   extern int avcnt;
#endif
#ifdef ZMODEM
static lastchar = ' ';
   if( c != 24 ) lastchar = c;
#endif

   c &= 0xFF;

   if( update_now>2 )	/* Make sure it's updated every 1/10 second */
   {
#ifdef SAVEBLOCK
      if( read_flag == 0 )
#endif
         update_page();
   }

#ifdef SAVEBLOCK
   if( save_flag && c != '\0' )
   {
      *save_ptr++ = c;
      if( save_ptr >= save_buf+sizeof(save_buf) ) save_ptr = save_buf;
   }
#endif

#ifdef AVATAR
   if( avcnt > 0 || ( avcnt == 0 && ( c == '\026' || c == '\031')))
   {
      do_avatar(c);
      return;
   }
#endif
#ifdef ZMODEM
   if( c == 24 && lastchar == '*' ) /* CTRL-X */
   {
#ifdef TSRPROG
      if( !tsrflag )
#endif
      {
         system("dsz d handshake slow rz -rr");
         fetch_page();
         curpage->dirtypg = 1;
      }
      return;
   }
#endif

   if( ansi_state == 0 && c >= ' ' )	/* Fast shortcut */
   {
      litput(c);
      return;
   }

   if( ansi_state <= 3 && ansi_state != 1
       && ( curpage->chartran < 10 || c == '\033' || ansi_state > 1 ))
          switch(c)
   {
   case '\n': curpage->line++;
	      if( curpage->line == scr_len ) scroll(0, scr_len-1, 1);
	      return;

   case '\r': curpage->col = 0;
	      return;

   case '\b': if( curpage->col )
		 curpage->col--;
	      return;

   case '\t': i = (8 - (curpage->col&7) );
	      curpage->col += i;
	      if( curpage->col > line_len )
		 curpage->col     = line_len;
	      return;

#if defined(SCO_ANSI) || defined(AVATAR)
   case '\f': scroll( scr_len-1, 0, scr_len);
	      curpage->line=0;
	      curpage->col=0;
	      return;
#endif

#ifdef OLDBEEPER
   case '\007':beep_on();
	       return;
#endif /* OLDBEEPER */
#ifdef BEEPER
   case '\007':beep_on();
	       return;
#endif /* BEEPER */

   case '\030':ansi_state = 0; /* Ctrl-X */
               return;

   case '\032':ansi_state = 0; /* Ctrl-Z */
               rawput(0xA8);
               return;

   case '\033':
              if( phy_scr.dumb == 0 )
	      {
		 ansi_state = 1;

	         for(argc=0; argc<10; argc++) args[argc] = 0;
	         argc    = 0;
	         tchar   = 0;
	         echar   = 0;

		 return;
	      }
	      /*FALLTHROUGH*/
   }

   switch(ansi_state)
   {
   default:ansi_state =0;

   case 0: if( c < ' ' && phy_scr.dumb == 0 && curpage->chartran < 10 )
	      break;
	   litput(c);
	   break;

   case 1: if( curpage->chartran >= 10 && c != '[' )
	   {
	      litput('\033');
              if( c != '\033' )
	      {
	         litput(c);
                 ansi_state = 0;
	      }
	      break;
	   }
	   switch(c)
           {
	   case '\\': /* NO-OP if not in DCS string */
              ansi_state = 0;
              break;
	   case 'P':
	      dcs_ptr = dcs;
	      ansi_state = 2;
	      break;
           case '[':
              dcs_ptr = 0;
	      ansi_state = 2;
	      break;
           case '(':
	      ansi_state = 8;
              break;
	   case '7':
              curpage->sline = curpage->line;
              curpage->scol  = curpage->col;
              ansi_state = 0;
              break;
	   case '8':
              set_pos(curpage->sline, curpage->scol);
              ansi_state = 0;
              break;
#ifdef SCO_ANSI
	  case 'c':
	      curpage->reset_done = 0;
	      reset_page();
#ifdef AT_BIOS_KEY
#ifdef SCO_REMAP
	      reset_fkeys();
#endif
#endif
	      ansi_state = 0;
	      break;
#endif 
#ifdef AT_BIOS_KEY
	   case '>':
              curpage->key_mode = 0;
              ansi_state = 0;
              break;
	   case '=':
              curpage->key_mode = 1;
              ansi_state = 0;
              break;
	   case '<':
              curpage->key_mode = 2;
              ansi_state = 0;
              break;
#endif
#ifdef SCO_REMAP
	   case 'Q':
	      ansi_state = 10;
              break;
#endif
           default:
	      ansi_state = 0;
              if( c < ' ' || c > '~' )
                 rawput(c);	/* ESC prefix -> Font raw */
              break;
           }
	   break;

   case 2: if(( c >= ' ' && c < '0' ) || c == ':' || ( c > ';' && c <= '?' ))
	   {
	      tchar = c;
	      ansi_state = 3;
	      break;
	   }
   case 3: if( c >= '0' && c <= '9' )
	   {
	      args[argc] = args[argc]*10 + c - '0';
	      break;
	   }
	   else if(c == ';' )
	   {
	      if( ++argc >= 10 )
	      {
		 ansi_state = 0;
		 break;
	      }
	      args[argc] = 0;
	      break;
	   }
           else if( c >= '@' && c <= '~' )
	   {
	      echar = c;
	      if( dcs_ptr == 0 )
	      {
	         ansi_state = 0;
	         do_ansi( echar, tchar, args, argc+1 );
	      }
	      else
	      {
	         ansi_state = 4;
		 break;
	      }
	   }
	   ansi_state = 0;
	   break;

   /* DCS ... ST processing */
   case 4: if( c == '\030' || dcs_ptr >= dcs+sizeof(dcs)-1 )
              ansi_state = 0;
           else if( c == '\033' )
              ansi_state = 5;
	   else
	      *dcs_ptr++ = c;
	   break;

   case 5: if( c != '\\' )
           {
              if( dcs_ptr >= dcs+sizeof(dcs)-2 || c == '\030' )
	         ansi_state = 0;
              else
	      {
	         *dcs_ptr++ = '\033';
                 if( c != '\033' ) { *dcs_ptr++ = c; ansi_state = 4; }
	      }
	      break;
	   }
	   *dcs_ptr = '\0';
	   ansi_state = 0;

	   if( tchar == '$' && echar == '~' )
	   {
              dcs[80] = 0;
              if( *dcs ) message("%s", dcs);
              else       syslineno = -1;
	   }
	   break;

   /* ESC ( <n>  Screen language processing */
   case 8: ansi_state =0;
           switch(c)
	   {
	   case 'B': curpage->chartran = 1; break;
	   case '0': curpage->chartran = 2; break;
	   case 'A': curpage->chartran = 3; break;

	   case 'U': curpage->chartran = 0; break;
	   case 'u': curpage->chartran = 4; break;

	   default:  curpage->chartran = -1; break;
	   }
	   curpage->charsave = curpage->chartran;
	   break;

   /* SCO Function key remapping */
#ifdef SCO_REMAP
   case 10: echar = c-'0'; /* FUNCTION KEY NUMBER 0=F1 .. 9=F10 */
#ifdef DEBUG
	    message("Define function key %d", echar+1);
#endif
	    ansi_state = 11;
	    break;

   case 11: tchar = c;
	    ansi_state = 12;
	    break;

   case 12: if( c == tchar )
	    {
	       ansi_state = 0;
	       set_key(echar);
	    }
	    else if( c != '^' )
	       add_fnchar(c);
	    else
	       ansi_state = 13;
	    break;
   case 13: if( c == tchar ) ansi_state = 0; else ansi_state = 12;

	    if( c == tchar )
	       set_key(echar);
	    else if( c != '^' )
	       add_fnchar(c& 0x1F);
	    else
	       add_fnchar(c);
	    break;
#endif

   }
}

/***************************************************************************
 * Hardware screen, Write any byte to screen through the translation table.
 */

/* XXX, Humm should the -1's be zeros ? */
unsigned char iso8859_1_cp437[] = {
  4, 177,  -1,  -1,  -1,  -1, 248, 241, 176,  -1, 217, 191, 218, 192, 197,  -1,
 -1, 196,  -1,  95, 195, 180, 193, 194, 179, 243, 242, 227,  -1, 156, 250,  -1,

255, 173, 155, 156,   9, 157, 124,  21,  34,  67, 166, 174, 170,  45,  82, 196,
248, 241, 253,  51,  39, 230,  20, 250,  44,  49, 167, 175, 172, 171,  51, 168,
 65,  65,  65,  65, 142, 143, 146, 128,  69, 144,  69,  69,  73,  73,  73,  73,
 68, 165,  79,  79,  79,  79, 153, 120, 237,  85,  85,  85, 154,  89,  80, 225,
133, 160, 131,  97, 132, 134, 145, 135, 138, 130, 136, 137, 141, 161, 140, 139,
 11, 164, 149, 162, 147, 111, 148, 246, 237, 151, 163, 150, 129, 121, 112, 152
};

unsigned char iso8859_1_cp850[] = {
  4, 177,  -1,  -1,  -1,  -1, 248, 241, 176,  -1, 217, 191, 218, 192, 197,  -1,
 -1, 196,  -1,  95, 195, 180, 193, 194, 179, 243, 242, 227,  -1, 156, 250,  -1,

255, 173, 189, 156, 207, 190, 221, 245, 249, 184, 166, 174, 170, 240, 169, 238,
248, 241, 253, 252, 239, 230, 244, 250, 247, 251, 167, 175, 172, 171, 243, 168,
183, 181, 182, 199, 142, 143, 146, 128, 212, 144, 210, 211, 222, 214, 215, 216,
209, 165, 227, 224, 226, 229, 153, 158, 157, 235, 233, 234, 154, 237, 231, 225,
133, 160, 131, 198, 132, 134, 145, 135, 138, 130, 136, 137, 141, 161, 140, 139,
208, 164, 149, 162, 147, 228, 148, 246, 155, 151, 163, 150, 129, 236, 232, 152
};

void
litput(c)
int c;
{
   c &= 0xFF;
   switch( curpage->chartran )
   {
   case 1:
      if( (c&0x80) )
      {
         if( c&0x60 ) c  = iso8859_1[c&0x7F];
	 else         c &= 0x1F;
      }
      break;

   case 2:
      if( c >= 0x60 && c < 0x80 )
	 c = iso8859_1[c&0x1F];
      break;

   case 3:
      if( c == '#' ) { c = 156; break; }
      /* FALLTHROUGH */

   default:
      if( c < ' ' || c > '~' ) return;
      break;

   case 4:
      c &= 0x7F;
      break;

   case 12:
      c ^= 0x80;
   case 11:
   case 0:
      break;
   }
#if MAXPAGE != 1
   if( pages == curpage )
      rawpage0(c);
   else
#endif
      rawput(c);
}

void
rawput(c)
int c;
{
   if( curpage->col >= line_len )
   {
      curpage->line++;
      curpage->col=0;
      if( curpage->line == scr_len ) scroll(0, scr_len-1, 1);
   }
   curpage->lines[curpage->line][curpage->col] = c + (curpage->attr<<8);
   curpage->dirty[curpage->line] = 1;
   curpage->col++;
#ifdef SCO_ANSI
   if( curpage->col == line_len && curpage->am )
   {
      if( curpage->am & 2 )
         curpage->col--;
      else
      {
         curpage->line++; curpage->col=0;
      }
      if( ( curpage->am & 1 ) && curpage->line == scr_len )
         scroll(0, scr_len-1, 1);
   }
#endif
}

#if MAXPAGE != 1
void
rawpage0(c)
int c;
{
   if( pages->col >= line_len )
   {
      pages->line++;
      pages->col=0;
      if( pages->line == scr_len ) scroll(0, scr_len-1, 1);
   }
   pages->lines[pages->line][pages->col] = c + (pages->attr<<8);
   pages->dirty[pages->line] = 1;
   pages->col++;
#ifdef SCO_ANSI
   if( pages->col == line_len && pages->am )
   {
      if( pages->am & 2 )
         pages->col--;
      else
      {
         pages->line++; pages->col=0;
      }
      if( ( pages->am & 1 ) && pages->line == scr_len )
         scroll(0, scr_len-1, 1);
   }
#endif
}
#endif

/***************************************************************************
 * Hardware screen, Set the virtual cursor position.
 */
void
set_pos(line, col)
int line;
int col;
{
   curpage->line = line;
   curpage->col = col;
   if( curpage->line < 0 ) curpage->line = 0;
   if( curpage->line >= scr_len ) curpage->line = scr_len-1;
   if( curpage->col  < 0 ) curpage->col = 0;
   if( curpage->col >=line_len ) curpage->col = line_len-1;
}

/***************************************************************************
 * Hardware screen, Write screen image to physical screen.
 */
void
update_page()
{
   int i;
   update_now=0;

   if( curpage->col != phy_scr.col || curpage->line != phy_scr.line )
   {
      int c;
      phy_scr.col = curpage->col;
      phy_scr.line = curpage->line;

      if( curpage->col == line_len )
	 c = line_len-1;
      else
	 c = curpage->col;
      move_cur(curpage->line, c);
   }

   if( syslineno == curpage->line )
      syslineno = scr_len -1 -syslineno;

   if( curpage->dirtypg )
   {
      syslineold = syslineno;
      syslinedirty = 0;
   }

   if( syslinetmp && syslineold == -1 )
   {
      if( curpage->line == 0 )
         syslineno = scr_len-1;
      else
         syslineno = 0;
      syslineold = syslineno;
   }

   if( syslineold != syslineno )
   {
      if( syslinetmp )
      {
         syslinetmp = 0;
	 syslineno = -1;
      }
      if( syslineold != -1 )
         curpage->dirty[syslineold] = 1;
      if( syslineno != -1 )
         syslinedirty = 1;
      syslineold = syslineno;
   }

   for(i=0; i<scr_len; i++)
      if( curpage->dirtypg || curpage->dirty[i] )
      {
#ifdef FLDATTR
         copyattr(i);
#endif
         updateline(i);
      }

   if( syslineno != -1 && syslinedirty )
      updateline(syslineno);
   curpage->dirtypg = 0;
}

#ifdef FLDATTR
copyattr(lno)
int lno;
{
int i;
int lastattr = -1;

   for(i=0; i<line_len; i++)
   {
      if((curpage->lines[lno][i]&0xFF) == 0xFF)
         lastattr = (curpage->lines[lno][i]&0xFF00);
      if( lastattr != -1 )
         curpage->lines[lno][i] = ((curpage->lines[lno][i]&0xFF)|lastattr);
   }
}
#endif

void
updateline(to)
int to;
{
   int ll = line_len*2;
   char far * ptr;

   curpage->dirty[to] = 0;
   if( to == syslineno )
   {
      ptr = (char far *) sysline;
      syslinedirty = 0;
   }
   else
      ptr = (char far *)(curpage->lines[to]);
   movedata(FP_SEG(ptr), FP_OFF(ptr),
            FP_SEG(phy_scr.scrptr), ll*to,
             ll);
}

/***************************************************************************
 * Hardware screen, Fetch physical screen into image memory.
 */
void
fetch_page()
{
   int i;

   iregs.h.ah = 3;
   iregs.h.bh = page_no;
   intvid(iregs);
   curpage->line = iregs.h.dh;
   curpage->col  = iregs.h.dl;

   for(i=0; i<scr_len; i++)
      fetch_line(i);
}

void
fetch_line(from)
int from;
{
   int ll = line_len*2;
   char far * ptr;
   if( from == syslineno ) return;
   ptr = (char far *)(curpage->lines[from]);
   movedata(FP_SEG(phy_scr.scrptr), ll*from,
            FP_SEG(ptr), FP_OFF(ptr),
             ll);
}

/***************************************************************************
 * Hardware screen, apply an ansi sequence to the current screen image.
 */
void
do_ansi( cmd, subcmd, args, argc )
int cmd;
int subcmd;
int * args;
int argc;
{
   int ar;
static int colconv[] = { 000, 004, 002, 006, 001, 005, 003, 007,
                         010, 014, 012, 016, 011, 015, 013, 017 };
   switch( subcmd )
   {
   case 0:   switch( cmd )
             {
#ifdef SCO_ANSI
	     case '@': inch(args[0]);
		       break;
#endif
	     case 'A': if( args[0] < 1 ) args[0] = 1;
                       set_pos(curpage->line-args[0], curpage->col);
		       break;
#ifdef SCO_ANSI
             case 'E': curpage->col = 0;
                       /* FALLTHROUGH */
             case 'e':
#endif
	     case 'B': if( args[0] < 1 ) args[0] = 1;
		       set_pos(curpage->line+args[0], curpage->col);
		       break;
#ifdef SCO_ANSI
             case 'a':
#endif
	     case 'C': if( args[0] < 1 ) args[0] = 1;
		       curpage->col    += args[0];
		       if( curpage->col >= line_len )
			  curpage->col     = line_len -1;
		       break;
	     case 'D': if( args[0] < 1) args[0] = 1;
		       curpage->col    -= args[0];
		       if( curpage->col < 0 )
			  curpage->col     = 0;
		       break;
#ifdef SCO_ANSI
	     case 'F': if( args[0] < 1 ) args[0] = 1;
                       set_pos(curpage->line-args[0], 0);
		       break;
#endif
             case 'f':
             case 'H': set_pos(args[0]-1, args[1]-1);
		       break;
	     case 'J': /* cls */
		       if( args[0] == 2)
		       {
		          scroll( scr_len-1, 0, scr_len);
		          curpage->line=0;
		          curpage->col=0;
		       }
		       else if( args[0] == 0 )
                       {
                          clr_eol();
			  if( curpage->line != scr_len-1 )
                             scroll( scr_len-1, curpage->line+1, scr_len);
                       }
		       else if( args[0] == 1 )
                       {
                          clr_sol();
			  if( curpage->line != 0 )
			  scroll( curpage->line-1, 0, scr_len);
                       }
		       break;
	     case 'K': /* Clear eol */
		       if(args[0] == 0 )
                          clr_eol();
		       else if(args[0] == 1 )
                          clr_sol();
		       else if(args[0] == 2 )
                          clrline(curpage->line);
		       break;

#ifdef SCO_ANSI
             case 'L': scroll(scr_len-1, curpage->line, args[0]);
		       break;

             case 'M': scroll(curpage->line, scr_len-1, args[0]);
		       break;

             case 'P': delch(args[0]);
		       break;

             case 'S': scroll(0, scr_len-1, args[0]);
		       break;

             case 'T': scroll(scr_len-1, 0, args[0]);
		       break;

             case 'X': zapch(args[0]);
                       break;

             case 'Z': if( args[0] == 0 ) args[0] = 1;
                       set_pos(curpage->line,((curpage->col+7-8*(args[0]))&-8));
                       break;
#endif
#ifdef PRINTER
	     case 'i': if( args[0] == 5 )
                       {
		          if( args[1] > 0 && args[1] < 3 ) print_dev = args[1];
			  in_transprt = 1;
		       }
		       break;
#endif

             case 'm': /* Attributes */
		       for(ar=0; ar<argc; ar++)
		       switch(args[ar])
		       {
		       case 0: curpage->attr  = curpage->std_col;
			       break;
		       case 1: curpage->attr |= 0x08;
			       break;
#ifdef SCO_ANSI
		       case 2: if( dos_mode != 2 && dos_mode != 7 && ar+2<argc )
                               {
                                  curpage->std_col = colconv[args[ar+1]&0xF]
                                               + (colconv[args[ar+2]&0xF] << 4);
			          curpage->attr  = curpage->std_col;
                                  if( args[ar+2]&0x8 )
                                     set_blink(0);
                                  ar+=2;
                               }
			       break;
		       case 3: if( dos_mode != 2 && dos_mode != 7 && ar+1<argc )
                               {
                                  set_blink(args[++ar]);
                               }
                               break;
#endif
		       case 4: if( dos_mode == 7 )
                                  curpage->attr = ((curpage->attr & 0xF0)|0x01);
			       break;
		       case 24:if( dos_mode == 7 )
                                  curpage->attr = ((curpage->attr & 0xF0)|0x07);
			       break;
		       case 5: curpage->attr |= 0x80;
                               set_blink(1);
		               break;
		       case 7:
#ifdef SCO_ANSI
		               if( dos_mode != 2 && dos_mode != 7 && ar+2<argc )
                               {
                                  curpage->rev_col = colconv[args[ar+1]&0xF]
                                               + (colconv[args[ar+2]&0xF] << 4);
                                  if( args[ar+2]&0x8 )
                                     set_blink(0);
                                  ar+=2;
                               }
#endif
			       curpage->attr  = curpage->rev_col;
			       break;
		       case 27: if( curpage->attr == curpage->rev_col )
			          curpage->attr  = curpage->std_col;
                               break;
		       case 8: curpage->attr  = 0;
			       break;
#ifdef SCO_ANSI
		       case 10:curpage->chartran = curpage->charsave;
                               curpage->attr = curpage->std_col;
			       break;
		       case 11:
		       case 12:curpage->chartran = args[ar];
                               curpage->attr = curpage->gr_col;
			       break;
#endif
		       case 30:case 31:case 32:case 33:
                       case 34:case 35:case 36:case 37:
                               if( dos_mode != 2 && dos_mode != 7 )
			          curpage->attr = ((curpage->attr & 0xF8)
                                                    |(colconv[args[ar]-30]));
			       break;
		       case 40:case 41:case 42:case 43:
                       case 44:case 45:case 46:case 47:
                               if( dos_mode != 2 && dos_mode != 7 )
			          curpage->attr
                                          = ((curpage->attr & 0x8F)
                                              |((colconv[args[ar]-40]&0x7)<<4));
			       break;
		       }
		       if( curpage->honour_attr )
                          curpage->clr_col = curpage->attr;
		       break;
#ifdef SCO_ANSI
             case 'g': if( curpage->col == line_len )
	               {
		          curpage->line++;
		          curpage->col=0;
		          if( curpage->line == scr_len )
                             scroll(0, scr_len-1, 1);
	               }
                       curpage->lines[curpage->line][curpage->col] =
		                          args[0] + (curpage->gr_col<<8);
                       curpage->dirty[curpage->line] = 1;
	               curpage->col++;
                       break;
#endif

	       case 's':
                 curpage->sline = curpage->line;
                 curpage->scol  = curpage->col;
                 break;
	       case 'u':
                  set_pos(curpage->sline, curpage->scol);
                  break;

#ifdef LINK_COMM
	       case 'h':
		  switch(args[0])
		  {
		  case 12: link_echo(0); break;
		  }
		  break;
	       case 'l':
		  switch(args[0])
		  {
		  case 12: link_echo(1); break;
		  }
		  break;
#endif
             }
             break;

#ifdef SCO_ANSI
   case '=': switch( cmd )
	     {
#ifdef OLDBEEPER
             case 'B': beep_set(args[0], args[1]);
                       break;
#endif
#ifdef BEEPER
             case 'B': beep_set(args[0], args[1]);
                       break;
#endif
	     case 'C': /* set cursor (0=>norm, 1=>off, 2=>big, x;y=>setit */
		       if( argc <= 1 ) set_curtype(args[0]-1,0,15);
		       if( argc == 2 ) set_curtype(2,args[0],args[1]);
		       break;
	     case 'E': /* set cursor */
		       set_blink(args[0]);
		       break;
             case 'F': if( dos_mode != 2 && dos_mode != 7 )
			  curpage->std_col = ((curpage->std_col & 0xF0)
                                              |(args[0]&0xF));
		       if( !curpage->honour_attr )
                          curpage->clr_col = curpage->std_col;
                       break;
             case 'G': if( dos_mode != 2 && dos_mode != 7 )
			  curpage->std_col = ((curpage->std_col & 0x0F)
                                              |((args[0]&0xF)<<4));
		       if( !curpage->honour_attr )
                          curpage->clr_col = curpage->std_col;
                       break;
             case 'H': if( dos_mode != 2 && dos_mode != 7 )
			  curpage->rev_col = ((curpage->rev_col & 0xF0)
                                              |(args[0]&0xF));
                       break;
             case 'I': if( dos_mode != 2 && dos_mode != 7 )
			  curpage->rev_col = ((curpage->rev_col & 0x0F)
                                              |((args[0]&0xF)<<4));
                       break;
             case 'J': if( dos_mode != 2 && dos_mode != 7 )
			  curpage->gr_col = ((curpage->gr_col & 0xF0)
                                              |(args[0]&0xF));
                       break;
             case 'K': if( dos_mode != 2 && dos_mode != 7 )
			  curpage->gr_col = ((curpage->gr_col & 0x0F)
                                              |((args[0]&0xF)<<4));
                       break;
             case 'L': curpage->honour_attr = !args[0];
		       if( curpage->honour_attr )
                          curpage->clr_col = curpage->attr;
                       else
                          curpage->clr_col = curpage->std_col;
                       break;
             case 'g': if( curpage->col == line_len )
	               {
		          curpage->line++;
		          curpage->col=0;
		          if( curpage->line == scr_len )
                             scroll(0, scr_len-1, 1);
	               }
                       curpage->lines[curpage->line][curpage->col] =
		                          args[0] + (curpage->attr<<8);
                       curpage->dirty[curpage->line] = 1;
	               curpage->col++;
                       break;
	     }
	     break;

   case '?': if( cmd == 'l' || cmd == 'h' )
	     {
                int flg = (cmd == 'h');
		switch(args[0])
		{
	        case 7: curpage->am = flg; break;
		}
	     }
	     break;
#endif

   case '$': switch(cmd)
             {
#if MAXPAGE != 1
	     case 'P': args[0] %= MAXPAGE;
		       if( args[0] == phy_scr.this_page ) break;
		       phy_scr.this_page = args[0];
		       curpage= pages+phy_scr.this_page;

		       if( pages[args[0]].page == 0 )
		       {
			  if( reset_page() < 0 )
			     phy_scr.this_page = 0;
		       }

		       curpage= pages+phy_scr.this_page;
		       curpage->dirtypg = 1;
		       break;
#endif

#ifdef SAVEBLOCK
	     case 'S': if(args[0] == 1)
		       {
                          if( read_flag ) break;
		          read_flag = 1; save_flag = 0;
			  read_block(args[1]);
			  read_flag = 0;
		       }
		       else if( args[0] == 2 && argc == 1 )
		       {
                          if( read_flag ) break;
			  save_flag = 1;
			  save_ptr = save_buf;
		       }
		       else if( args[0] == 2)
		       {
                          if( read_flag ) break;
			  save_block(args[1]);
		       }
		       break;
#endif
	     }
	     break;
   }
}

/***************************************************************************
 * Hardware screen, scroll a set of lines on the cur screen.
 */
void
scroll(from, to, lines)
int from, to, lines;
{
   int win, tomove, toclr, dir, line, c;
   int * tmp;

   if( curpage->line == scr_len) curpage->line--;
   if( lines <= 0 ) lines = 1;

   dir    = 1;
   if( from > to ) { dir = from ; from = to ; to = dir ; dir = -1 ;}
   win    = to-from+1;
   if( lines > win ) lines = win;
   tomove = win - lines;
   toclr  = lines;

   if( dir == 1 )
   {
      for(line=from; tomove>0; tomove--, line++)
      {
	 tmp = curpage->lines[line];
	 curpage->lines[line] = curpage->lines[line+lines];
	 curpage->lines[line+lines] = tmp;
	 curpage->dirty[line] = 1;
	 curpage->dirty[line+lines] = 1;
      }
      for(line=to; toclr>0; toclr--, line--)
      {
	 clrline(line);
      }
   }
   else
   {
      for(line=to; tomove>0; tomove--, line--)
      {
	 tmp = curpage->lines[line];
	 curpage->lines[line] = curpage->lines[line-lines];
	 curpage->lines[line-lines] = tmp;
	 curpage->dirty[line] = 1;
	 curpage->dirty[line+lines] = 1;
      }
      for(line=from; toclr>0; toclr--, line++)
      {
	 clrline(line);
      }
   }
}

/***************************************************************************
 * Hardware screen, clear one line.
 */
void
clrline(to)
int to;
{
   int * toptr = curpage->lines[to];
   int chars   = line_len;
   int pattern = ' ' + (curpage->clr_col << 8 );

   curpage->dirty[to] = 1;

   do
   {
      *toptr++ = pattern;
      chars--;
   }
   while( chars );
}

/***************************************************************************
 * Hardware screen, clear one page, reset dynamic values.
 */
int
reset_page()
{
static int *sys_page = 0, **sys_lines, *sys_dirty;
   int i;

   if( sys_page == 0 )
   {
      sys_page = (int*) malloc(scr_len*line_len*2);
      sys_lines = (int**) malloc(scr_len*sizeof(int*));
      sys_dirty = (int*) malloc(scr_len*sizeof(int));
      if( sys_page == 0 || sys_lines == 0 || sys_dirty == 0 )
         return -1;
   }

   if( !curpage->reset_done )
   {
      curpage->charsave = 0;
      curpage->chartran = 0;
      curpage->attr     = 0x07;
      curpage->std_col  = 0x07;
      curpage->rev_col  = 0x70;
      curpage->gr_col   = 0x07;
      curpage->clr_col  = 0x07;
      curpage->line     = 0;
      curpage->col      = 0;
      curpage->dirtypg  = 1;

#ifdef AT_BIOS_KEY
      curpage->key_mode = 0;
#endif
      curpage->am       = 1;
      curpage->honour_attr = 1;

      if( use_linux_defaults )
      {
         curpage->honour_attr = 0;
         curpage->charsave = 1;
         curpage->chartran = 1;
      }
      curpage->reset_done = 1;
   }

#if MAXPAGE != 1
   if( pages[phy_scr.this_page].page == 0
   || pages[phy_scr.this_page].lines == 0
   || pages[phy_scr.this_page].dirty == 0 )
   {
      pages[phy_scr.this_page].page = (int*) malloc(scr_len*line_len*2);
      pages[phy_scr.this_page].lines = (int**) malloc(scr_len*sizeof(int*));
      pages[phy_scr.this_page].dirty = (int*) malloc(scr_len*sizeof(int));
   }
#endif

   /* Out of memory, use the default page */
   if( pages[phy_scr.this_page].page == 0
   || pages[phy_scr.this_page].lines == 0
   || pages[phy_scr.this_page].dirty == 0 )
   {
      if(pages[phy_scr.this_page].page ) free(pages[phy_scr.this_page].page);
      if(pages[phy_scr.this_page].lines) free(pages[phy_scr.this_page].lines);
      if(pages[phy_scr.this_page].dirty) free(pages[phy_scr.this_page].dirty);
      
      for(i=0; i<MAXPAGE; i++) if( pages[phy_scr.this_page].page == sys_page )
      {
         pages[i].page  = 0;
         pages[i].lines = 0;
         pages[i].dirty = 0;
      }

      pages[phy_scr.this_page].page  = sys_page;
      pages[phy_scr.this_page].lines = sys_lines;
      pages[phy_scr.this_page].dirty = sys_dirty;
   }

   for(i=0; i<scr_len; i++)
      pages[phy_scr.this_page].lines[i]
          = pages[phy_scr.this_page].page+line_len*i;

   scroll( scr_len-1, 0, scr_len);

   return 0;
}

/***************************************************************************
 * Hardware screen, clear to end of line
 */
void
clr_eol()
{
   int pattern = ' ' +(curpage->clr_col << 8 );
   int * toptr = curpage->lines[curpage->line]+curpage->col;
   int x = curpage->col;

   curpage->dirty[curpage->line] = 1;
   while( x < line_len )
   {
      *toptr++ = pattern;
      x++;
   }
}

/***************************************************************************
 * Hardware screen, clear to start of line
 */
void
clr_sol()
{
   int pattern = ' ' +(curpage->clr_col << 8 );
   int * toptr = curpage->lines[curpage->line]+curpage->col;
   int x = curpage->col;

   curpage->dirty[curpage->line] = 1;
   while( x >= 0 )
   {
      *toptr-- = pattern;
      x--;
   }
}

/***************************************************************************
 * Hardware screen, delete some characters.
 */
void
delch(chars)
int chars;
{
   int pattern = ' ' +(curpage->clr_col << 8 );
   int * toptr = curpage->lines[curpage->line]+curpage->col;
   int x = curpage->col;
   int last;

   curpage->dirty[curpage->line] = 1;
   if( chars <=0 ) chars = 1;
   last = line_len-chars;

   while( x < last )
   {
      *toptr = toptr[chars];
      toptr++; x++;
   }

   while( x < line_len )
   {
      *toptr++ = pattern;
      x++;
   }
}

#ifdef SCO_ANSI
/***************************************************************************
 * Hardware screen, insert some characters.
 */
void
inch(chars)
int chars;
{
   int pattern = ' ' +(curpage->attr << 8 );
   int * toptr = curpage->lines[curpage->line]+line_len-1;
   int x = line_len-1;
   int last;

   curpage->dirty[curpage->line] = 1;
   if( chars <= 0 ) chars = 1;

   last = curpage->col+chars;
   chars = -chars;

   while( x >= last )
   {
      *toptr = toptr[chars];
      toptr--; x--;
   }

   while( x >= curpage->col )
   {
      *toptr-- = pattern;
      x--;
   }
}

/***************************************************************************
 * Hardware screen, clear some characters.
 */
void
zapch(chars)
int chars;
{
   int pattern = ' ' +(curpage->clr_col << 8 );
   int * toptr = curpage->lines[curpage->line]+curpage->col;
   int x = curpage->col;
   int last;

   curpage->dirty[curpage->line] = 1;
   if( chars <= 0 ) chars = 1;

   last = curpage->col+chars;
   if( last > line_len ) last = line_len;

   while( x < last )
   {
      *toptr++ = pattern;
      x++;
   }
}
#endif

/***************************************************************************
 * Hardware screen, init video, detect physical screen size and location
 * if it's in a graphic mode complain.
 */
void
init_vid()
{
   union REGS ioregs;
   int phy_mode=0;
   char *p;

   phy_scr.scrptr = (int far *) 0xB0000000;
   phy_scr.dumb   = dumb_flag;
   phy_scr.line   = -1;
   phy_scr.col    = -1;

   ioregs.x.ax = 0x0500;
   intvid(ioregs);

   ioregs.h.ah = 15;
   intvid(ioregs);
   dos_mode = ioregs.h.al;
   line_len = ioregs.h.ah;
   page_no = ioregs.h.bh;

   ioregs.h.ah = 3;
   ioregs.h.bh = page_no;
   intvid(ioregs);
   dos_cur = ioregs.x.cx;
   dos_line = ioregs.h.dh;
   dos_col  = ioregs.h.dl;

   ioregs.x.ax = 0x1130;  /* EGA bios info */
   ioregs.x.dx = 0;
   ioregs.h.bh = 0;
   intvid(ioregs);
   if( ioregs.x.dx )
   {
      is_ega_plus = 1;
      scr_len = ioregs.x.dx+1;

      if( ioregs.x.cx < 13 )
         dos_cur = 0x0405;
      else if( dos_mode == 7 )
         dos_cur = 0x0C0D;
      else
         dos_cur = 0x0607;
   }
   else
   {
      is_ega_plus = 0;
      scr_len = 25;
   }

   if( dos_mode == 7 )
      phy_mode=1;
   else
      if(dos_mode == 2 || dos_mode == 3)
      {
         phy_scr.scrptr = (int far * ) 0xB8000000;
         phy_mode=1;
      }
   else if( dos_mode > 0x13 )
     phy_mode = test_svga_mode();

   if( line_len < 80 )
   {
      printf("Screen needs to be at least 80 cols\r\n");
      exit(0);
   }
   if(phy_mode==0) { printf("Unusable display mode; do: mode co80\n"); exit(1); }

   phy_scr.this_page = 0;
   if( reset_page() < 0 )
   {
      printf("Memory failure, cannot allocate screen memory\n");
      exit(1);
   }

   putscrn('\r');
   putscrn('\n');
   set_curtype(-1,0,0);
   set_blink(1);

   if( dumb_flag ) terminal_type = "dumb";
   else switch(dos_mode)
   {
   case 2:  terminal_type = "scomono" ; break;
   case 7:  terminal_type = "scomda" ; break;
   default: terminal_type = "scoansi" ; break;
   }
   terminal_lines = scr_len;
   terminal_cols  = line_len;
}

/***************************************************************************
 * Hardware screen, test for an svga text mode.
 */
int
test_svga_mode()
{
   union REGS ioregs;
   int ch;

   phy_scr.scrptr = (int far * ) 0xB8000000;

   ioregs.h.ah = 8;
   ioregs.h.bh = page_no;
   intvid(ioregs);

   ch = phy_scr.scrptr[dos_line*line_len+dos_col];
   if( ch != ioregs.x.ax ) return 0;
   phy_scr.scrptr[dos_line*line_len+dos_col] = ~ch;

   ioregs.h.ah = 8;
   ioregs.h.bh = page_no;
   intvid(ioregs);

   phy_scr.scrptr[dos_line*line_len+dos_col] = ch;
   if( ( ~ch ) != ioregs.x.ax ) return 0;
   return 1;
}

/***************************************************************************
 * Hardware screen, reset the physical screen back to normal.
 */
void end_vid()
{
   if( !quiet )
      move_cur(scr_len-1, 0);
   set_blink(1);
   set_curtype(-1,0,0);
}

/***************************************************************************
 * Hardware screen, set the screen blink mode (blink or bg bold).
 */
void
set_blink(flg)
int flg;
{
   union REGS regs;
static int last = -1;
static int first = 1;

/* This takes far too long (~ 8ms ) on some bioses.
 * It apparently waits for a screen retrace and even then it isn't reliable.
 * Will have to go directly to the HW only problem is how to do it
 */

   if( !is_ega_plus ) return;

   flg = (flg != 0);
   if( flg == last ) return;

   regs.h.ah = 0x10;
   regs.h.al = 0x03;
   regs.h.bl = last = flg;

   int86(0x10, &regs, &regs);

   if( first && flg == 0 )  /* Workaround on some EGA's */
   {
      regs.h.ah = 0x06;
      regs.h.al = 0x00;
      regs.h.bh = 0x00;
      regs.h.ch = 1;
      regs.h.cl = 1;
      regs.h.dh = 1;
      regs.h.dl = 1;
      int86(0x10, &regs, &regs);
      curpage->dirty[1] = 1;
      first = 0;
   }
}

/***************************************************************************
 * Hardware screen, set the physical cursor position.
 */
void
move_cur(row, col)
int row, col;
{
   union REGS ioregs;
   ioregs.h.ah = 2;
   ioregs.h.bh = page_no;
   ioregs.h.dh = row;
   ioregs.h.dl = col;
   intvid(ioregs);
}

/***************************************************************************
 * Hardware screen, set the physical cursor type.
 */
void
set_curtype(a,top,bot)
int a, top, bot;
{
   union REGS ioregs;
   ioregs.h.ah = 1;
   ioregs.x.cx = dos_cur;
   if( a == 0 ) ioregs.h.ch = 0x10;
   if( a == 1 ) ioregs.h.ch = 0;
   if( a == 2 ) { ioregs.h.ch = top; ioregs.h.cl = bot; }
   intvid(ioregs);
}

#endif

#ifdef SAVEBLOCK
/***************************************************************************
 * Routines to save a chunk of data for a screen macro.
 */

void
read_block(blk)
int blk;
{
   char * p;
   if( blk < 0 || blk > max_blk ) return;

   p = blocks[blk];
   if( p ) while( *p ) putscrn(*p++ & 0xFF);
}

void
save_block(blk)
int blk;
{
   if( blk < 0 || blk > max_blk ) return;
   if( save_flag == 0 ) return;
   *save_ptr++ = '\0';
   if( blocks[blk] ) free(blocks[blk]);
   blocks[blk] = malloc(save_ptr-save_buf);
   if( blocks[blk] )
      strcpy(blocks[blk], save_buf);
}

#endif

/***************************************************************************
 * Get characters from port to screen.
 */
void
serial()
{
   register int c;
   register int count=200;

   do_xmit();
   if( con_type != CON_HW ) chfetch();

   if( (c= get_c()) >= 0 )
   {
      for(;;)
      {
#ifdef PRINTER
         if( in_transprt )
	 {
            putprnt(c);
	    break;
	 }
         else
#endif
         {
            putscrn(c);
	    if( --count <= 0 || (c=get_c()) < 0 ) break;
         }
      }
   }
#ifdef MEM_SCR
   else
	 update_page();
#endif

#ifdef RS8250
   rtsflow();
#endif
}

/****************************************************************************/

#ifdef RS8250
/***************************************************************************
 * Hardware serial routines.
 */

int com_phy[] = { 0x3F8, 0x2F8, 0x3E8, 0x2E8 };
int com_irq[] = {     4,     3,     4,     3 };

#define IRQ_MASK /* 0x88 */ 0x00

int save_bitflgs;
int port_addr;
int port_int;
int rtsflag = 2;
#ifdef POLL_MODE
int intr_delay = 0;
#endif

#endif

/***************************************************************************
 * Hardware serial routines, setup port and identify fossil port.
 */
void
setup(port, flags)
int port, flags;
{
   long bps = -1;
   port_no   = port;

   if( con_type < 0 )
   {
      con_type = CON_BIOS;

      iregs.h.ah = FOSINIT;
      iregs.x.dx = port_no;
      iregs.x.bx = 0;
      int86(RS232, &iregs, &oregs);
      if( oregs.x.ax == 0x1954 && oregs.h.bh >= 4 )
      {
	 fossilfunc = oregs.h.bl;
	 iregs.h.ah = 0xE0;
	 iregs.h.al = 6;
	 iregs.x.bx = 0;
	 int86(RS232, &iregs, &oregs);
	 if( oregs.x.bx == 0x4d58 )
	    mnp_fossil = 1;
      }
#ifdef RS8250
      else con_type = CON_HW;
#endif
   }

   if( con_type == CON_BIOS )
   {
      iregs.h.ah = INITRS;
      iregs.x.dx = port_no;
      iregs.h.al = flags;
   
      int86(RS232, &iregs, &oregs);
   }

#ifdef RS8250
   if( con_type == CON_HW )
   {
      port_addr = com_phy[port_no];
      port_int  = 8 + com_irq[port_no];

      save_bitflgs = inp(port_addr+4);

      if(flags > 255)
      {
         bps = speeds[flags>>5];
         flags &= 0x1F;
         flags |= 0xE0;
      }

      iregs.h.ah = INITRS;
      iregs.x.dx = port_no;
      iregs.h.al = flags;

      int86(RS232, &iregs, &oregs);

      if( bps > 0 )
      {
         long brd = 115200L / bps;

         outp(port_addr+3, inp(port_addr+3) | 0x80);
         outp(port_addr+0, brd & 0xFF);
         outp(port_addr+1, (brd >> 8) & 0xFF);
         outp(port_addr+3, inp(port_addr+3) & 0x7F);

#ifdef POLL_MODE
	 intr_delay *= brd;
	 if( intr_delay > 60 ) intr_delay = 0;
#endif
      }

      outp(port_addr+2, 0x47); /* 16550A's FIFO cleared & at 4 char timeout */
      setints();
      outp(port_addr+4, inp(port_addr+4) | 0xB );

      /* Calculate a delay for the interrupt routine IFF we're running slow */
#ifdef POLL_MODE
      {
	 register int loop, tm;

	 loop = 32000;
	 tm = BIOS_CLOCK;
	 while(--loop != 0) if( tm != BIOS_CLOCK ) break;
	 if( loop )
	 {
	    loop = 32000;
	    tm = BIOS_CLOCK;
	    while(--loop != 0) if( tm != BIOS_CLOCK ) break;
	    if( loop > 0 )
	    {
	       intr_delay = (32000-loop)/640;
	       if( intr_delay > 18 ) intr_delay = 0;
	    }
	 }
      }
      if( intr_delay && !quiet )
	 printf("WARNING: Using polling mode\n");
#endif
   }
#endif
}

/***************************************************************************
 * Hardware serial routines, reset hardware.
 */
void
clearup()
{
#ifdef RS8250
   if( con_type == CON_HW )
   {
      outp(port_addr+4, save_bitflgs);
      clrints();
   }
#endif
}

/***************************************************************************
 * Hardware serial routines, get character from buffer.
 */
int
get_c()
{
   register int c;

   if( putptr == empty )
      return -1;
   else
   {
      _disable();
      if(getptr >= full) getptr = empty;
      c = *getptr++;
      nsize--;
      if( nsize == 0 )
         getptr = putptr = empty;
      _enable();
      return c & mask;
   }
}

/***************************************************************************
 * Hardware serial routines, get characters from BIOS or FOSSIL driver.
 */
void
chfetch()
{
static struct SREGS sregs;

   if( con_type == CON_BIOS )
   {
      if( fossilfunc >= 0x18 )
      {
	 if( putptr != empty ) return;

	 iregs.h.ah = 0x18;
	 iregs.x.cx = sizeof(empty);
	 iregs.x.di = (unsigned) empty;
	 iregs.x.dx = port_no;
	 segread(&sregs);
	 sregs.es = sregs.ds;
	 int86x(RS232, &iregs, &oregs, &sregs);
	 putptr = empty + oregs.x.ax;
	 nsize = oregs.x.ax;
	 return;
      }

      /* Loop to extract from BIOS buffer, if any! */
      while(nsize < sizeof(empty))
      {
	 iregs.h.ah = STATUS;
	 iregs.x.dx = port_no;
	 int86(RS232, &iregs, &oregs);

	 if( oregs.x.ax & DTARDY )
	 {
	    iregs.h.ah = READCH;
	    iregs.x.dx = port_no;
	    int86(RS232, &iregs, &oregs);

	    if( oregs.h.ah & 0x8E) oregs.h.al = '\032';

	    if(putptr >= full) putptr = empty;
	    *putptr++ = oregs.h.al;
	    nsize++;
	 }
	 else
	    break;
      }
   }

#ifdef LINK_COMM
   if( con_type == CON_LINK && putptr == empty )
   {
      int v;
      v = link_read( empty, sizeof(empty) );
      putptr += v; 
      nsize += v;
   }
#endif
}

/***************************************************************************
 * Hardware serial routines, send characters to port.
 */
void
do_xmit()
{
   int cnt;
   int ch;
   if( xmit_put == xmit_buf ) return;

#ifdef RS8250
   if( con_type == CON_HW )
   {
      if( !(inp(port_addr+5) & 0x20) ) return;

      ch = *xmit_get++;
      if( xmit_get == xmit_put ) xmit_get = xmit_put = xmit_buf;

      outp(port_addr+0, ch);
      return;
   }
#endif

   if( con_type == CON_BIOS )
   {
      ch = *xmit_get++;
      if( xmit_get == xmit_put ) xmit_get = xmit_put = xmit_buf;

      iregs.h.ah = WRITECH;
      iregs.x.dx = port_no;
      iregs.h.al = ch;
      int86(RS232, &iregs, &oregs);

      if( oregs.h.ah & 0x80 )
         message("Write Failed (0x%x)", oregs.h.ah);
   }

#ifdef LINK_COMM
   if( con_type == CON_LINK )
   {
      xmit_get += link_write( xmit_get, xmit_put-xmit_get );
      if( xmit_get == xmit_put ) xmit_get = xmit_put = xmit_buf;
   }
#endif
}


/***************************************************************************
 * Hardware serial routines, interrupt handling.
 */

#ifdef RS8250
void ( interrupt far * int_rs_orig) _((void));

void interrupt far int_rs _((void));

void
setints()
{
   int c;
   int c1;

   int_rs_orig = _dos_getvect(port_int);

   _dos_setvect(port_int, int_rs);

   outp(port_addr+1, 0x01);
   outp(port_addr+4, inp(port_addr+4)&0xF);

   inp(0x21);
   outp(0x21, IRQ_MASK);

   inp(port_addr+0);
}

void
clrints()
{
   int c;

   _disable();
   c = inp(port_addr+3);
   outp(port_addr+3, c&0x7F);
   outp(port_addr+1, 0);
   outp(port_addr+3, c);
   _enable();

   _dos_setvect(port_int, int_rs_orig);
}

/***************************************************************************
 * Hardware serial routines, interrupt routine.
 *
 */
void interrupt far int_rs()
{
register int lsr, prt_addr = port_addr;

   lsr=inp(prt_addr+5);
start_again:
   for(;;)
   {
      {
         register char * ptr = putptr;
         if( lsr & 0x01 )
         {
            if(ptr >= full) ptr = empty;
            *ptr++ = inp(prt_addr+0);
            nsize++;
         }
         if( lsr & 0x1A )
         {
            if(ptr >= full) ptr = empty;
	    *ptr++ = '\032';	/* Flag break, overrun or frame error */
            nsize++;
         }
         putptr = ptr;
      }

      if( rtsflag )
      {
         /* Is buffer too full ? */
         if( nsize>FLOW_ON )
         {
            register int i;
            rtsflag = 0;
            i=prt_addr+4;
            outp(i, inp(i) & ~2 );
         }
      }

#ifdef POLL_MODE
      /* This is so 115200 on a 4.77XT will cause this interrupt to loop */
      if( intr_delay )
      {
	 register int i = intr_delay;
	 do
	 {
            if( (lsr=inp(prt_addr+5)) & 0x1F ) break;
	 }
	 while(--i>0);
         if( (lsr&0x1F) ) continue;
      }
#endif
      break;
   }
   outp(prt_addr+1, 0x00);
   outp(0x20, 0x20);		/* Ensure late irq's retrigger */

   if( nsize<sizeof(empty)-2 )	/* But only if we ain't full */
   {
      /* Last chance to check for late arrivals, but we don't want to
       * if the buffer is already full.
       */
      if( (lsr=inp(prt_addr+5)) & 0x1F ) goto start_again;
      outp(prt_addr+1, 0x01);
   }
}

/***************************************************************************
 * Hardware serial routines, release RTS/CTS flow control
 */
void
rtsflow()
{
   if( con_type != CON_HW || rtsflag || nsize>FLOW_OFF ) return;

   rtsflag = 2;
   outp(port_addr+4, inp(port_addr+4) | 0xB );
   outp(port_addr+1, 0x01);
}
#endif

/***************************************************************************
 * These routines force the RTS flow control on when in the keyboard
 * interrupt; this is sometimes needed to deal with nasty TSRs and
 * bad BIOSes.
 *
 * Also here is the piece of code that stuffs the scancodes into the
 * keyboard buffer.
 */
void
init_kbd()
{
#if defined(KBDRTS) || defined(__BORLANDC__)
   orig_kbd_int = _dos_getvect(KBDINT);
   _dos_setvect(KBDINT, kbd_int);
#endif
   (void) get_key();
}

#if defined(KBDRTS) || defined(__BORLANDC__)
void interrupt far kbd_int()
{
   register int i;
#ifdef KBDRTS
   register int lsr=0;
   if( con_type == CON_HW )
      outp(port_addr+4, (lsr=inp(port_addr+4)) & ~2 );
#endif

#ifdef NS_EOI
   if( early_ack )
   {
      _enable();
      outp(0x20, 0x20);		/* Allow RS interrupts in */
   }
#endif

#ifdef AT_BIOS_KEY
#ifdef __BORLANDC__
   /* Save scancodes ... */
   if( kbd_type > 0 )
   {
      irq_flag = 16;

      i = (inp(0x60) & 0xFF);
      _CX = 0xFF00 + i;
      _AH = 0x05; geninterrupt(0x16);

      /* Disable C-A-D, C-A-Esc and Co */
      if(i==0x53 || i==1 || i==0x1C || i == 0x4A || i == 0x4E )
      {
         if( ( (i=STATE_FLAGS) & 0xC ) == 0xC )
         {
	    STATE_FLAGS = (i & ~0x030C);	/* Turn off Ctrl-Alt */
            orig_kbd_int();
	    STATE_FLAGS = i;
	    goto rs_ok;
         }
      }
      /* Disable Pause */
      else if( i == 0xE1 )
         STATE_FLAGS &= ~0x0800;
   }
#endif
#endif

#ifdef KBDRTS
   if( con_type == CON_HW )
   {
      /* Fetch any byte, but the interrupt is still pending */
      if( lsr & 2 ) for(i=0; i<40; i++)
      if( ((lsr=inp(port_addr+5)) & 0x1F ) && nsize<sizeof(empty)-2 )
      {
	 register char * ptr = putptr; i=0;
	 if( lsr & 0x1A )
	 {
	    if(ptr >= full) ptr = empty;
	    *ptr++ = '\032';	/* Flag break, overrun or frame error */
	    nsize++;
	 }
	 if( lsr & 0x01 )
	 {
	    if(ptr >= full) ptr = empty;
	    *ptr++ = inp(port_addr);
	    nsize++;
	 }
	 putptr = ptr;
      }
   }
#endif

   orig_kbd_int();

rs_ok:;
#ifdef KBDRTS
   if( con_type == CON_HW )
      outp(port_addr+4, inp(port_addr+4) | rtsflag );
#endif
}
#endif

void
clear_kbd()
{
   int i;
#if defined(KBDRTS) || defined(__BORLANDC__)
   _dos_setvect(KBDINT, orig_kbd_int);
#endif
   /* Clear any junk from the buffer */
   for(i=0; i<16; i++)
      while( get_key() != -1 ) ;
}

/***************************************************************************
 * AVATAR -> ANSI conversion routines.
 *
 * Only the hardware screen version can use the avatar+ codes
 * (except insert mode which needs large changes)
 */
#ifdef AVATAR
#ifndef MEM_SCR

char avbuf[270];
int avcnt = 0;

               /* @  A  B  C  D  E  F  G  H  I  J  K  L  M  N */
int avsizes[] = { 0, 3, 2, 2, 2, 2, 2, 2, 4, 2, 7, 7, 5, 6, 2 };
int avzero [] = { 0, 3, 2, 2, 2, 2, 2, 2, 4 };
int colconv[] = { 0, 4, 2, 6, 1, 5, 3, 7 };

do_avatar(ch)
{
   char tbuf[270];
   int i, j;

   if( avcnt == 0 )
   {
      avbuf[0] = ch;
      avcnt=1;
      return;
   }
   else
   {
      avbuf[avcnt++] = ch;
      if( avbuf[0] == '\031' )
      {
	 if( avcnt < 3 ) return;
	 j = (avbuf[2]&0x7F);
	 avcnt = -1;
	 for(i=0; i<j; i++)
	    putscrn(avbuf[1]);
	 avcnt = 0;
         return;
      }
      avbuf[1] &= 0x3F;
      if( avbuf[1] == '\031' )
      {
         if( avcnt < 3 || avcnt < (avbuf[2]&0xFF)+4 )
	    return;
      }
      else if( avbuf[1] < 1 || avbuf[1] >= sizeof(avsizes)/sizeof(int) )
      {
	 avcnt = -1;
	 putscrn('\026');
	 putscrn(ch);
	 avcnt = 0;
	 return;
      }
      else
         if( avcnt < avsizes[avbuf[1]]) return;
      avcnt = -1;
      tbuf[0] = '\0';
      switch( avbuf[1] )
      {
      case 1: sprintf(tbuf, "\033[0;3%d;4%dm",
                            colconv[avbuf[2]&0x7], colconv[(avbuf[2]>>4)&0x7]);
	      if( avbuf[2]&0x08 ) sprintf(tbuf+strlen(tbuf), "\033[1m");
	      break;
      case 2: sprintf(tbuf, "\033[5m");
	      break;
      case 3: sprintf(tbuf, "\033[A");
	      break;
      case 4: sprintf(tbuf, "\033[B");
	      break;
      case 5: sprintf(tbuf, "\033[D");
	      break;
      case 6: sprintf(tbuf, "\033[C");
	      break;
      case 7: sprintf(tbuf, "\033[K");
	      break;
      case 8: if( avbuf[2] > 25 || avbuf[2] < 1 )
	      {
		 putscrn(avbuf[2]);
		 putscrn(avbuf[3]);
	      }
	      else if( avbuf[3] > 80 || avbuf[3] < 1 )
	      {
	         sprintf(tbuf, "\033[%dH", avbuf[2]);
		 j=strlen(tbuf);
		 tbuf[j] = avbuf[3];
		 tbuf[j+1] = '\0';
	      }
	      else
	         sprintf(tbuf, "\033[%d;%dH", avbuf[2], avbuf[3]);
	      break;
      case 25: memcpy(tbuf, avbuf, 270);
               j = (tbuf[tbuf[2]+3]&0xFF);
	       avcnt = 0;
	       for(;j>0; j--)
	          for(i=0; i<(tbuf[2]&0xff); i++)
		     putscrn(tbuf[i+3]);

	       tbuf[0] = '\0';
	       break;
      default: sprintf(tbuf, "Unsupported avatar CTRL-V CTRL-%c ",
                              '@'+ avbuf[1] );
	      break;
      }
      for(i=0; tbuf[i]; i++)
	 putscrn(tbuf[i]);
      avcnt = 0;
   }
}

#else  /* def MEM_SCR */

char avbuf[270];
int avcnt = 0;

               /* @  A  B  C  D  E  F  G  H  I  J  K  L  M  N */
#ifdef AVATAR_PLUS
int avsizes[] = { 0, 3, 2, 2, 2, 2, 2, 2, 4, 2, 7, 7, 5, 6, 2 };
#else
int avsizes[] = { 0, 3, 2, 2, 2, 2, 2, 2, 4 };
#endif
int colconv[] = { 0, 4, 2, 6, 1, 5, 3, 7 };

do_avatar(ch)
{
   char tbuf[270];
   int i, j;

   if( avcnt == 0 )
   {
      avbuf[0] = ch;
      avcnt=1;
      return;
   }
   else
   {
      avbuf[avcnt++] = ch;
      if( avbuf[0] == '\031' )
      {
	 if( avcnt < 3 ) return;
	 j = (avbuf[2]&0x7F);
	 avcnt = -1;
	 for(i=0; i<j; i++)
	    litput(avbuf[1]);
	 avcnt = 0;
         return;
      }
      avbuf[1] &= 0x3F;
      if( avbuf[1] == '\031' )
      {
         if( avcnt < 3 || avcnt < (avbuf[2]&0xFF)+4 )
	    return;
      }
      else if( avbuf[1] < 1 || avbuf[1] >= sizeof(avsizes)/sizeof(int) )
      {
	 avcnt = -1;
	 litput('\026');
	 litput(ch);
	 avcnt = 0;
	 return;
      }
      else
         if( avcnt < avsizes[avbuf[1]]) return;
      avcnt = -1;
      tbuf[0] = '\0';
      switch( avbuf[1] )
      {
      case 1: if( dos_mode != 2 && dos_mode != 7 )
                  curpage->attr = (avbuf[2]&0x7F);
              else
                  curpage->attr = ((avbuf[2]&0x08)|0x07);
	      if( curpage->honour_attr )
		  curpage->clr_col = curpage->attr;
	      break;
      case 2: curpage->attr |= 0x80;
	      if( curpage->honour_attr )
		  curpage->clr_col = curpage->attr;
	      break;
      case 3: set_pos(curpage->line-1, curpage->col);
	      break;
      case 4: set_pos(curpage->line+1, curpage->col);
	      break;
      case 5: curpage->col--;
	      if( curpage->col < 0 )
		 curpage->col     = 0;
	      break;
      case 6: curpage->col++;
	      if( curpage->col >= line_len )
		 curpage->col     = line_len -1;
	      break;
      case 7: clr_eol();
	      break;
      case 8: set_pos(avbuf[2]-1, avbuf[3]-1);
	      break;
#ifdef AVATAR_PLUS
/*    case 9: insert mode  (Gaud! this means lots of changes) */

      case 10: /* scroll up */
	       scroll_up(avbuf[2], avbuf[3], avbuf[4], avbuf[5], avbuf[6]);
	       break;

      case 11: /* scroll down */
	       scroll_down(avbuf[2], avbuf[3], avbuf[4], avbuf[5], avbuf[6]);
	       break;

      case 12: clear_area(curpage->line, curpage->col,
			  avbuf[3], avbuf[4], avbuf[2] , ' ');
	       break;
      case 13: clear_area(curpage->line, curpage->col,
			  avbuf[4], avbuf[5], avbuf[2], avbuf[3]);
	       break;

      case 14: /* del char */
               delch(1);
               break;
#endif
      case 25: memcpy(tbuf, avbuf, 270);
               j = (tbuf[tbuf[2]+3]&0xFF);
	       avcnt = 0;
	       for(;j>0; j--)
	          for(i=0; i<(tbuf[2]&0xff); i++)
		     putscrn(tbuf[i+3]);

	       tbuf[0] = '\0';
	       break;
      default: sprintf(tbuf, "Unsupported avatar CTRL-V CTRL-%c ",
                              '@'+ avbuf[1] );
	      break;
      }
      for(i=0; tbuf[i]; i++)
	 putscrn(tbuf[i]);
      avcnt = 0;
   }
}

#ifdef AVATAR_PLUS
clear_area(r, c, h, w, a, cc)
int w,h;
int r, c;
{
   int i, j;
   int ch;
   int attr;

   attr = a;

   ch = (cc&0xFF)+(attr<<8);

   if( r >= scr_len || c >= line_len 
      || r+h < 0 || c+w < 0 || h < 0 || w < 0 ) return;
   if( r < 0 ) { h -= r; r = 0; }
   if( c < 0 ) { w -= c; w = 0; }
   if( r+h > scr_len ) { h = scr_len-r; }
   if( c+w > line_len ) { w = line_len-c; }

   for(i=0; i<h; i++)
   {
      for(j=0; j<w; j++)
      {
	 curpage->lines[r+i][c+j] = ch;
      }
   }
   dirty_lines(r, h);
   curpage->attr = attr;
}

scroll_up(lines, tlr, tlc, brr, brc)
int lines, tlr, tlc, brr, brc;
{
   int slines;
   int rows, cols, i, k;
   if( tlr < 1 ) tlr = 1;
   if( tlc < 1 ) tlc = 1;
   if( brr > scr_len ) brr = scr_len;
   if( brc > line_len ) brc = line_len;
   if( tlr > brr ) return;
   if( tlc > brc ) return;

   rows = brr-tlr+1;
   cols = brc-tlc+1;
   tlr--; tlc--; brc--; brr--;

   if( lines <= 0 || lines >= rows )
   {
      clear_area(tlr, tlc, rows, cols, curpage->attr, ' ');
      return;
   }
   slines = rows - lines;
   for(i=0;i < slines;i++)
   {
      /* copy from line tlr+i+lines to line tlr+i */
      for(k=tlc;k<=brc;k++)
      {
	 curpage->lines[tlr+i][k] = curpage->lines[tlr+lines+i][k];
      }
   }
   for(i=slines; i<rows; i++)
   {
      /* zap line tlr+i */
      for(k=tlc;k<=brc;k++)
      {
	 curpage->lines[tlr+i][k] = (curpage->attr<<8)+' ';
      }
   }
   dirty_lines(tlr, rows);
}

scroll_down(lines, tlr, tlc, brr, brc)
int lines, tlr, tlc, brr, brc;
{
   int slines;
   int rows, cols, i, k;
   if( tlr < 1 ) tlr = 1;
   if( tlc < 1 ) tlc = 1;
   if( brr > scr_len ) brr = scr_len;
   if( brc > line_len ) brc = line_len;
   if( tlr > brr ) return;
   if( tlc > brc ) return;

   rows = brr-tlr+1;
   cols = brc-tlc+1;
   tlr--; tlc--; brc--; brr--;

   if( lines <= 0 || lines >= rows )
   {
      clear_area(tlr, tlc, rows, cols, curpage->attr, ' ');
      return;
   }
   slines = rows - lines;
   for(i=rows-1;i >= lines;i--)
   {
      /* copy from line tlr+i to line tlr+i+lines */
      for(k=tlc;k<=brc;k++)
      {
	 curpage->lines[tlr+i][k] = curpage->lines[tlr+i-lines][k];
      }
   }
   for(i=0; i<lines; i++)
   {
      /* zap line tlr+i */
      for(k=tlc;k<=brc;k++)
      {
	 curpage->lines[tlr+i][k] = (curpage->attr<<8)+' ';
      }
   }
   dirty_lines(tlr, rows);
}

dirty_lines(top, count)
int top, count;
{
   int i;
   for(i=0; i<count; i++)
   {
      curpage->dirty[top+i] = 1;
   }
}
#endif
#endif
#endif

#ifdef AT_BIOS_KEY

#ifdef SCO_REMAP
extern char * kdeftab[];
#endif

/* Internal use only */
#define KEY_CTRL2   0x0002
#define KEY_SHIFT2  0x0001

/****************************************************************************
 * bioskeydecode table:
 *
 * Each entry is 4 fields:   0xPQRR
 *
 * P  = Forced keyflags 0=none, 1=SHIFT, 2=CTRL, 3=ALT
 *
 * Q = Key Class.
 *     0= Undefined/Special.
 *     1= Allow CTRL or SHIFT or normal ascii.
 *     2= Other key Eg TAB or ESC, only normal ascii.
 *     3= Other key, Allow shifted not CTRL ascii, Eg Return.
 *     4= Allow CTRL or SHIFT or normal ascii, specials for mixed.
 *     5= Allow only normal ascii, Not OTHER type key.
 *     6= Keypad, ascii only for normal.
 *     7= Keypad, ascii for CTRL, SHIFT or normal.
 *
 * RR = Ascii code associated with this key if none supplied by BIOS.
 *      0=> none
 *      81..8C => Function keys.
 *      90..9F => Special keys (Del, Ins, Arrows etc)
 *
 ****************************************************************************/

static int bioskeydecode[] = {
/*00*/	0x0000, 0x3280, 0x3131, 0x3132, 0x3133, 0x3134, 0x3135, 0x3136,
	0x3137, 0x3138, 0x3139, 0x3130, 0x312d, 0x313d, 0x3308, 0x1209,
/*10*/	0x3171, 0x3177, 0x3165, 0x3172, 0x3174, 0x3179, 0x3175, 0x3169,
	0x316f, 0x3170, 0x315b, 0x315d, 0x330d, 0x0000, 0x3161, 0x3173,
/*20*/	0x3164, 0x3166, 0x3167, 0x3168, 0x316a, 0x316b, 0x316c, 0x313b,
	0x0127, 0x0160, 0x0000, 0x045c, 0x317a, 0x3178, 0x3163, 0x3176,
/*30*/	0x3162, 0x316e, 0x316d, 0x312c, 0x312e, 0x312f, 0x0000, 0x0700,
	0x0000, 0x3520, 0x0000, 0x0481, 0x0482, 0x0483, 0x0484, 0x0485,
/*40*/	0x0486, 0x0487, 0x0488, 0x0489, 0x048a, 0x0600, 0x0000, 0x0697,
	0x0698, 0x0699, 0x072d, 0x0694, 0x0695, 0x0696, 0x072b, 0x0691,
/*50*/	0x0692, 0x0693, 0x0690, 0x069a, 0x1481, 0x1482, 0x1483, 0x1484,
	0x1485, 0x1486, 0x1487, 0x1488, 0x1489, 0x148a, 0x2481, 0x2482,
/*60*/	0x2483, 0x2484, 0x2485, 0x2486, 0x2487, 0x2488, 0x2489, 0x248a,
	0x3481, 0x3482, 0x3483, 0x3484, 0x3485, 0x3486, 0x3487, 0x3488,
/*70*/	0x3489, 0x348a, 0x0000, 0x2694, 0x2696, 0x2691, 0x2693, 0x2697,
	0x3131, 0x3132, 0x3133, 0x3134, 0x3135, 0x3136, 0x3137, 0x3138,
/*80*/	0x3139, 0x3130, 0x002d, 0x003d, 0x2699, 0x048b, 0x048c, 0x148b,
	0x148c, 0x248b, 0x248c, 0x348b, 0x348c, 0x2698, 0x272d, 0x2695,
/*90*/	0x272b, 0x2692, 0x2690, 0x269a, 0x2009, 0x272f, 0x272a, 0x3697,
	0x3698, 0x3699, 0x0000, 0x3694, 0x3695, 0x3696, 0x0000, 0x3691,
/*A0*/	0x3692, 0x3693, 0x3690, 0x369a, 0x372f, 0x3009, 0x370d, 0x0000,
	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
/*B0*/	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
/*C0*/	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
/*D0*/	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
/*E0*/	0x0700, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
/*F0*/	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
	0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
};

int get_key()
{
static int e_code_bytes = 0;	/* For E0 or E1 byte count */
static int big_scan = 0;	/* Build up a composite scan code */
#ifndef KEYTEST
static int pending_keyscan = 0;	/* A scancode for which we expect a bios key */
#endif

static int current_flags = 0;
static int last_flags = 0;
static int forced_flags[] = {0, KEY_SHIFT, KEY_CTRL, KEY_ALT};

   int ch, scan, key_flags;
   int scand;
   int i, key_ready;

#ifdef KEYTEST
   last_stuffed  = last_bios_key = last_ctrl_flg = -1;
#endif
   if( irq_flag > 0 ) irq_flag--;

   /* Make sure we have an AT keyboard */
   if( kbd_type < 0 )
#ifdef __BORLANDC__
   {
      kbd_type = 0;

      for(i=0; i<16;i++)
      {
         _AH = 0x01; geninterrupt(0x16); if((_FLAGS&0x40)) break;
         _AH = 0x00; geninterrupt(0x16);
      }
      _AH = 0x05; _CX= 0xFFFF; geninterrupt(0x16);
      for(i=0; i<16;i++)
      {
         _AH = 0x11; geninterrupt(0x16); if((_FLAGS&0x40)) break;
         _AH = 0x10; geninterrupt(0x16);
	 if( _AX == 0xFFFF )
	 {
	     kbd_type = 0x10;
	     break;
	 }
      }
   }
#else
      kbd_type = 0;
#endif

#ifdef KEYTEST
   if( bios_stuff ) { ch = bios_stuff; bios_stuff = key_ready = 0; } else {
#endif
#ifdef __BORLANDC__
   _AH = kbd_type+1; geninterrupt(0x16);
   ch = _AX;
   key_ready = !!(_FLAGS&0x40);

   /* Collect non-bios keys */
   if( key_ready == 0 && (ch&0xFF00) == 0xFF00 && pending_keyscan )
      key_ready = 1;
   if( key_ready == 1 && pending_keyscan )
   {
      ch = (pending_keyscan<<8) + ((pending_keyscan&0xFF00)?0xE0:0);
      key_ready = 2;
   }

#else
   key_ready = !_bios_keybrd(_KEYBRD_READY);
#endif

   if(key_ready == 0)
   {
#ifdef __BORLANDC__
      _AH = kbd_type; geninterrupt(0x16);
      ch = (unsigned) _AX;
#else
      ch = _bios_keybrd(_KEYBRD_READ);
#endif
   }
#ifdef KEYTEST
   }
#endif

   /* -- Add fake scan codes for shift changes on XT keyboards -- */
   if( kbd_type == 0 && key_ready == 1 )
   {
static int last_flgs = 0;
      int flgs = (_bios_keybrd(_KEYBRD_SHIFTSTATUS) & 0xF);
      if( flgs != last_flgs )
      {
	 key_ready = 0;
         ch = 0xFF00;
	 if( ( flgs^last_flgs ) & 1 )
	    ch = 0xFF36 + ((flgs&1)?0:0x80), last_flgs ^= 1;
	 else if( ( flgs^last_flgs ) & 2 )
	    ch = 0xFF2A + ((flgs&2)?0:0x80), last_flgs ^= 2;
	 else if( ( flgs^last_flgs ) & 4 )
	    ch = 0xFF1D + ((flgs&4)?0:0x80), last_flgs ^= 4;
	 else if( ( flgs^last_flgs ) & 8 )
	    ch = 0xFF38 + ((flgs&8)?0:0x80), last_flgs ^= 8;
      }
   }

   if( key_ready == 1 )
   {
      /* Generate the codes for double shift key flagging */
      if( last_flags != current_flags )
      {
         for(i=((current_flags|last_flags)&0x7FFF); (i&1) == 0; i>>=1)
            ;
         if( i & -2 )
	 {
            if( current_flags > last_flags )
            {
               last_flags = current_flags;
	       i = current_flags;
	       if( i & KEY_CTRL2 ) i |= KEY_CTRL;
	       if( i & KEY_SHIFT2 ) i |= KEY_SHIFT;
	       return KEY_SPECIAL + (i & 0x7F00);
            }
	    last_flags = 0;
            return KEY_SPECIAL;
         }
      }
      return -1;
   }

   /* Is this a scan code not a bios key ? */
   if( ( ch & 0xFF00 ) == 0xFF00 ) 
   {
      ch &= 0xFF;

      if( e_code_bytes ) { e_code_bytes--; big_scan = (big_scan << 8) + ch; }
      else if( ch == 0xE0 ) { e_code_bytes=1; big_scan = 0xE0; }
      else if( ch == 0xE1 ) { e_code_bytes=2; big_scan = 0; }
      else
         big_scan = ch;

      if( !e_code_bytes )
      {
static char shift_scans[8] = { 0x1D, 0x2A, 0x36, 0x38,/*0x3A, 0x45, 0x46,*/0 };
static int  shift_flags[8] = { KEY_CTRL, KEY_SHIFT, KEY_SHIFT2, KEY_ALT };
         char * p;
	 int sw_flag = 0;
         if( (p=strchr(shift_scans, (ch&0x7F))) != 0 )
	 {
	    switch(big_scan&0x7F7F)
	    {
	    case 0x601D: sw_flag = KEY_CTRL2; break;
	    case 0x602A: /* Un-numlock: The BIOS actually does this! */ break;
            case 0x1D45: /* Pause */ break;
	    case 0x6038: sw_flag = KEY_ALTGR; break;
	    default:     sw_flag = shift_flags[p-shift_scans]; break;
	    }
	    if( ch & 0x80 )
	       current_flags &= ~sw_flag;
	    else
	       current_flags |= sw_flag;
	 }
	 else if( ( ch & 0x80 ) == 0 && STATE_ALTCD == 0 )
	    pending_keyscan = big_scan;
      }
/*
cprintf("\rec %d, bs=%04x, fl=%04x, sc=%02x\r\n", e_code_bytes, big_scan, current_flags, ch);
*/
      return KEY_SPECIAL + KEY_DIRECT + KEY_OTHER + ch;
   }

#ifdef KEYTEST
   if( key_ready == 2 )
      last_stuffed  = ch;
   else
      last_bios_key = ch;
   last_ctrl_flg = current_flags;
#endif

   pending_keyscan = 0;	/* We've got something like a bios key */

   if( ch == 0 ) return KEY_OTHER + 0x03;

   scan = ((ch>>8)&0xFF);
   ch &= 0xFF;

   if( scan == 0 ) return ch + KEY_DIRECT;
   if( scan == 0xE0 ) scan = 0xA4 + 2*(ch < ' ');

   key_flags = 0;
   if( ch == 0xE0 || (key_ready != 2 && scan >= 0x97 && scan <= 0xA3 ))
   { key_flags |= KEY_PAD; ch = 0; }

   /* Check for forced flags */
   if( ch == 0 && current_flags == 0 && key_ready != 2 )
      key_flags |= forced_flags[(bioskeydecode[scan]>>12)&3];

   if( current_flags & (KEY_CTRL|KEY_CTRL2) )   key_flags |= KEY_CTRL;
   if( current_flags & (KEY_SHIFT|KEY_SHIFT2) ) key_flags |= KEY_SHIFT;
   key_flags |= (current_flags & (KEY_ALT|KEY_ALTGR));

   if( ch && key_ready != 2 ) switch(key_flags)
   {
   case KEY_CTRL: if( (ch >= ' ' && ch < '@') || ch > 127) break;
   case 0:
   case KEY_SHIFT:
      switch((bioskeydecode[scan]>>8)&7)
      {
      case 1:
         return ch;
      case 2:
         if( key_flags == 0 ) return ch + KEY_OTHER;
         break;
      case 3:
         if( (key_flags & ~KEY_CTRL) == 0 ) return ch + KEY_OTHER;
         break;
      case 4:
         if( (key_flags & ~KEY_SHIFT) == 0 ) return ch;
         if( key_flags == KEY_CTRL ) return (ch&0x1F);
         break;
      case 5:
         if( key_flags == 0 ) return ch;
         break;
      case 6:
         if( key_flags == 0 ) return ch + KEY_PAD;
         break;
      case 7: return ch + KEY_PAD;
      }
   }

   key_flags |= KEY_SPECIAL;

   if( ((bioskeydecode[scan]>>8)&6) == 6 && kbd_type )
      key_flags ^= KEY_PAD;
   
   if( ((bioskeydecode[scan]>>8)&7) == 4 &&
       ( ch || ( key_ready == 2 && ((bioskeydecode[scan]>>12)&3) != 0 ) ) )
      ;
   else if((bioskeydecode[scan]&0xFF) &&
           (!(key_flags&KEY_PAD) || (bioskeydecode[scan]&0x700)>=0x600))
      return key_flags + (bioskeydecode[scan]&0xFF);

   /* Now the last few specials ... */
   if( key_flags & KEY_PAD )
   {
      /* Keypad-'*' where it conflicts with PrintScrn */
      if( scan == 0x37 ) return key_flags + '*';

      /* Num lock */
      if( scan == 0x45 ) return 0x9B + (key_flags & ~KEY_PAD);

      /* Pause/HoldScrn */
      if( scan == 0x46 ) return 0x9C + (key_flags & ~KEY_PAD);
   }
   else
   { 
      /* Pause/HoldScrn again */
      if( scan == 0x45 ) return 0x9C + key_flags;

      /* Scroll lock */
      if( scan == 0x46 ) return 0x9D + key_flags;

      /* Caps lock */
      if( scan == 0x3A ) return 0x9F + key_flags;

      /* Key 56h, |\ or <> */
      if( scan == 0x56 ) return '<' + key_flags;

      /* Print screen */
      if( scan == 0x37 ) return 0x9E + key_flags;

      /* Print screen */
      if( scan == 0x72 )
         return 0x9E + key_flags | (current_flags==0?KEY_CTRL:0);

      /* SysRq */
      if( scan == 0x54 )
         return 0x9E + key_flags | (current_flags==0?KEY_ALT:0);
   }

   return key_flags + KEY_DIRECT + scan;
}

/****************************************************************************/

unsigned char scan_desc[] = {
 0,   0,   '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 8,   0,  
 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', 10,  'C', 'a', 's',
 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', 0,   0,   'S', 0,   'z', 'x', 'c', 'v',
 'b', 'n', 'm', ',', '.', '/', 'T', 0,   'A', ' ', 0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 'E', 'F', 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  
 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
};

char hextbl[] = "0123456789abcdef";

/* Write scancodes, in this mode you really need a compatible program on
 * the host, but you can just about type 'reset<cr>' and have it work.
 */
void
write_scan(scan)
int scan;
{
static int lastscan = 0x100;
   int by;

   scan &= 0xFF;

   if( scan == lastscan+0x80 )
      { xmit('~'); xmit('\b'); } /* xmit('_'); */
   else if( 0 != ( by = scan_desc[scan] ))
      xmit(by);
   else if( 0 != ( by = scan_desc[scan&0x7F] ))
      { xmit('!'); xmit(by); }
   else
      { xmit('~'); xmit(hextbl[scan>>4]); xmit(hextbl[scan&0xF]); }
   lastscan = scan;
}

/*
 * This keyboard gives a pattern of control sequences that makes just about
 * every keypress distinct. It does need a compatible host program but its
 * useable as a generic terminal type unlike the scancodes.
 */
void
write_doscode(ch)
int ch;
{
#define CT_KEY 0x1E
   int by = (ch & 0xFF);

   /* Ignore scancodes */
   if( (ch&0xFF00) == KEY_SPECIAL + KEY_DIRECT + KEY_OTHER )
      return ;

   /* First we swap round ^M and Return, likewise BS, Tab and Esc  */
   if( ( ch & 0xFF00 ) == KEY_OTHER || ( ch & 0xFF00 ) == 0 )
   {
      /* Make it so we can detect the 'other' keys */
      if( strchr("\b\t\r\n\033\003\177", by) )
      {
	 if( ch & KEY_OTHER )
	    ch ^= KEY_OTHER;
	 else
	    by = ((ch = KEY_SPECIAL+KEY_CTRL+tolower(by+'@')) & 0xFF);
      }
   }

   if( ch & 0xFF00 )
   {
      if( ch & KEY_SPECIAL )
      {
static char xkeys[] = "0123456789dnhspc";
static char fkeys[] = "01234567890-=ABC";
         if( by == 0 )
	 {
	    xmit(CT_KEY); xmit(' ');
	    if( ch & KEY_ALT )      { xmit(CT_KEY); xmit('A'); }
	    if( ch & KEY_CTRL )     { xmit(CT_KEY); xmit('C'); }
	    if( ch & KEY_SHIFT )    { xmit(CT_KEY); xmit('S'); }
	    if( ch & KEY_ALTGR )    { xmit(CT_KEY); xmit('G'); }
	    return;
	 }

	 if( ch & KEY_ALT )     { xmit(CT_KEY); xmit('a'); }
	 if( ch & KEY_CTRL )    { xmit(CT_KEY); xmit('c'); }
	 if( ch & KEY_SHIFT )   { xmit(CT_KEY); xmit('s'); }
	 if( ch & KEY_ALTGR )   { xmit(CT_KEY); xmit('g'); }
	 if( ch & KEY_PAD )     { xmit(CT_KEY); xmit('k'); }
	 /* if( ch & KEY_OTHER )   { xmit(CT_KEY); xmit('o'); } */

	 if( ch & KEY_DIRECT )
	 {
	    xmit(CT_KEY); xmit('~');
            xmit(hextbl[by>>4]); xmit(hextbl[by&0xF]);
	 }
         else if((by&0xF0)==0x80 )
	 {
	    if( by == 0x80 )
            {
	       xmit('\033');
	       xmit('\033');
            }
	    else
	    {
	       xmit(CT_KEY);
	       xmit(fkeys[by&0xF]);
	    }
	 }
	 else if((by&0xF0)==0x90 )
	 {
	    xmit(CT_KEY);
	    xmit('K');
	    switch(by)
	    {
	    case 0x9D: xmit('s'+ ((STATE_FLAGS&0x10)?'A'-'a':0)); break;
	    case 0x9B: xmit('n'+ ((STATE_FLAGS&0x20)?'A'-'a':0)); break;
	    case 0x9F: xmit('c'+ ((STATE_FLAGS&0x40)?'A'-'a':0)); break;
	    default: xmit(xkeys[by&0xF]); break;
	    }
         }
	 else
	    xmit(by);
      }
      else
      {
	 if( ch & KEY_DIRECT )
	 {
	    char buf[4], *p;
	    sprintf(buf, "%d", by);
	    xmit(CT_KEY); xmit('A');
	    for(p=buf; *p; p++)
	    {
	       xmit(CT_KEY); xmit('k'); xmit(*p);
	    }
	    xmit(CT_KEY); xmit(' ');
	 }
	 else
	 {
	    if( ch & KEY_PAD )     { xmit(CT_KEY); xmit('k'); }
	    if( ch & KEY_OTHER )   { xmit(CT_KEY); xmit('o'); }
	    xmit(by);
	 }
      }
   }
   else if( by == CT_KEY )
   {
      xmit(CT_KEY); xmit('c'); xmit(tolower(CT_KEY+'@'));
   }
   else
   {
      write_ascii(by);
      if( by == '\033' )
         xmit(by);
   }
}

/*
 * This key mapping is designed for easy use with terminfo nevertheless
 * it has potentially 96 function key + 104 alt/ctrl/shift&letter codes.
 *
#ifdef SCO_KEYMAP
 * This generates key sequences compatible with the SCO-Xenix console.
 * In addition many extra key combinations generate distinct codes.
 * But there are normally several ways of generating each standard key.
#endif
 */
void
write_unix(ch)
int ch;
{
   int by, mod;
#ifdef SCO_KEYMAP
                    /*  012345678901234567890123456   789012 */
static char normal[] = " MNOPQRSTUVWX   LFBGDECHAI\177.   . ";
static char shift [] = " YZabcdefghij   0123456789\177.   . ";
static char ctrl  [] = " klmnopqrstuv             \177.   . ";
static char ctrshf[] = " wxyz@[\\]^_`{             \177.   . ";
#endif

   /* This seems to be a pain if it stays */
   if( ch == KEY_SPECIAL+KEY_SHIFT+'\r' ) ch = '\r';
   if( ch == KEY_SPECIAL+KEY_SHIFT+' '  ) ch = ' ';

#ifdef SCO_KEYMAP
   if( ch & KEY_SPECIAL )
   {
      if( (ch & 0xFF) == 0 ) return;
      if( ch & (KEY_ALT|KEY_ALTGR|KEY_DIRECT) )
         write_doscode(ch);
      else if( (ch & 0xE0) != 0x80 )
         write_doscode(ch);
      else
      {
         char * keys;
	 switch(ch & (KEY_SHIFT+KEY_CTRL) )
	 {
	 case 0:			mod=0; keys = normal; break;
	 case KEY_SHIFT:		mod=1; keys = shift;  break;
	 case KEY_CTRL:			mod=2; keys = ctrl;   break;
	 case KEY_SHIFT+KEY_CTRL:	mod=3; keys = ctrshf; break;
	 }

         by = keys[ch&0x1F];
	 if( by == ' ' ) write_doscode(ch);
#ifdef SCO_REMAP
	 else if( kdeftab[(ch&0x1F) + (mod<<5)] )
	 {
            char * kptr = kdeftab[(ch&0x1F) + (mod<<5)];
	    if(kptr) while( *kptr ) xmit(*kptr++);
	 }
#endif
	 else if( by == '\177' || by >= '0' && by <= '9' )
	    xmit(by);
         else if( by != '.' )
	 {
	    xmit('\033');
	    xmit('[');
	    xmit(by);
	 }
      }
   }
#else
   if( ch & KEY_SPECIAL )
      write_doscode(ch);
#endif
   else
      write_ascii(ch);
}

/*
 * This key mapping is designed for easy use with dosemu.
 */
void
write_dosemu(ch)
int ch;
{
   int by = (ch&0xFF);

   /* First we swap round ^M and Return, likewise BS, Tab and Esc  */
   if( ( ch & 0xFF00 ) == KEY_OTHER || ( ch & 0xFF00 ) == 0 )
   {
      /* Make it so we can detect the 'other' keys */
      if( strchr("\b\t\r\n\033\003\177", by) )
      {
	 if( ch & KEY_OTHER )
	    ch ^= KEY_OTHER;
	 else
	    by = ((ch = KEY_SPECIAL+KEY_CTRL+tolower(by+'@')) & 0xFF);
      }
   }

   if( ch & KEY_SPECIAL )
   {
      if( (ch & 0xFF) == 0 ) return;
      if( ch & (KEY_ALT|KEY_ALTGR|KEY_DIRECT) )
         write_doscode(ch);
      else if( (ch & 0xF0) != 0x90 )
         write_doscode(ch);
      else /* Key pad and similar keys */
      {
	 if( ch & KEY_ALT )     { xmit(CT_KEY); xmit('a'); }
	 if( ch & KEY_CTRL )    { xmit(CT_KEY); xmit('c'); }
	 if( ch & KEY_SHIFT )   { xmit(CT_KEY); xmit('s'); }
	 if( ch & KEY_ALTGR )   { xmit(CT_KEY); xmit('g'); }

	 if( ch & KEY_PAD )
	 {
	                       /* 0123456789ABCDEF */
	    static char keys[] = "pqrstuvwxyn.   .";
	    if( keys[ch&0xF] == ' ' )
               write_doscode(ch);
	    else if( keys[ch&0xF] != '.' )
            {
	       xmit('\033');
	       xmit('O');
	       xmit(keys[ch&0xF]);
            }
	 }
	 else
	 {
	                        /* 0123456789ABCDEF */
	    static char fkeys[] = "24B6DZC1A53.   .";
	    static char skeys[] = "~~ ~   ~ ~~     ";
	    if( fkeys[ch&0xF] == ' ' )
               write_doscode(ch);
	    else if( fkeys[ch&0xF] != '.' )
            {
	       xmit('\033');
	       xmit('[');
	       xmit(fkeys[ch&0xF]);
	       if(skeys[ch&0xF] > ' ')
	          xmit(skeys[ch&0xF]);
            }
	 }
         
      }
   }
   else
      write_ascii(ch);
}

/*
 * This function remaps _just_ the directly typed keys so that if the screen
 * is in iso8859-1 mode the keys generate a character corrisponding to the
 * picture on the key! It assumes the keyboard is CP850, this is sufficiently
 * correct for all keyboards.
 */
void
write_ascii(ch)
int ch;
{
#ifdef MEM_SCR
static unsigned char conv_cp850_to_latin1[128] =
  {
    199, 252, 233, 226, 228, 224, 229, 231,	/* 128 - 135 */
    234, 235, 232, 239, 238, 236, 196, 197,	/* 136 - 143 */
    201, 230, 198, 244, 246, 242, 251, 249,	/* 144 - 151 */
    255, 214, 220, 248, 163, 216, 215,   0,	/* 152 - 159 */
    225, 237, 243, 250, 241, 209, 170, 186,	/* 160 - 167 */
    191, 174, 172, 189, 188, 161, 171, 187,	/* 168 - 175 */
      0,   0,   0,   0,   0, 193, 194, 192,	/* 176 - 183 */
    169,   0,   0,   0,   0, 162, 165,   0,	/* 184 - 191 */
      0,   0,   0,   0,   0,   0, 227, 195,	/* 192 - 199 */
      0,   0,   0,   0,   0,   0,   0, 164,	/* 200 - 207 */
    240, 208, 202, 203, 200,   0, 205, 206,	/* 208 - 215 */
    207,   0,   0,   0,   0, 166, 204,   0,	/* 216 - 223 */
    211, 223, 212, 210, 245, 213,   0, 222,	/* 224 - 231 */
    254, 218, 219, 217, 253, 221,   0, 180,	/* 232 - 239 */
    173, 177,   0, 190, 182, 167, 247,   0,	/* 240 - 247 */
    176, 168,   0, 185, 179, 178,   0, 160,	/* 248 - 255 */
  };
   if( ch >= 128 && ch < 256 && curpage->chartran == 1 )
   {
      if( conv_cp850_to_latin1[ch-128] )
         ch = conv_cp850_to_latin1[ch-128];
   }
#endif
   xmit(ch&0xFF);
}

/***************************************************************************
 * These functions are used for defining alternate function keys.
 */

#ifdef SCO_REMAP
char   keybuf[33] = "";
char * kdeftab[128];

void add_fnchar(ch)
int ch;
{
   int s = strlen(keybuf);
   if( s == 32 ) return;
   keybuf[s] = ch;
   s++;
   keybuf[s] = 0;
}

#define KEYTABSIZE 64

void set_key(kno)
int kno;
{
   static sco_xlate[KEYTABSIZE] = {
      0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
      0x09, 0x0A, 0x0B, 0x0C, 0x21, 0x22, 0x23, 0x24,
      0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C,
      0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48,
      0x49, 0x4A, 0x4B, 0x4C, 0x61, 0x62, 0x63, 0x64,
      0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C,
      0x17, 0x18, 0x19, 0x00, 0x14, 0x15, 0x16, 0x00,
      0x11, 0x12, 0x13, 0x10, 0x00, 0x00, 0x00, 0x00
   };

   if( kno < 0 || kno >= KEYTABSIZE ) return;
   kno = sco_xlate[kno];

   if( kdeftab[kno] ) free(kdeftab[kno]);
   if( keybuf[0] ) kdeftab[kno] = strdup(keybuf);
   else            kdeftab[kno] = 0;

   keybuf[0] = 0;
}

void reset_fkeys()
{
   int kno;

   keybuf[0] = 0;
   for(kno=0;kno<KEYTABSIZE;kno++) set_key(kno);
}

#endif /* SCO_REMAP */

#else /* !AT_BIOS_KEY */
/***************************************************************************
 * Get a key from the keyboard (-1 if none available)
 * Simple XT-BIOS version
 */

int get_key()
{
#ifdef KEY_COMPAT
   /* This is called so often that windows thinks we're idle; well we
    * are _but_ windows doesn't restart us for a serial interrupt.
    */

   if( _bios_keybrd(_KEYBRD_READY) == 0 ) return -1;
   return _bios_keybrd(_KEYBRD_READ);

#else

  /* So we have to hack it */

#define bios_ram   ((char far *)0x00400000L)
   static char last_flags = 0;
   int c;

   if( bios_ram[0x1C] != bios_ram[0x1A] )
      return _bios_keybrd(_KEYBRD_READ);
   else
      return -1;

#endif

}

/***************************************************************************
 * XT-BIOS Keymap tables for SCO console.
 */

#ifdef SCO_KEYMAP
#ifdef SCO_REMAP
#define KEYTABSIZE 64

char * keytab[95];
char   keybuf[33] = "";
int    keyxlate[KEYTABSIZE] =
                      { 0073, 0074, 0075, 0076, 0077,
                        0100, 0101, 0102, 0103, 0104, 0, 0, /* F11, F12 oops */
			0124, 0125, 0126, 0127, 0130,
			0131, 0132, 0133, 0134, 0135, 0, 0,
			0136, 0137, 0140, 0141, 0142,
			0143, 0144, 0145, 0146, 0147, 0, 0,
			0150, 0151, 0152, 0153, 0154,
			0155, 0156, 0157, 0160, 0161, 0, 0,
			0107, 0110, 0111, 0112, 0113,
			0114, 0115, 0116, 0117, 0120,
			0121, 0122
                      };
#endif

int kbtab[] =
{
/* 000 00 */   0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
/* 010 08 */   0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x25A,
/* 020 10 */   0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
/* 030 18 */   0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
/* 040 20 */   0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
/* 050 28 */   0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
/* 060 30 */   0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
/* 070 38 */   0x000, 0x000, 0x000, 0x24D, 0x24E, 0x24F, 0x250, 0x251,
/* 100 40 */   0x252, 0x253, 0x254, 0x255, 0x256, 0x000, 0x000, 0x248,
/* 110 48 */   0x241, 0x249, 0x000, 0x244, 0x000, 0x243, 0x000, 0x246,
/* 120 50 */   0x242, 0x247, 0x24C, 0x07F, 0x259, 0x25A, 0x261, 0x262,
/* 130 58 */   0x263, 0x264, 0x265, 0x266, 0x267, 0x268, 0x26B, 0x26C,
/* 140 60 */   0x26D, 0x26E, 0x26F, 0x270, 0x271, 0x272, 0x273, 0x274,
/* 150 68 */   0x277, 0x278, 0x279, 0x27A, 0x240, 0x25B, 0x25C, 0x25D,
/* 160 70 */   0x25E, 0x25F, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000
};

bios_keymap(c)
int c;
{
   char * kptr;
   c >>= 8;

   if(c>=0 && c<0x78 && kbtab[c])
   {
      switch((kbtab[c] >> 8)&0xF)
      {
      case 1: xmit('\033');
	      break;
      case 2: xmit('\033');
	      xmit('[');
	      break;
#ifdef SCO_REMAP
      case 3: kptr = keytab[kbtab[c] & 0xFF];
	      if(kptr) while( *kptr ) xmit(*kptr++);
	      return TRUE;
#endif
      }
      xmit(kbtab[c] & 0xFF);
      return 1;
   }
   return 0;
}

/***************************************************************************
 * These functions are used for defining alternate function keys.
 */

#ifdef SCO_REMAP
void add_fnchar(ch)
int ch;
{
   int s = strlen(keybuf);
   if( s == 32 ) return;
   keybuf[s] = ch;
   s++;
   keybuf[s] = 0;
}

void set_key(kno)
int kno;
{
   if( kno < 0 || kno >= KEYTABSIZE ) return;

   kbtab[keyxlate[kno]] = (0x300|kno);

   if( keybuf[0] == 0 ) return message("Function key %d cleared", kno+1);
   if( keytab[kno] != 0 )
   {
      free(keytab[kno]);
      keytab[kno] = 0;
   }
   keytab[kno] = malloc(strlen(keybuf)+1);
   strcpy(keytab[kno], keybuf);
   keybuf[0] = 0;
}
#endif
#endif
#endif
